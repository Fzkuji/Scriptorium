The user is actively improving their English, having started taking English language classes in May 2023, and practices outside of class using apps, online resources, and a planned language exchange partner.[^e-d600ab085e] ^01fbcdd7

[^e-d600ab085e]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_15bbcc24f91f](sources/locomo/thread_37d993f7a9d6.md#source-3f1bc7ce207d5335), [locomo/thread_37d993f7a9d6/msg_34fa12ce3947](sources/locomo/thread_37d993f7a9d6.md#source-eae59293bb940b5e)

The user recently moved into a new apartment whose shorter commute frees up about 30 extra minutes each morning.[^e-952232ddf3] ^ce04e934

[^e-952232ddf3]: Time: `2023-04-29`; Sources: [locomo/thread_7a2d72a9009a/msg_733c22d0826c](sources/locomo/thread_7a2d72a9009a.md#source-80f4b4db0c7b2c23)

The user recently changed their legal name and is updating their official documents, including changing their address with the US Postal Service.[^e-29326bd588] ^1bf43553

[^e-29326bd588]: Time: `2023-05-20`; Sources: [locomo/thread_6bc2090ac4de/msg_a24e4dfe6c20](sources/locomo/thread_6bc2090ac4de.md#source-a32718f8a803603d)

The user is planning a road trip in spring 2024 to visit national parks in the western US, including the Grand Canyon and Yellowstone.[^e-1f97dc9aa5] ^773858e6

[^e-1f97dc9aa5]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_db5b60cf8fd1](sources/locomo/thread_7a2d72a9009a.md#source-09eb5fd0b8dae9a0)

The user is planning a trip to visit family for the holidays and needs to renew their passport beforehand.[^e-839c2419f3] ^d2cf4fab

[^e-839c2419f3]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_cef6e3a88f68](sources/locomo/thread_7a2d72a9009a.md#source-52c4794a71fd2442)

The user manages chronic sinusitis, uses a nasal spray prescribed by Dr. Patel, and recently received a benign biopsy result for a mole on their back from dermatologist Dr. Lee.[^e-257ea3a8c8] ^ed6a45f8

[^e-257ea3a8c8]: Time: `2023-05-20`; Sources: [locomo/thread_89990fbd2a44/msg_e94e6e841d8e](sources/locomo/thread_89990fbd2a44.md#source-72a40ff0043bd59d), [locomo/thread_89990fbd2a44/msg_159ca96fc9cf](sources/locomo/thread_89990fbd2a44.md#source-dbb89dc4c282dd9b)

The user's primary care physician is Dr. Smith, who recently treated them for a urinary tract infection with antibiotics; the user is still recovering and has been experiencing fatigue.[^e-87388e0357] ^6e6fcf6c

[^e-87388e0357]: Time: `2023-05-21`; Sources: [locomo/thread_cbcd98836154/msg_4efa0dd0ad5d](sources/locomo/thread_cbcd98836154.md#source-d36bc6e70ac12196), [locomo/thread_cbcd98836154/msg_8efa0e8abaf5](sources/locomo/thread_cbcd98836154.md#source-ecffe79b3060cdbc)

The user is exploring how to merge their multiple diverse passions into a single career path and is researching career options that reflect their varied interests.[^e-3d59ccbcd7] ^80cadaba

[^e-3d59ccbcd7]: Time: `2023-05-21`; Sources: [locomo/thread_987adb9e3384/msg_49916e9f133b](sources/locomo/thread_987adb9e3384.md#source-3476c113605b1c56), [locomo/thread_987adb9e3384/msg_cedd23a82653](sources/locomo/thread_987adb9e3384.md#source-a01f1646c2b15630)

The user is an active gardener who practices companion planting and is exploring permaculture and natural pest control methods.[^e-dba2d61918] ^b82ce4be

[^e-dba2d61918]: Time: `2023-05-22`; Sources: [locomo/thread_749fa3152137/msg_a642c1a18f3f](sources/locomo/thread_749fa3152137.md#source-4163a2571ab0f5e7), [locomo/thread_749fa3152137/msg_0913bf8fc1b5](sources/locomo/thread_749fa3152137.md#source-c0d518f692b45fef)

The user is developing a zombie-apocalypse video game with a prologue and three timeline paths plus seven "Amplified" zombie types, and wants the timelines kept ambiguous until players piece together the clues.[^e-ba209d838c] ^3cc3c914

[^e-ba209d838c]: Time: `2023-05-23`; Sources: [locomo/thread_810c4bac6d0f/msg_8f5a57d42cbb](sources/locomo/thread_810c4bac6d0f.md#source-d1cf887ca1af8bc8), [locomo/thread_810c4bac6d0f/msg_2f8a85df49fb](sources/locomo/thread_810c4bac6d0f.md#source-f669b521a9f819bb), [locomo/thread_810c4bac6d0f/msg_f91bb19ddb67](sources/locomo/thread_810c4bac6d0f.md#source-83c02a13a2357013)

The user is committed to reducing waste and living more sustainably, including switching to eco-friendly products, reducing single-use plastics, and reducing food waste.[^e-b46a7c71eb][^e-12fff023fa][^e-329d82ed46] ^587a0354

[^e-b46a7c71eb]: Time: `2023-05-23`; Sources: [locomo/thread_aaa7a92208f6/msg_3b8e306169b8](sources/locomo/thread_aaa7a92208f6.md#source-6f360b8fd76a3e9f)

[^e-12fff023fa]: Time: `2023-05-24`; Sources: [locomo/thread_01ea86c3d49e/msg_71e26acb8c06](sources/locomo/thread_01ea86c3d49e.md#source-1408496e554a6289)

[^e-329d82ed46]: Time: `2023-05`; Sources: [locomo/thread_aaa7a92208f6/msg_75ad9734e141](sources/locomo/thread_aaa7a92208f6.md#source-cbfd99d1cd502542)

The user is building RealEstateMall, a real estate marketplace platform, and is exploring adding interactive 3D property tours, virtual staging, renovation visualization, and neighborhood and street visualization to it.[^e-c69247ee7b] ^e95971ec

[^e-c69247ee7b]: Time: `2023-05-24`; Sources: [locomo/thread_b24a05483e4e/msg_f387e885504d](sources/locomo/thread_b24a05483e4e.md#source-1fd9321af352ff31), [locomo/thread_b24a05483e4e/msg_62cf9d12f1a0](sources/locomo/thread_b24a05483e4e.md#source-9aa08c67a105c408), [locomo/thread_b24a05483e4e/msg_248efc7a5dc9](sources/locomo/thread_b24a05483e4e.md#source-79023fd204902ae0), [locomo/thread_b24a05483e4e/msg_be725ca91973](sources/locomo/thread_b24a05483e4e.md#source-793c6a5c40669b6e)

The user is an active solo traveler who recently returned from a solo trip to Thailand and is already planning their next trip, leaning toward Central America and specifically Costa Rica.[^e-dac8df0646] ^40047567

[^e-dac8df0646]: Time: `2023-05-26`; Sources: [locomo/thread_85a4c6cb88e4/msg_09c255ae0eb8](sources/locomo/thread_85a4c6cb88e4.md#source-b753ff2e5aa7b201), [locomo/thread_85a4c6cb88e4/msg_7d4597b48c1f](sources/locomo/thread_85a4c6cb88e4.md#source-3e1244b164ec31b8)

The user commutes to work by bus in Springfield, Massachusetts, catching the bus at 7:45 am, and is considering switching to a bike commute.[^e-1dd9bf676d] ^87b9cea3

[^e-1dd9bf676d]: Time: `2023-05-25`; Sources: [locomo/thread_de58813e57c1/msg_d790286faeeb](sources/locomo/thread_de58813e57c1.md#source-d80e2d4a986f8779), [locomo/thread_de58813e57c1/msg_31c7ba4c5cac](sources/locomo/thread_de58813e57c1.md#source-fc89b14202eb4cad)

The user is a web developer and is planning to build a Coaching for Profit (CFP) Management System SaaS that any poker coaching business could use to manage their business.[^e-63d02a25b6] ^11cdf020

[^e-63d02a25b6]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_5cc39f69fb27](sources/locomo/thread_023f8650f638.md#source-065a44001a08aed1)

The user usually reads The New Yorker magazine on Sundays.[^e-5d7e1701a9] ^6146fb73

[^e-5d7e1701a9]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_f0d74ae50aaa](sources/locomo/thread_b6fdc3c2643b.md#source-1c124a978a422942), [locomo/thread_b6fdc3c2643b/msg_7679159943d0](sources/locomo/thread_b6fdc3c2643b.md#source-ea454525e1b4f702)

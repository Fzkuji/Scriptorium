# thread_7c96790ff4be

<a id="source-0f9d10005397692e"></a>
<!-- source-id:locomo/thread_7c96790ff4be/msg_78118bc0cf54 -->
[2023-05-22] user: What got written during the Battle of Baltimore and by who?

<a id="source-99ac97836ddb7902"></a>
<!-- source-id:locomo/thread_7c96790ff4be/msg_f580f8742d52 -->
[2023-05-22] assistant: The Battle of Baltimore took place during the War of 1812, specifically on September 12-14, 1814. One of the most significant events that occurred during this battle was the bombardment of Fort McHenry by the British Navy. This bombardment inspired Francis Scott Key, an American lawyer and amateur poet, to write a poem titled "Defence of Fort M'Henry", which later became known as "The Star-Spangled Banner", the national anthem of the United States.

Francis Scott Key was aboard a British ship negotiating the release of American prisoners when the bombardment began. Throughout the night, he watched as the American flag continued to fly above Fort McHenry, despite the intense shelling. When the bombardment finally ceased and Key saw the flag still waving, he was inspired to write the poem.

The poem was later set to the tune of a popular British song, "To Anacreon in Heaven," and became a popular patriotic song in the United States. In 1931, "The Star-Spangled Banner" was officially adopted as the national anthem of the United States.

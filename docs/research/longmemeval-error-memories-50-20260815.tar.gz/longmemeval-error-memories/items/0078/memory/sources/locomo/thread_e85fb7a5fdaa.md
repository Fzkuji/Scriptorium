# thread_e85fb7a5fdaa

<a id="source-e961634308cd8289"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_89e527969c06 -->
[2023-05-28] user: I'm looking to get some advice on insuring my valuables. I recently inherited a few rare items, including an antique emerald and diamond necklace that's been in my family for generations, which a gemologist valued at $12,000.

<a id="source-6ae9fafd63cff716"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_fd4953c05338 -->
[2023-05-28] assistant: Congratulations on your inheritance! Insuring your valuable items is a wise decision to protect them from loss, damage, or theft. I'd be happy to offer some advice on how to insure your antique emerald and diamond necklace.

**Types of Insurance Options:**

1. **Homeowners or Renters Insurance:** You can add a rider or endorsement to your existing homeowners or renters insurance policy to cover your valuable items. This is often the most cost-effective option. However, the coverage limits may be lower, and the deductible might be higher.
2. **Scheduled Personal Property (SPP) Insurance:** This type of policy provides more comprehensive coverage for individual items, like your necklace. You'll need to schedule each item separately, and the coverage is usually more detailed.
3. **Stand-Alone Jewelry Insurance:** Specialized insurance companies offer policies specifically designed for jewelry and other valuable items. These policies often provide more comprehensive coverage and flexibility.

**Things to Consider:**

1. **Appraisal and Valuation:** Since you've already had your necklace appraised, you have a professional valuation. Keep the appraisal report and any documentation to support the value.
2. **Coverage Limits:** Ensure the policy covers the full value of your necklace ($12,000). Some policies may have lower coverage limits, so be sure to check.
3. **Deductible:** Understand the deductible amount you'll need to pay in case of a claim.
4. **Coverage Perils:** Check what perils are covered, such as theft, loss, damage, or mysterious disappearance.
5. **Worldwide Coverage:** If you plan to travel with your necklace, ensure the policy covers it worldwide.
6. **Depreciation:** Some policies may depreciate the value of your necklace over time. Look for policies that offer agreed value or guaranteed value coverage.
7. **Claims Process:** Research the insurer's claims process and reputation for settling claims fairly and quickly.

**Next Steps:**

1. **Contact Your Current Insurer:** Reach out to your homeowners or renters insurance provider to discuss adding a rider or endorsement for your necklace.
2. **Research Specialized Insurers:** Look into companies that specialize in jewelry insurance, such as Jewelers Mutual, State Farm, or Chubb.
3. **Compare Policies:** Get quotes from multiple insurers and compare coverage, pricing, and service.
4. **Review and Update:** Regularly review your policy to ensure it remains adequate, and update your coverage as needed.

By following these steps, you'll be able to find the right insurance coverage for your valuable antique emerald and diamond necklace.

<a id="source-78e91c3cb4189370"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_9cf6ec6ac876 -->
[2023-05-28] user: I'm also considering insuring some of my other rare items, like a vintage 1960s Omega Speedmaster watch I purchased online for $3,200. It's one of only 100 pieces made with a rare "tropical" dial. Do you have any advice on how to determine the value of an item like this for insurance purposes?

<a id="source-acadb2bb2e107b34"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_52606b108e25 -->
[2023-05-28] assistant: Insuring your vintage Omega Speedmaster watch is a great idea, especially given its rarity and value. Determining the value of a unique item like this can be a bit more complex, but here are some steps to help you establish its value for insurance purposes:

**Gather Documentation:**

1. **Sales Receipt:** Keep the sales receipt from the online purchase, which should show the price you paid ($3,200).
2. **Certificate of Authenticity:** If you received a certificate of authenticity from the seller or a reputable third-party authenticator, make sure to keep it. This document confirms the watch's legitimacy and provenance.
3. **Appraisal Report:** Consider hiring a professional watch appraiser or a reputable vintage watch dealer to evaluate your Speedmaster. They can provide a detailed appraisal report, which will help establish the watch's value.

**Research the Market:**

1. **Comparable Sales:** Look for recent sales of similar vintage Omega Speedmaster watches with "tropical" dials. Websites like Chrono24, WatchRecon, or specialized watch forums can provide valuable insights.
2. **Auction Results:** Check auction houses like Christie's, Sotheby's, or Bonhams, which frequently feature rare and vintage watches. You can find auction results and estimates for similar watches.
3. **Collector Communities:** Join online forums or social media groups dedicated to vintage watch collectors. These communities often share knowledge, discuss market trends, and provide insights on rare watches like yours.

**Determine the Value:**

1. **Retail Replacement Value:** Based on your research, determine the retail replacement value of your watch. This is the amount it would cost to replace your watch with a similar one in the current market.
2. **Actual Cash Value:** This value takes into account the watch's age, condition, and depreciation. It's the amount you could realistically sell the watch for in the current market.
3. **Agreed Value:** If you're insuring your watch, you may want to negotiate an agreed value with the insurer. This is the amount you and the insurer agree upon as the watch's value.

**Tips for Insuring Your Watch:**

1. **Specify the Watch's Features:** When insuring your watch, make sure to specify its unique features, such as the "tropical" dial, to ensure the insurer understands its value.
2. **Get a Detailed Policy:** Opt for a policy that covers specific perils, such as theft, loss, damage, or mysterious disappearance.
3. **Consider a Scheduled Policy:** A scheduled policy allows you to insure individual items, like your watch, with a more detailed description and valuation.
4. **Review and Update:** Regularly review your policy to ensure it remains adequate, and update the valuation as the watch's value changes over time.

By following these steps, you'll be able to determine a fair value for your vintage Omega Speedmaster watch and ensure it's properly insured.

<a id="source-b22c0b6375e06159"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_6fc8dcacf93d -->
[2023-05-28] user: I'm also thinking of insuring my rare first edition of F. Scott Fitzgerald's "The Great Gatsby" that I recently purchased at a used bookstore in the East Village. The owner told me it was one of only 300 copies printed with a misprinted title page, and I managed to negotiate the price down to $2,500. Do you have any advice on how to determine the value of a rare book like this for insurance purposes?

<a id="source-a065a96899dad69b"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_feace2d0fb3f -->
[2023-05-28] assistant: What a fantastic find! Insuring your rare first edition of "The Great Gatsby" is a great idea, and I'm happy to help you determine its value for insurance purposes.

**Gather Documentation:**

1. **Receipt and Provenance:** Keep the receipt from the used bookstore, as well as any documentation from the seller about the book's provenance, including the misprinted title page.
2. **Certificate of Authenticity:** If the seller provided a certificate of authenticity or a letter of provenance, make sure to keep it. This document confirms the book's legitimacy and rarity.
3. **Appraisal Report:** Consider hiring a professional rare book appraiser or a reputable rare book dealer to evaluate your "Gatsby" edition. They can provide a detailed appraisal report, which will help establish the book's value.

**Research the Market:**

1. **Comparable Sales:** Look for recent sales of similar rare book editions, including first editions with misprinted title pages. Websites like AbeBooks, Biblio, or rare book auction houses like Christie's or Sotheby's can provide valuable insights.
2. **Bibliographic Resources:** Consult reputable bibliographic resources, such as the Bibliography of American Literature (BAL) or the First Edition Identification Points website, to verify the edition's authenticity and rarity.
3. **Rare Book Communities:** Join online forums or social media groups dedicated to rare book collectors. These communities often share knowledge, discuss market trends, and provide insights on rare books like yours.

**Determine the Value:**

1. **Retail Replacement Value:** Based on your research, determine the retail replacement value of your "Gatsby" edition. This is the amount it would cost to replace your book with a similar one in the current market.
2. **Actual Cash Value:** This value takes into account the book's condition, rarity, and depreciation. It's the amount you could realistically sell the book for in the current market.
3. **Agreed Value:** If you're insuring your book, you may want to negotiate an agreed value with the insurer. This is the amount you and the insurer agree upon as the book's value.

**Tips for Insuring Your Rare Book:**

1. **Provide Detailed Description:** When insuring your book, provide a detailed description, including the edition, printing, and any unique features like the misprinted title page.
2. **Specify the Condition:** Accurately describe the book's condition, including any flaws or defects, to ensure the insurer understands its value.
3. **Consider a Scheduled Policy:** A scheduled policy allows you to insure individual items, like your rare book, with a more detailed description and valuation.
4. **Review and Update:** Regularly review your policy to ensure it remains adequate, and update the valuation as the book's value changes over time.

By following these steps, you'll be able to determine a fair value for your rare first edition of "The Great Gatsby" and ensure it's properly insured.

<a id="source-07df541c8aa32e38"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_aeb41ccca1d7 -->
[2023-05-28] user: I'm also planning to insure my antique emerald and diamond necklace that's been in my family for generations, which a gemologist valued at $12,000. I'd like to get advice on how to store and protect it while it's not being worn, to minimize the risk of damage or loss.

<a id="source-39d19dd273e95721"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_a7d2f44e508f -->
[2023-05-28] assistant: Wonderful! Insuring your antique emerald and diamond necklace is a great step, and now it's essential to focus on storing and protecting it when not being worn. Here are some expert tips to help you minimize the risk of damage or loss:

**Storage:**

1. **Safety Deposit Box:** Consider renting a safety deposit box at a bank or a secure storage facility. This will provide a highly secure environment, protected by alarms, cameras, and limited access.
2. **Home Safe:** If you prefer to store the necklace at home, invest in a high-quality safe that's specifically designed for jewelry storage. Look for a safe with a UL (Underwriters Laboratories) rating, which indicates it's been tested for security and durability.
3. **Jewelry Armoire:** If you don't have a safe, consider a high-quality jewelry armoire with a lock. These often have separate compartments and velvet-lined trays to prevent scratching and tangling.

**Protection:**

1. **Individual Storage:** Store each piece of jewelry, including the emerald and diamond necklace, separately to prevent scratching or tangling.
2. **Soft Pouches or Boxes:** Use soft, velvet-lined pouches or boxes specifically designed for jewelry storage. These will help prevent scratching and damage.
3. **Avoid Humidity:** Store the necklace in a dry, cool environment to prevent humidity from causing damage to the emeralds or other components.
4. **Avoid Direct Sunlight:** Direct sunlight can cause gemstones to fade or become discolored over time. Store the necklace away from direct sunlight or use UV-filtering glass or acrylic to minimize exposure.

**Security:**

1. **Keep it Discreet:** Avoid discussing the necklace's value or storage location with anyone outside your trusted circle.
2. **Document Storage:** Keep documentation, such as appraisals, certificates, and receipts, in a separate, secure location.
3. **Inventory and Photos:** Take high-quality photos of the necklace from multiple angles and create an inventory list, including details like the gemstone type, carat weight, and metal composition.
4. **Alarm Systems:** Consider investing in a home security system that includes motion detectors and door/window sensors to deter potential thieves.

**Maintenance:**

1. **Regular Cleaning:** Clean the necklace regularly using a soft, dry cloth to remove dirt and oils from skin.
2. **Professional Maintenance:** Have the necklace professionally cleaned, inspected, and maintained by a reputable jeweler every 6-12 months to prevent damage and detect any potential issues.
3. **Avoid Chemicals:** Avoid exposing the necklace to harsh chemicals, such as bleach or ammonia, which can damage the gemstones or metal.

By following these storage, protection, security, and maintenance tips, you'll be able to minimize the risk of damage or loss and ensure your antique emerald and diamond necklace remains safe and secure when not being worn.

<a id="source-f4bcfd718bec2398"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_4db1ca81c322 -->
[2023-05-28] user: I'd like to get some advice on how to display my vintage 1920s Cartier pocket watch, which I inherited from my grandfather. It's one of only 50 pieces made with a unique enamel dial, and I had it appraised by a professional who valued it at $15,000. I'd like to display it in a glass case in my study, but I'm not sure how to do it safely and securely.

<a id="source-baa2ea07b4716887"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_82036e3667b3 -->
[2023-05-28] assistant: What a treasured family heirloom! Displaying your vintage Cartier pocket watch in a glass case is a great way to showcase its beauty while keeping it safe. Here are some expert tips to help you display your pocket watch securely and safely:

**Glass Case Selection:**

1. **Acrylic or Glass:** Choose a high-quality glass case made from acrylic or glass that's specifically designed for displaying valuable items. Avoid using a regular glass case, as it may not provide sufficient protection.
2. **UV Protection:** Opt for a case with UV-filtering glass or acrylic to prevent damage from direct sunlight, which can cause the enamel dial to fade or become discolored.
3. **Secure Closure:** Ensure the case has a secure closure system, such as a locking mechanism or a tight-fitting lid, to prevent unauthorized access.

**Mounting and Display:**

1. **Custom Mounting:** Consider hiring a professional to create a custom mounting system that will hold the pocket watch securely in place. This will prevent it from shifting or falling.
2. **Soft Padding:** Use soft, acid-free padding or velvet to cushion the pocket watch and prevent scratching or damage.
3. **Minimal Handling:** Handle the pocket watch as little as possible to prevent oils from your skin from damaging the enamel dial or other components.

**Environmental Control:**

1. **Temperature Control:** Keep the display case away from direct sunlight, radiators, or air conditioning vents, which can cause temperature fluctuations that may damage the pocket watch.
2. **Humidity Control:** Maintain a stable humidity level between 40-60% to prevent moisture from accumulating inside the case and damaging the watch.
3. **Air Quality:** Keep the display case away from areas with high pollution or airborne contaminants, which can damage the watch's finish or components.

**Security Considerations:**

1. **Anchoring:** Anchor the display case to a wall or a heavy piece of furniture to prevent it from being easily moved or stolen.
2. **Alarm System:** Consider investing in a security system that includes motion detectors and glass break sensors to deter potential thieves.
3. **Discreet Display:** Avoid drawing attention to the pocket watch's value or the display case's security features to minimize the risk of theft.

**Additional Tips:**

1. **Regular Inspection:** Regularly inspect the pocket watch and display case to ensure they're in good condition and secure.
2. **Professional Maintenance:** Have the pocket watch professionally maintained and serviced every 5-10 years to prevent damage and ensure it remains in good working condition.
3. **Documentation:** Keep documentation, such as appraisals, certificates, and receipts, in a separate, secure location to prove ownership and value.

By following these expert tips, you'll be able to display your vintage Cartier pocket watch safely and securely in your study, while showcasing its beauty and historical significance.

<a id="source-9980cb2edaac333d"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_6ec44c120a29 -->
[2023-05-28] user: I'd like to get some advice on how to determine the value of my rare 1913 Liberty Head nickel, which I recently purchased from a reputable dealer for $10,000. I'd like to insure it, but I'm not sure how to determine its value for insurance purposes.

<a id="source-d2a895a6e2e41d0e"></a>
<!-- source-id:locomo/thread_e85fb7a5fdaa/msg_4187f392cc94 -->
[2023-05-28] assistant: What a fantastic find! Determining the value of your rare 1913 Liberty Head nickel is a crucial step in insuring it properly. Here are some expert tips to help you determine its value for insurance purposes:

**Gather Documentation:**

1. **Receipt and Provenance:** Keep the receipt from the reputable dealer, as well as any documentation about the coin's provenance, including its history of ownership and any previous sales records.
2. **Certification:** Ensure the coin is certified by a reputable third-party grading service, such as the Professional Coin Grading Service (PCGS) or the Numismatic Guaranty Corporation (NGC). This will provide an independent assessment of the coin's authenticity and grade.

**Research the Market:**

1. **Comparable Sales:** Look for recent sales of similar 1913 Liberty Head nickels, including those with similar grades and provenance. Websites like Heritage Auctions, Stack's Bowers, or NGC's auction archives can provide valuable insights.
2. **Price Guides:** Consult reputable coin price guides, such as the Red Book or the PCGS Price Guide, to determine the coin's value based on its grade and rarity.
3. **Coin Communities:** Join online forums or social media groups dedicated to numismatics. These communities often share knowledge, discuss market trends, and provide insights on rare coins like yours.

**Determine the Value:**

1. **Retail Replacement Value:** Based on your research, determine the retail replacement value of your 1913 Liberty Head nickel. This is the amount it would cost to replace your coin with a similar one in the current market.
2. **Actual Cash Value:** This value takes into account the coin's condition, rarity, and depreciation. It's the amount you could realistically sell the coin for in the current market.
3. **Agreed Value:** If you're insuring your coin, you may want to negotiate an agreed value with the insurer. This is the amount you and the insurer agree upon as the coin's value.

**Tips for Insuring Your Coin:**

1. **Provide Detailed Description:** When insuring your coin, provide a detailed description, including the coin's grade, serial number, and any unique features.
2. **Specify the Condition:** Accurately describe the coin's condition, including any flaws or defects, to ensure the insurer understands its value.
3. **Consider a Scheduled Policy:** A scheduled policy allows you to insure individual items, like your rare coin, with a more detailed description and valuation.
4. **Review and Update:** Regularly review your policy to ensure it remains adequate, and update the valuation as the coin's value changes over time.

By following these steps, you'll be able to determine a fair value for your rare 1913 Liberty Head nickel and ensure it's properly insured.

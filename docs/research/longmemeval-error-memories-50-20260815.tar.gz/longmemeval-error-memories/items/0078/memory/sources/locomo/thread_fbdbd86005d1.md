# thread_fbdbd86005d1

<a id="source-a9317b62d3024ac0"></a>
<!-- source-id:locomo/thread_fbdbd86005d1/msg_0c0fc9080af6 -->
[2023-05-26] user: A token bridge is a system that allows tokens to be transferred between different blockchain networks. When a user like Alice wants to move a token like Sol from one network like Solana to another network like Ethereum, the token bridge facilitates this transfer by creating a "proxy" token on the destination network that is pegged to the value of the original token.

For example, when Alice wants to move Sol from Solana to Ethereum, the token bridge will create a "Sol-Ethereum" token on the Ethereum network that is pegged to the value of Sol on the Solana network. Alice can then send her Sol to the token bridge, which will transfer the equivalent value of Sol-Ethereum to her Ethereum wallet.

The token bridge also ensures that the transfer of the token is atomic, meaning that either the entire transfer is completed or it is not completed at all. This ensures that there is no risk of Alice losing her Sol in the transfer process.

There are different ways that a token bridge can be implemented, depending on the specific requirements of the networks involved and the type of tokens being transferred. Some token bridges are built using smart contracts on the destination network, while others use a more centralized approach where the tokens are held in a "pool" and transferred manually by the operators of the token bridge.

<a id="source-1214c667b44f5d35"></a>
<!-- source-id:locomo/thread_fbdbd86005d1/msg_a5cccea5de98 -->
[2023-05-26] assistant: Token bridges are an important tool for enabling interoperability between different blockchain networks and enabling users to easily move their tokens between different networks. This can be useful in a variety of scenarios, such as when users want to take advantage of different features or services offered on different networks, or when they want to take advantage of different market opportunities.

In addition to facilitating the transfer of tokens between networks, token bridges can also be used to enable the transfer of other types of assets, such as non-fungible tokens (NFTs) or decentralized finance (DeFi) assets.

Overall, token bridges play a crucial role in enabling users to easily and securely move their assets between different blockchain networks, helping to increase the liquidity and utility of the entire ecosystem.

<a id="source-0a1411819a641c5c"></a>
<!-- source-id:locomo/thread_fbdbd86005d1/msg_4171fd7e8389 -->
[2023-05-26] user: "Sol-Ethereum" token is created by which system

<a id="source-5a14ebe3f35054a8"></a>
<!-- source-id:locomo/thread_fbdbd86005d1/msg_26febcb017ea -->
[2023-05-26] assistant: In the example you provided, the "Sol-Ethereum" token is created by the token bridge system as a proxy token on the Ethereum network. When a user like Alice wants to move Sol tokens from the Solana network to the Ethereum network, the token bridge creates a corresponding "Sol-Ethereum" token on the Ethereum network and transfers it to Alice's Ethereum wallet. This "Sol-Ethereum" token is pegged to the value of the original Sol token on the Solana network, meaning that it has the same value as the Sol token.

The process of creating the "Sol-Ethereum" token and transferring it to the user's Ethereum wallet is typically automated and managed by the token bridge system. The specifics of how this process is implemented can vary depending on the specific token bridge being used and the requirements of the networks involved.

<a id="source-b6e13ac4a1008240"></a>
<!-- source-id:locomo/thread_fbdbd86005d1/msg_cfb210aeae85 -->
[2023-05-26] user: Is it possible for the bridge to pair Sol with an already existing proxy currency on the receiving network

<a id="source-42ac36026ff09885"></a>
<!-- source-id:locomo/thread_fbdbd86005d1/msg_a06281ab3083 -->
[2023-05-26] assistant: It is possible for a token bridge to pair a token like Sol with an already existing proxy token on the receiving network, rather than creating a new proxy token. In this case, the token bridge would simply transfer the equivalent value of the already existing proxy token to the user's wallet on the receiving network, rather than creating a new proxy token.

For example, if there is already an "Sol-Ethereum" proxy token being used on the Ethereum network, the token bridge could transfer this proxy token to the user's Ethereum wallet rather than creating a new "Sol-Ethereum" token.

Whether or not a token bridge pairs a token with an existing proxy token or creates a new proxy token can depend on a variety of factors, including the specific implementation of the token bridge, the requirements of the networks involved, and the preferences of the users.

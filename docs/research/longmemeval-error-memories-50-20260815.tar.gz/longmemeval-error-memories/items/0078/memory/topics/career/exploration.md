The user has multiple diverse passions and is exploring how to merge them into a single career path rather than choosing just one focus, and is starting to research career options that incorporate their passions using resources such as LinkedIn, industry associations and professional organizations, job search websites, and informational interviews.[^e-7e4316b954][^e-5e55ae3201] ^8650c967 ^6dc8a91c

[^e-7e4316b954]: Time: `2023-05-21`; Sources: [locomo/thread_987adb9e3384/msg_49916e9f133b](../../sources/locomo/thread_987adb9e3384.md#source-3476c113605b1c56), [locomo/thread_987adb9e3384/msg_cedd23a82653](../../sources/locomo/thread_987adb9e3384.md#source-a01f1646c2b15630)

[^e-5e55ae3201]: Time: `2023-05-21`; Sources: [locomo/thread_987adb9e3384/msg_93ccddf82484](../../sources/locomo/thread_987adb9e3384.md#source-24da4a402bb04a09), [locomo/thread_987adb9e3384/msg_0b04854e2403](../../sources/locomo/thread_987adb9e3384.md#source-a4b3ffb1038e77f2)

The user asked the assistant to write an application to test a graphical AI made by Adobe; the drafted application positions the user as a graphic designer with several years of experience using Adobe software such as Photoshop, Illustrator, and InDesign.[^e-90f83627d7] ^52f1e5bf

[^e-90f83627d7]: Time: `2023-05-29`; Sources: [locomo/thread_d7ef2bcadc43/msg_6e7dcb803047](../../sources/locomo/thread_d7ef2bcadc43.md#source-d7e974963db3cfe9), [locomo/thread_d7ef2bcadc43/msg_195681a47156](../../sources/locomo/thread_d7ef2bcadc43.md#source-e152c1dd1f602451)

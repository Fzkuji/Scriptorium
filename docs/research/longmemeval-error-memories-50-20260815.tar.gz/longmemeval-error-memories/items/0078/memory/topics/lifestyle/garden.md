## Companion planting and permaculture

The user gardens and practices companion planting; the marigolds they planted near their tomatoes have been keeping nematodes away, and they harvested their first batch of tomatoes on 2023-05-22.[^e-fd6e55a985] ^18d73927

[^e-fd6e55a985]: Time: `2023-05-22`; Sources: [locomo/thread_749fa3152137/msg_a642c1a18f3f](../../sources/locomo/thread_749fa3152137.md#source-4163a2571ab0f5e7), [locomo/thread_749fa3152137/msg_6122171936cb](../../sources/locomo/thread_749fa3152137.md#source-0d783ebded5190c7)

The user attended a local permaculture workshop that inspired them to create a more sustainable garden, and they are planning a polyculture around their tomatoes using companion herbs and flowers such as basil, marigolds, oregano, and parsley.[^e-233b860484] ^86cd998c

[^e-233b860484]: Time: `2023-05-22`; Sources: [locomo/thread_749fa3152137/msg_0913bf8fc1b5](../../sources/locomo/thread_749fa3152137.md#source-c0d518f692b45fef), [locomo/thread_749fa3152137/msg_4536eecce9e8](../../sources/locomo/thread_749fa3152137.md#source-28639cf425bc392e), [locomo/thread_749fa3152137/msg_a4c530391d7b](../../sources/locomo/thread_749fa3152137.md#source-8b1d6903462f2310), [locomo/thread_749fa3152137/msg_389fd8353426](../../sources/locomo/thread_749fa3152137.md#source-a4be88521ed7e3fe)

## Pest control and soil fertility

The user is researching natural pest control methods beyond neem oil and companion planting, is considering adding carrots to the garden while concerned about carrot flies, and is interested in using compost tea to improve soil fertility.[^e-e2a74c95bc] ^51a98262

[^e-e2a74c95bc]: Time: `2023-05-22`; Sources: [locomo/thread_749fa3152137/msg_c88501022bd8](../../sources/locomo/thread_749fa3152137.md#source-a1367db7ea2ffd30), [locomo/thread_749fa3152137/msg_a0fdefbb25d7](../../sources/locomo/thread_749fa3152137.md#source-9305f94c7e7b42b2), [locomo/thread_749fa3152137/msg_4d533b6188b6](../../sources/locomo/thread_749fa3152137.md#source-2261945359ac6c8b), [locomo/thread_749fa3152137/msg_16db1c60e078](../../sources/locomo/thread_749fa3152137.md#source-3a296cc6891580d1), [locomo/thread_749fa3152137/msg_5874bcc16857](../../sources/locomo/thread_749fa3152137.md#source-d341808becf35c40)

The user is dealing with a snail problem and an aphid problem in their garden and plans to try a beer trap for the snails and a soap-and-water spray for the aphids, while also checking the trap regularly to avoid attracting other pests.[^e-f49348786a] ^3d6b73a0

[^e-f49348786a]: Time: `2023-05-27`; Sources: [locomo/thread_6058016e3a4c/msg_99a3ef0c65e6](../../sources/locomo/thread_6058016e3a4c.md#source-e8338506550cff6e), [locomo/thread_6058016e3a4c/msg_972e74206ba7](../../sources/locomo/thread_6058016e3a4c.md#source-54d8abcfbeb69e44), [locomo/thread_6058016e3a4c/msg_f8c34a4d49e7](../../sources/locomo/thread_6058016e3a4c.md#source-69ee0684dbb21527)

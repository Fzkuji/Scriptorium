The user owns a wireless mouse that they have had since 2018, which now has intermittent connectivity issues and declining battery life, so they are considering replacing it.[^e-38e350d8fc] ^ee4bb1af

[^e-38e350d8fc]: Time: `2023-05-21`; Sources: [locomo/thread_f4407b5e69a3/msg_b7e48307cffc](../../sources/locomo/thread_f4407b5e69a3.md#source-feeae438fd5ea0c5)

The user performed maintenance on their desktop computer on 2023-02-01, which improved its performance.[^e-0c6e13903d] ^ea96b8a8

[^e-0c6e13903d]: Time: `2023-02-01`; Sources: [locomo/thread_f4407b5e69a3/msg_b7e48307cffc](../../sources/locomo/thread_f4407b5e69a3.md#source-feeae438fd5ea0c5), [locomo/thread_f4407b5e69a3/msg_98493d57f0de](../../sources/locomo/thread_f4407b5e69a3.md#source-30df1c1628335d2d)

The user visited an electronics store on 2023-01-25 to shop for a new monitor but did not buy one because they could not decide between two models; after installing a new graphics card on 2023-02-10, they are now leaning towards buying a monitor with a higher refresh rate, such as 144Hz, with G-Sync or FreeSync support.[^e-2cd951dc84][^e-83768386b6] ^c055475e ^435a459c

[^e-2cd951dc84]: Time: `2023-01-25`; Sources: [locomo/thread_f4407b5e69a3/msg_255d528a32f4](../../sources/locomo/thread_f4407b5e69a3.md#source-32adf334dc723fa7)

[^e-83768386b6]: Time: `2023-02-10`; Sources: [locomo/thread_f4407b5e69a3/msg_e1bb2f87354c](../../sources/locomo/thread_f4407b5e69a3.md#source-11958cf40bbc4e48), [locomo/thread_f4407b5e69a3/msg_98493d57f0de](../../sources/locomo/thread_f4407b5e69a3.md#source-30df1c1628335d2d), [locomo/thread_f4407b5e69a3/msg_af2ba6f017d5](../../sources/locomo/thread_f4407b5e69a3.md#source-f29da36a5425b668)

The user is considering upgrading their laptop backpack, which they have used daily since it arrived from Amazon on 2023-01-20.[^e-9c9448f240] ^8babb58e

[^e-9c9448f240]: Time: `2023-01-20`; Sources: [locomo/thread_f4407b5e69a3/msg_4c55976ef78e](../../sources/locomo/thread_f4407b5e69a3.md#source-5c9eed9aa4fa74fa)

The user created a new folder structure and moved their work documents to the cloud on 2023-02-05, freeing up space on their hard drive, and is looking for tips on managing passwords securely.[^e-50d8de0b76] ^fd53ffa7

[^e-50d8de0b76]: Time: `2023-02-05`; Sources: [locomo/thread_f4407b5e69a3/msg_3c6f6cbb4613](../../sources/locomo/thread_f4407b5e69a3.md#source-f0f7d5b0d1420a9b), [locomo/thread_f4407b5e69a3/msg_09e2e3ff715f](../../sources/locomo/thread_f4407b5e69a3.md#source-c08f618f0eac3e4b)

The user was troubleshooting a Remote Desktop connection to a remote system running Windows Server 2019, where they encountered a "CredSSP encryption oracle not available" error, and they were also checking their system's support for Network Level Authentication and setting up LDAPS using an existing domain-joined certificate authority.[^e-76acfd1ab2] ^4b425349

[^e-76acfd1ab2]: Time: `2023-05-22`; Sources: [locomo/thread_046276ceb02b/msg_b0cb1f83cf72](../../sources/locomo/thread_046276ceb02b.md#source-6da09263999e405b), [locomo/thread_046276ceb02b/msg_0d4316fe0a8a](../../sources/locomo/thread_046276ceb02b.md#source-b9427965157a5530), [locomo/thread_046276ceb02b/msg_0be0c293ed18](../../sources/locomo/thread_046276ceb02b.md#source-3a50f1f61ff6b9f6), [locomo/thread_046276ceb02b/msg_d1e1e628164b](../../sources/locomo/thread_046276ceb02b.md#source-8ab6bae49c1141ca), [locomo/thread_046276ceb02b/msg_7e9ce10ee2d8](../../sources/locomo/thread_046276ceb02b.md#source-a7b4f517fe8d8165)

The user enjoys crafting handmade gifts and, although they liked the idea of making hand-painted candles, they wanted to try something new and started exploring wire wrapping and jewelry making.[^e-b29778e749] ^dd1daf6d

[^e-b29778e749]: Time: `2023-05-25`; Sources: [locomo/thread_ae05743e8c30/msg_75b0901b5e08](../../sources/locomo/thread_ae05743e8c30.md#source-bd51d9a5b7c04394)

The user has already taken a class on wire wrapping and is now looking to try new techniques, particularly making pendants and charms, and is interested in trying a filigree pendant tutorial.[^e-d11b81ce9d] ^a8aecd34

[^e-d11b81ce9d]: Time: `2023-05-25`; Sources: [locomo/thread_ae05743e8c30/msg_b9d247ef4b89](../../sources/locomo/thread_ae05743e8c30.md#source-366dfbcb6e6164fd), [locomo/thread_ae05743e8c30/msg_5e9fb1d6c167](../../sources/locomo/thread_ae05743e8c30.md#source-d962808116fbdc35)

The user has 20 gauge copper wire left over from other projects and plans to try the filigree pendant project with it, ordering finer gauge (28-30 gauge) wire online if the thicker wire does not work out.[^e-92bfa3f05b] ^4a7341c0

[^e-92bfa3f05b]: Time: `2023-05-25`; Sources: [locomo/thread_ae05743e8c30/msg_b7eab86cb12c](../../sources/locomo/thread_ae05743e8c30.md#source-7d4f7f031f0f4a99), [locomo/thread_ae05743e8c30/msg_9cda50b293fe](../../sources/locomo/thread_ae05743e8c30.md#source-d9fa78ea70a6f1df)

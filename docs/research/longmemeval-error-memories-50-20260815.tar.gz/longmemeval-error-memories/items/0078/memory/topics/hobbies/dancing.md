The user has been dancing salsa for a few months, having started with a 5-week beginner class at DanceFever studio, and is now hooked; they look for salsa music to practice to at home.[^e-05e2374604][^e-f8af262704] ^9c8048c5

[^e-05e2374604]: Time: `2023`; Sources: [locomo/thread_22a07b103833/msg_ced81efbac89](../../sources/locomo/thread_22a07b103833.md#source-a932703ce1aaf392)

[^e-f8af262704]: Time: `2023-05-25`; Sources: [locomo/thread_22a07b103833/msg_9da1bd635b0c](../../sources/locomo/thread_22a07b103833.md#source-d42095b57ab716fd)

The user loves the energy of salsa dancing and the feeling of accomplishment when mastering a new move, and enjoys the social aspect of meeting new people and making friends; their biggest challenge is leading and following, connecting with a partner and anticipating their movements.[^e-ab4eb80a79] ^9779e1ab

[^e-ab4eb80a79]: Time: `2023-05-25`; Sources: [locomo/thread_22a07b103833/msg_782213106cdb](../../sources/locomo/thread_22a07b103833.md#source-db0016aa9b41fc7e), [locomo/thread_22a07b103833/msg_9e635e66f55b](../../sources/locomo/thread_22a07b103833.md#source-69b40aca959dfda8)

The user has danced with several different people at the social dance nights at DanceFever and finds practicing with different partners very helpful, because you can learn a lot from each other.[^e-84f7f66849] ^31f27215

[^e-84f7f66849]: Time: `2023-05-25`; Sources: [locomo/thread_22a07b103833/msg_24d2799c070f](../../sources/locomo/thread_22a07b103833.md#source-2bc45866ec920d5f)

The user has learned that the most valuable thing about dancing with different partners is the importance of connection and communication between partners — it is not just about the steps — and that focusing on this has made them a more aware and responsive dancer who has improved their timing and overall dance quality.[^e-361602744b] ^84c76c03

[^e-361602744b]: Time: `2023-05-25`; Sources: [locomo/thread_22a07b103833/msg_2bc824d8b759](../../sources/locomo/thread_22a07b103833.md#source-4d0cd054857164cd)

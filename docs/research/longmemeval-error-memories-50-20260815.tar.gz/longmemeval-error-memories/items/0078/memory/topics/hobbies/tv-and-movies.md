## TV shows

The user recently finished the latest season of Stranger Things and has been binge-watching movies, including finishing all the Marvel movies in one sitting.[^e-4d2f278b2a] ^eb299097

[^e-4d2f278b2a]: Time: `2023-05-27`; Sources: [locomo/thread_4c22fc1ada7e/msg_f204f7793441](../../sources/locomo/thread_4c22fc1ada7e.md#source-8cb8a421e0b22842), [locomo/thread_4c22fc1ada7e/msg_aff81df7e757](../../sources/locomo/thread_4c22fc1ada7e.md#source-85ac2810a5e43610)

The user is watching The Witcher, currently on episode 5, and enjoys the world-building, monsters, and magic system and Henry Cavill's performance as Geralt, but finds the non-linear storytelling a bit confusing; they are particularly interested in the characters Ciri and Yennefer.[^e-7f936acd84] ^62b016bc

[^e-7f936acd84]: Time: `2023-05-27`; Sources: [locomo/thread_4c22fc1ada7e/msg_d1d21bdff54b](../../sources/locomo/thread_4c22fc1ada7e.md#source-d36b4f4b5e31ed22), [locomo/thread_4c22fc1ada7e/msg_05e8ee0a2b46](../../sources/locomo/thread_4c22fc1ada7e.md#source-0b45a5bc5531b50b), [locomo/thread_4c22fc1ada7e/msg_a51f16341614](../../sources/locomo/thread_4c22fc1ada7e.md#source-856fc692ef312216)

## Movies and film

The user rewatched The Shawshank Redemption, which is one of their favorite films, and resonates with its themes of hope, resilience, and freedom, especially the scene where Red steps out into the sunlight after parole and the quote "Get busy living or get busy dying."[^e-2002613a3c] ^8e003292

[^e-2002613a3c]: Time: `2023-05-27`; Sources: [locomo/thread_4c22fc1ada7e/msg_a51f16341614](../../sources/locomo/thread_4c22fc1ada7e.md#source-856fc692ef312216), [locomo/thread_4c22fc1ada7e/msg_3e783a257c9d](../../sources/locomo/thread_4c22fc1ada7e.md#source-fbad34d9cd97c871)

The user discussed how lighting shapes the emotional tone of films, asking the assistant to analyze "The Silent Killer" and learning how lighting is used in films such as The Shawshank Redemption (light representing hope), The Godfather (low-key lighting for tension), The Revenant (natural light), The Dark Knight (blue and white for Batman, red-orange for the Joker), Blade Runner (neon), Schindler's List (black-and-white), There Will Be Blood (bleak natural and artificial light), and Mad Max: Fury Road (vivid, colorful lighting).[^e-b35576d17c] ^0e7d7ecf

[^e-b35576d17c]: Time: `2023-05-28`; Sources: [locomo/thread_11649ff00661/msg_fa33c423b85d](../../sources/locomo/thread_11649ff00661.md#source-adf8258a99573ce4), [locomo/thread_11649ff00661/msg_db552290c7f9](../../sources/locomo/thread_11649ff00661.md#source-9a133750826267d0), [locomo/thread_11649ff00661/msg_5719efb4dc9a](../../sources/locomo/thread_11649ff00661.md#source-bcb9ae2b1450f422)

The user bought a bottle of truffle oil from Trader Joe's during a trip there with their sister, on which they spent around $80 on specialty items, and was looking for recipe ideas using the truffle oil; they are also interested in making homemade pasta sauce and canning it.[^e-1833729377][^e-447235256c][^e-fccf06d26f] ^3712e53d ^f031a800

[^e-1833729377]: Time: `2023-05`; Sources: [locomo/thread_aaa7a92208f6/msg_8b3dc879fb94](../../sources/locomo/thread_aaa7a92208f6.md#source-102bf208edd54a78)

[^e-447235256c]: Time: `2023-05-23`; Sources: [locomo/thread_aaa7a92208f6/msg_8b3dc879fb94](../../sources/locomo/thread_aaa7a92208f6.md#source-102bf208edd54a78), [locomo/thread_aaa7a92208f6/msg_f6fae4c00dfe](../../sources/locomo/thread_aaa7a92208f6.md#source-44823ba473b45d8c), [locomo/thread_aaa7a92208f6/msg_d775b76e59a0](../../sources/locomo/thread_aaa7a92208f6.md#source-00354b3efdd90ed0)

[^e-fccf06d26f]: Time: `2023-05-23`; Sources: [locomo/thread_aaa7a92208f6/msg_7a87c69c4444](../../sources/locomo/thread_aaa7a92208f6.md#source-55b06a2c50f7bdbd)

The user is meal planning and making a grocery list before going to the store to help cut down on grocery spending, and on 2023-05-21 they went to Walmart and spent around $120 on food and household items.[^e-63cf773dc2] ^65129834

[^e-63cf773dc2]: Time: `2023-05-21`; Sources: [locomo/thread_aaa7a92208f6/msg_47a8a6a34e5a](../../sources/locomo/thread_aaa7a92208f6.md#source-2ebd1848184c96fa)

The user is trying to reduce food waste by using up leftovers and planning meals around what they already have in the fridge and pantry; last week they made a big pot of chili, froze it, and ate it for lunch and dinner throughout the week.[^e-c9473336e3] ^0bde0577

[^e-c9473336e3]: Time: `2023-05`; Sources: [locomo/thread_aaa7a92208f6/msg_75ad9734e141](../../sources/locomo/thread_aaa7a92208f6.md#source-cbfd99d1cd502542)

The user is interested in trying new recipes, especially vegan ones, and recently discovered a recipe for vegan sushi that they are eager to try.[^e-4bda7bfbd5] ^46ab3bd0

[^e-4bda7bfbd5]: Time: `2023-05-23`; Sources: [locomo/thread_aaa7a92208f6/msg_b3397aecbed5](../../sources/locomo/thread_aaa7a92208f6.md#source-ee22dda4d2930c63)

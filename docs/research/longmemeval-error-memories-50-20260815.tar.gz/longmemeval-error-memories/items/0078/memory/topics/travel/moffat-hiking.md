The user is planning a hiking trip to Moffat, Scotland, and researched the area's trails and parks, including Moffat Hills, Grey Mare's Tail Nature Reserve, Devil's Beef Tub, Ae Forest, and Galloway Forest Park; as a beginner hiker they plan to hike the Grey Mare's Tail waterfall trail, a 2.5-mile round trip with a well-maintained path.[^e-896743b773][^e-1eed18e3cf] ^a2223a4a

[^e-896743b773]: Time: `2023-05-30`; Sources: [locomo/thread_8e09fa96d2c5/msg_3323362a8a5e](../../sources/locomo/thread_8e09fa96d2c5.md#source-edbc4ca6bb5825f4), [locomo/thread_8e09fa96d2c5/msg_d3ad161308d4](../../sources/locomo/thread_8e09fa96d2c5.md#source-bdb3dd1095060f93)

[^e-1eed18e3cf]: Time: `2023-05-30`; Sources: [locomo/thread_8e09fa96d2c5/msg_006e4345eb8a](../../sources/locomo/thread_8e09fa96d2c5.md#source-f86b62f3a861ffd3), [locomo/thread_8e09fa96d2c5/msg_68d0795c5da3](../../sources/locomo/thread_8e09fa96d2c5.md#source-c7d24e8199b8f6a6)

The user asked about essential hiking gear and is considering bringing a tent for a multi-day stay in Moffat; concerned about encountering wild animals like bears and wolves or getting lost, they also asked about guided tours and group hikes in the area.[^e-604d5b5899][^e-08adde2c82] ^4c79a93b

[^e-604d5b5899]: Time: `2023-05-30`; Sources: [locomo/thread_8e09fa96d2c5/msg_209429f755d5](../../sources/locomo/thread_8e09fa96d2c5.md#source-b901c33c76a87237), [locomo/thread_8e09fa96d2c5/msg_d63bc99e91a0](../../sources/locomo/thread_8e09fa96d2c5.md#source-f0d147537cc515d4), [locomo/thread_8e09fa96d2c5/msg_36357bc96c67](../../sources/locomo/thread_8e09fa96d2c5.md#source-d0271dac8a46d0c4), [locomo/thread_8e09fa96d2c5/msg_2f715d57183d](../../sources/locomo/thread_8e09fa96d2c5.md#source-07c5e896e1a9d5f2)

[^e-08adde2c82]: Time: `2023-05-30`; Sources: [locomo/thread_8e09fa96d2c5/msg_ac4bd357006a](../../sources/locomo/thread_8e09fa96d2c5.md#source-3d2b130bd769ed39), [locomo/thread_8e09fa96d2c5/msg_560c16f64bf2](../../sources/locomo/thread_8e09fa96d2c5.md#source-1055d40489424e28)

The user likes to stay connected even when out in nature and asked whether the Moffat hiking trails have Wi-Fi or cell service.[^e-a1841a853f] ^c0b28d04

[^e-a1841a853f]: Time: `2023-05-30`; Sources: [locomo/thread_8e09fa96d2c5/msg_d45651134911](../../sources/locomo/thread_8e09fa96d2c5.md#source-b3c159439f63a78c), [locomo/thread_8e09fa96d2c5/msg_676bc494290b](../../sources/locomo/thread_8e09fa96d2c5.md#source-73d94ea73e31824f)

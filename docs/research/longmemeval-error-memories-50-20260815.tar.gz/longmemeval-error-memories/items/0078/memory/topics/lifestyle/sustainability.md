## Eco-friendly products and habits

The user is making a conscious effort to switch to eco-friendly products in their daily life and is reducing their use of single-use plastics, bringing reusable bags and containers to the store with them.[^e-f512c15daa][^e-67a410a6c0] ^8e56c3b1

[^e-f512c15daa]: Time: `2023-05-23`; Sources: [locomo/thread_aaa7a92208f6/msg_3b8e306169b8](../../sources/locomo/thread_aaa7a92208f6.md#source-6f360b8fd76a3e9f)

[^e-67a410a6c0]: Time: `2023-05-24`; Sources: [locomo/thread_01ea86c3d49e/msg_71e26acb8c06](../../sources/locomo/thread_01ea86c3d49e.md#source-1408496e554a6289)

The user is interested in trying Goddess Garden Organics Everyday Natural Sunscreen, a reef-safe mineral sunscreen, for their [upcoming beach trip](../travel/beach-trip.md#^2dd28bc1).[^e-49e7fbedb9] ^4b8d3d6c

[^e-49e7fbedb9]: Time: `2023-05-24`; Sources: [locomo/thread_01ea86c3d49e/msg_099b87789e90](../../sources/locomo/thread_01ea86c3d49e.md#source-9753659f08da0f61), [locomo/thread_01ea86c3d49e/msg_2f041590d6d6](../../sources/locomo/thread_01ea86c3d49e.md#source-ccbbd07326267011)

The user currently uses the Night Bloom moisturizer from Seedling and is comparing Goddess Garden Organics' Everyday Natural Moisturizer and Facial Serum against it; the Facial Serum is recommended for mature, dry, sensitive, and combination skin but may be too rich for oily or acne-prone skin.[^e-9871500c92] ^a419bff3

[^e-9871500c92]: Time: `2023-05-24`; Sources: [locomo/thread_01ea86c3d49e/msg_9b96d338f175](../../sources/locomo/thread_01ea86c3d49e.md#source-99ffec8bc9ba20ae), [locomo/thread_01ea86c3d49e/msg_e7e524d0b642](../../sources/locomo/thread_01ea86c3d49e.md#source-eef94db99f377467)

Goddess Garden Organics offers a Refill Pouch program for its sunscreen that reduces waste by up to 70%, uses recyclable and bioplastic packaging, aims to make all its packaging recyclable, reusable, or biodegradable by 2025, and is exploring extending the refill program to other products like moisturizers and serums.[^e-ada8e11389] ^b1bd1623

[^e-ada8e11389]: Time: `2023-05-24`; Sources: [locomo/thread_01ea86c3d49e/msg_38308d4cbd48](../../sources/locomo/thread_01ea86c3d49e.md#source-0817bfdeaae8ee78), [locomo/thread_01ea86c3d49e/msg_ac620abc2e9b](../../sources/locomo/thread_01ea86c3d49e.md#source-53c9562aa914398e), [locomo/thread_01ea86c3d49e/msg_738dbffe998f](../../sources/locomo/thread_01ea86c3d49e.md#source-20ec611000f921f5)

## Carbon footprint at home

The user is interested in reducing their carbon footprint at home and has been researching tips such as reducing energy and water consumption, reducing waste, using eco-friendly products, and eating less meat; related research covers [big data and analytics in transportation and logistics](../learning/data-and-sustainability.md#^26e476aa).[^e-2d2d8271e5] ^737e1c95

[^e-2d2d8271e5]: Time: `2023-05-27`; Sources: [locomo/thread_e75d517f7f0b/msg_0b0eb7d6844d](../../sources/locomo/thread_e75d517f7f0b.md#source-8e230d3f1517c473), [locomo/thread_e75d517f7f0b/msg_4db7488a6ae7](../../sources/locomo/thread_e75d517f7f0b.md#source-9e0a2b273807e2a6)

## Sustainable fashion

The user learned about the environmental impact of the fashion industry, including water pollution, roughly 10% of global greenhouse gas emissions, textile waste (with the average American generating 82 pounds of textile waste per year), resource depletion, and deforestation, along with sustainable fashion choices such as buying second-hand, investing in quality, choosing sustainable fabrics, renting or sharing clothing, supporting sustainable brands, repairing and upcycling, and buying local.[^e-d12289935d] ^3d3b4f00

[^e-d12289935d]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_d93aadd0ee10](../../sources/locomo/thread_b6fdc3c2643b.md#source-1e351e33f451c229)

The user learned about organic cotton, which is grown without toxic pesticides, synthetic fertilizers, or GMOs, conserves water, promotes soil health and biodiversity, and benefits farmers, compared to conventional cotton that uses approximately 16% of the world's insecticides and 7% of pesticides; they also learned to look for certifications such as GOTS, OCS, and Fairtrade.[^e-b53301a078] ^67d14664

[^e-b53301a078]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_4c7b63adf7ef](../../sources/locomo/thread_b6fdc3c2643b.md#source-1cd60bba8b0e24ef)

The user learned about clothing recycling (mechanical, chemical, and biological) and upcycling (repairing, refashioning, and reinventing), and about how fashion brands incorporate sustainability through materials like organic cotton, recycled polyester, Tencel, hemp, and upcycled fabrics, production methods like zero-waste design, 3D design, digital printing, and supply chain transparency, certifications like GOTS, Oeko-Tex, Fairtrade, B Corp, and Bluesign, and leading brands like Patagonia, Reformation, Everlane, H&M Conscious, and Outerknown.[^e-c30e50284a] ^7c3a333e

[^e-c30e50284a]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_fb9801ef5199](../../sources/locomo/thread_b6fdc3c2643b.md#source-a339acf14e66c4e5), [locomo/thread_b6fdc3c2643b/msg_97a142d92e39](../../sources/locomo/thread_b6fdc3c2643b.md#source-e970f583b2f37866)

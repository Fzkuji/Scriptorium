The user is building a detailed model kit that they bought online from an online retailer, which makes it harder to get help from store staff, and sorting through the parts and instructions on the first day felt overwhelming.[^e-9948c52ce7] ^08c1c395

[^e-9948c52ce7]: Time: `2023-05-25`; Sources: [locomo/thread_774d07d5ad9c/msg_08c63977e8e1](../../sources/locomo/thread_774d07d5ad9c.md#source-264373bbfefa777e), [locomo/thread_774d07d5ad9c/msg_51a5be8b8d8c](../../sources/locomo/thread_774d07d5ad9c.md#source-5b5a4935764b3ff1)

While gluing the hull of their model kit, the user applied too much glue, which caused the parts to shift and left a gap between two sections of the hull that they were unsure how to fix.[^e-9023620fcd] ^717234b4

[^e-9023620fcd]: Time: `2023-05-25`; Sources: [locomo/thread_774d07d5ad9c/msg_944c6a38b2b8](../../sources/locomo/thread_774d07d5ad9c.md#source-38a1f003cc5db977)

The user is planning to build a futuristic spaceship model next and has been researching designs on a concept art website, looking for recommendations for sci-fi model kits.[^e-2dd9f551a0] ^0bb40733

[^e-2dd9f551a0]: Time: `2023-05-25`; Sources: [locomo/thread_774d07d5ad9c/msg_106297cc6efc](../../sources/locomo/thread_774d07d5ad9c.md#source-b39d9572aa62d17f), [locomo/thread_774d07d5ad9c/msg_16a6e5b4e518](../../sources/locomo/thread_774d07d5ad9c.md#source-cd771816470fc17f)

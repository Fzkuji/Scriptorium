The user recently changed their legal name; the court approved their application on 2023-01-15, the hearing was held on 2023-01-25, and they received their new Social Security card with the updated name on 2023-02-22.[^e-6f1ccd9da3] ^dd684d8a

[^e-6f1ccd9da3]: Time: `2023-02-22`; Sources: [locomo/thread_6bc2090ac4de/msg_f8754e93bfdc](../../sources/locomo/thread_6bc2090ac4de.md#source-dee9d2afa1a5912e)

The user has already updated their name with the Social Security Administration and is now working on updating their address with the US Postal Service using Form PS 3575.[^e-093d155d06] ^356b8641

[^e-093d155d06]: Time: `2023-05-20`; Sources: [locomo/thread_6bc2090ac4de/msg_f8754e93bfdc](../../sources/locomo/thread_6bc2090ac4de.md#source-dee9d2afa1a5912e)

The user plans to upload their court approval letter as an additional document in the USPS change of address application.[^e-c6528f4949][^e-462140a695] ^3cf2115b

[^e-c6528f4949]: Time: `2023-05-20`; Sources: [locomo/thread_6bc2090ac4de/msg_2719e25a26a0](../../sources/locomo/thread_6bc2090ac4de.md#source-3dd95118165ede9d)

[^e-462140a695]: Time: `2023-05-20`; Sources: [locomo/thread_6bc2090ac4de/msg_077b9fd33521](../../sources/locomo/thread_6bc2090ac4de.md#source-38b226a6cc202564)

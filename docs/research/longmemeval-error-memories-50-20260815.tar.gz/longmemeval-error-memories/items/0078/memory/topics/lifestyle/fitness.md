The user rejoined their old gym in April 2023 and is getting into a regular exercise routine, seeking tips on staying motivated and avoiding burnout.[^e-8034a76aae] ^c8179e06

[^e-8034a76aae]: Time: `2023-04`; Sources: [locomo/thread_7a2d72a9009a/msg_b2abf303cfe7](../../sources/locomo/thread_7a2d72a9009a.md#source-73f5889a2d354328)

The user has been incorporating more walking into their daily routine and has discovered new parks and hidden cafes in their neighborhood.[^e-9ca48a330d] ^6487b5d2

[^e-9ca48a330d]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_733c22d0826c](../../sources/locomo/thread_7a2d72a9009a.md#source-80f4b4db0c7b2c23)

The user has been tracking their sleep with a fitness tracker and is getting 7-8 hours a night, within their target range; they do cardio such as jogging and cycling plus bodyweight strength training, and have set goals of 150 minutes of moderate-intensity exercise per week (increasing by 30 minutes each month) and strength training at least 3 times a week, planning to track progress with their fitness tracker, a workout journal, and progress photos and measurements every 4-6 weeks.[^e-eb4e14e618] ^2f0f7f9c

[^e-eb4e14e618]: Time: `2023-05-28`; Sources: [locomo/thread_d5369eec43f1/msg_f4c416079023](../../sources/locomo/thread_d5369eec43f1.md#source-ee51e609c80a9198), [locomo/thread_d5369eec43f1/msg_0c02aad8863e](../../sources/locomo/thread_d5369eec43f1.md#source-14684dae2d2281d3), [locomo/thread_d5369eec43f1/msg_df6584837c48](../../sources/locomo/thread_d5369eec43f1.md#source-30508f9f81cde9ff), [locomo/thread_d5369eec43f1/msg_6b55410d165d](../../sources/locomo/thread_d5369eec43f1.md#source-176b1f755c5f652d), [locomo/thread_d5369eec43f1/msg_4f71a4f51c09](../../sources/locomo/thread_d5369eec43f1.md#source-7e0df69b2f157915)

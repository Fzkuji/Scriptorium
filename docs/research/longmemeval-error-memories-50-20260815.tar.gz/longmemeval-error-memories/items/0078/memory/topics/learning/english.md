The user started taking English language classes in May 2023 and wants to practice outside of class using language learning apps and online resources.[^e-843d16a659] ^c998e765

[^e-843d16a659]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_15bbcc24f91f](../../sources/locomo/thread_37d993f7a9d6.md#source-3f1bc7ce207d5335)

The user is interested in the BBC Learning English website, especially the Elementary Level lessons covering basic grammar and vocabulary for beginners.[^e-ec32933a65] ^ae155e11

[^e-ec32933a65]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_04860fb00bc9](../../sources/locomo/thread_37d993f7a9d6.md#source-9d8894722f733153), [locomo/thread_37d993f7a9d6/msg_dfde6a0693d2](../../sources/locomo/thread_37d993f7a9d6.md#source-6069515421af360a)

The user plans to participate in the BBC Learning English discussion forums to practice their writing and reading skills and to get feedback from the community.[^e-a6234eb286] ^860a9a2c

[^e-a6234eb286]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_2f9b37f3c2b3](../../sources/locomo/thread_37d993f7a9d6.md#source-8339b8d33ddcc0d0)

The user is excited to start practicing with a language exchange partner and plans to look for one through resources such as the BBC forums and language exchange apps.[^e-5c01cdaea2] ^1ea06282

[^e-5c01cdaea2]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_34fa12ce3947](../../sources/locomo/thread_37d993f7a9d6.md#source-eae59293bb940b5e)

The user practiced their English writing by having the assistant improve a passage they wrote and then explain the changes, learning to use active voice, contractions, simpler words like "used" instead of "utilized", added specific details, and "I" instead of "me" when referring to oneself.[^e-6c09fae3d7] ^d20a54e8

[^e-6c09fae3d7]: Time: `2023-05-29`; Sources: [locomo/thread_0e19af4ae30e/msg_baccc5682ef9](../../sources/locomo/thread_0e19af4ae30e.md#source-a0c38c5ca7073aac), [locomo/thread_0e19af4ae30e/msg_73d77f622cfc](../../sources/locomo/thread_0e19af4ae30e.md#source-712b4ea500f8d660)

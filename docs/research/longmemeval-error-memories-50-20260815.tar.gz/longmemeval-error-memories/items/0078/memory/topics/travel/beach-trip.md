The user is planning an upcoming beach trip and is looking for an eco-friendly, reef-safe sunscreen to take with them, and has been researching [Goddess Garden Organics Everyday Natural Sunscreen](../lifestyle/sustainability.md#^4b8d3d6c).[^e-bac618fb31] ^2dd28bc1

[^e-bac618fb31]: Time: `2023-05-24`; Sources: [locomo/thread_01ea86c3d49e/msg_099b87789e90](../../sources/locomo/thread_01ea86c3d49e.md#source-9753659f08da0f61)

The user is a web developer and is planning to build a Coaching for Profit (CFP) Management System SaaS that any poker coaching business could use to manage their business, and has been researching what features to incorporate.[^e-3e5387ea40] ^99ed0882

[^e-3e5387ea40]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_5cc39f69fb27](../../sources/locomo/thread_023f8650f638.md#source-065a44001a08aed1)

The user had lunch with their friend Rachel at a new restaurant on 2023-05-19 (a Friday), where they met a man named Mike at the next table, exchanged numbers, and were invited to a party at his place the following weekend (see [party plans](../lifestyle/entertaining.md#^73fe3791)).[^e-dbc2020fa4] ^93371488

[^e-dbc2020fa4]: Time: `2023-05-19`; Sources: [locomo/thread_bb376441501c/msg_ff4264064f14](../../sources/locomo/thread_bb376441501c.md#source-7e33fd17b92c937a), [locomo/thread_bb376441501c/msg_b336ce7c40ad](../../sources/locomo/thread_bb376441501c.md#source-520911356138312f)

The user has a friend named Michael who had to cancel a planned meetup at the last minute the previous week, and the user wants to reach out and reschedule.[^e-886996de17] ^51003be9

[^e-886996de17]: Time: `2023-05-21`; Sources: [locomo/thread_bb376441501c/msg_00f465059b48](../../sources/locomo/thread_bb376441501c.md#source-f321809c2ad2a8d1)

The user's cousin Rachel got married a few weeks ago, and the user was part of the group of attendants who helped the bride Rachel get ready for her ceremony.[^e-02d58f3940] ^d6a20d86

[^e-02d58f3940]: Time: `2023-04`; Sources: [locomo/thread_6e5fb66a8677/msg_08f7475963fc](../../sources/locomo/thread_6e5fb66a8677.md#source-2059ace6acacdfb8)

The user's friend Emily married Alex a few weeks ago; the user was unable to attend because their cousin's wedding was on the same weekend.[^e-c91c45ec8a] ^5e41c9f0

[^e-c91c45ec8a]: Time: `2023-04`; Sources: [locomo/thread_6e5fb66a8677/msg_08f7475963fc](../../sources/locomo/thread_6e5fb66a8677.md#source-2059ace6acacdfb8)

The user is sending a congratulatory card for Emily and Alex's wedding and chose Paperless Post as the online store, planning to personalize the message by mentioning how happy they are that Emily found her partner in Alex after the ups and downs of her past relationships.[^e-3b7384b5af] ^3b16f751

[^e-3b7384b5af]: Time: `2023-05-24`; Sources: [locomo/thread_6e5fb66a8677/msg_88ea2a72357e](../../sources/locomo/thread_6e5fb66a8677.md#source-3ab9d49353290d8d), [locomo/thread_6e5fb66a8677/msg_ecc74d9a0ecf](../../sources/locomo/thread_6e5fb66a8677.md#source-0101ef3aa2d582ee), [locomo/thread_6e5fb66a8677/msg_0d0337d3fde6](../../sources/locomo/thread_6e5fb66a8677.md#source-2453286123c71556)

The user is also considering sending a unique and thoughtful wedding gift to Emily and Alex.[^e-7a43333afe] ^10b9b7c2

[^e-7a43333afe]: Time: `2023-05-24`; Sources: [locomo/thread_6e5fb66a8677/msg_cfa40338e702](../../sources/locomo/thread_6e5fb66a8677.md#source-d3b430494dc9ca8b)

The user is developing a zombie-apocalypse video game structured around a prologue and three timeline paths, and wants the game's maps presented so that it stays ambiguous which events belong to which timeline until players piece together all the clues.[^e-03e53ac498] ^9cce9494

[^e-03e53ac498]: Time: `2023-05-23`; Sources: [locomo/thread_810c4bac6d0f/msg_8f5a57d42cbb](../../sources/locomo/thread_810c4bac6d0f.md#source-d1cf887ca1af8bc8), [locomo/thread_810c4bac6d0f/msg_4a55570ce418](../../sources/locomo/thread_810c4bac6d0f.md#source-8e61581360f85f5e)

In the game's darkest timeline (Path 3), Marcus's stray bullet kills Dr. Penelope, Surgey responds by killing Marcus and the shocked Jillian and then flees, the outbreak from the lab goes uncontained and spreads through the Americas, and later a deranged Surgey manipulates a group of bunker survivors into carpet-bombing a "safe" border with parasite-filled bombs aimed at the USSR, ending in global apocalypse.[^e-2690561058] ^a55503ce

[^e-2690561058]: Time: `2023-05-23`; Sources: [locomo/thread_810c4bac6d0f/msg_40ebc5271110](../../sources/locomo/thread_810c4bac6d0f.md#source-9f03b52650c20a1d)

The game includes seven "Amplified" zombie types — the Juggernaut, Hydra, Skullcrawler, Berserker, Lasher, Hoplite, and Fissionator — and the user was deciding which should appear in all three timelines and which should be path-exclusive.[^e-b50bdf4c0a] ^2146fb7f

[^e-b50bdf4c0a]: Time: `2023-05-23`; Sources: [locomo/thread_810c4bac6d0f/msg_2f8a85df49fb](../../sources/locomo/thread_810c4bac6d0f.md#source-f669b521a9f819bb), [locomo/thread_810c4bac6d0f/msg_f91bb19ddb67](../../sources/locomo/thread_810c4bac6d0f.md#source-83c02a13a2357013)

The user liked the idea of adding more, smaller timeline splits based on different decisions; the game's story involves military experiments at "Project Zeta" labs, and the user also requested suggestions for maps and events that would fit each of the three paths.[^e-4047a34078] ^b40aff8d

[^e-4047a34078]: Time: `2023-05-23`; Sources: [locomo/thread_810c4bac6d0f/msg_71e8197a0b28](../../sources/locomo/thread_810c4bac6d0f.md#source-d683ad061cc66eb8), [locomo/thread_810c4bac6d0f/msg_f541f64c9f38](../../sources/locomo/thread_810c4bac6d0f.md#source-7c695f93c62976f3), [locomo/thread_810c4bac6d0f/msg_5140d9340862](../../sources/locomo/thread_810c4bac6d0f.md#source-f7ba977a5646fea3)

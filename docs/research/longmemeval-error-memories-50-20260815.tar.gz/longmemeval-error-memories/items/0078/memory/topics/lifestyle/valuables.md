The user recently inherited a few rare items and is working on insuring them; one is an antique emerald and diamond necklace that has been in their family for generations, valued at $12,000 by a gemologist.[^e-ff6048b72c] ^54dc0190

[^e-ff6048b72c]: Time: `2023-05-28`; Sources: [locomo/thread_e85fb7a5fdaa/msg_89e527969c06](../../sources/locomo/thread_e85fb7a5fdaa.md#source-e961634308cd8289), [locomo/thread_e85fb7a5fdaa/msg_aeb41ccca1d7](../../sources/locomo/thread_e85fb7a5fdaa.md#source-07df541c8aa32e38)

The user owns a vintage 1960s Omega Speedmaster watch purchased online for $3,200, one of only 100 pieces made with a rare "tropical" dial, which they plan to insure.[^e-fe336a8439] ^9833c10d

[^e-fe336a8439]: Time: `2023-05-28`; Sources: [locomo/thread_e85fb7a5fdaa/msg_9cf6ec6ac876](../../sources/locomo/thread_e85fb7a5fdaa.md#source-78e91c3cb4189370)

The user purchased a rare first edition of F. Scott Fitzgerald's The Great Gatsby at a used bookstore in the East Village; it is one of only 300 copies printed with a misprinted title page, and they negotiated the price down to $2,500 and plan to insure it.[^e-598e34e3e0] ^01f904b2

[^e-598e34e3e0]: Time: `2023-05-28`; Sources: [locomo/thread_e85fb7a5fdaa/msg_6fc8dcacf93d](../../sources/locomo/thread_e85fb7a5fdaa.md#source-b22c0b6375e06159)

The user inherited a vintage 1920s Cartier pocket watch from their grandfather, one of only 50 pieces made with a unique enamel dial, appraised at $15,000, which they want to display safely in a glass case in their study.[^e-1e035c7fd2] ^bee87f56

[^e-1e035c7fd2]: Time: `2023-05-28`; Sources: [locomo/thread_e85fb7a5fdaa/msg_4db1ca81c322](../../sources/locomo/thread_e85fb7a5fdaa.md#source-f4bcfd718bec2398)

The user purchased a rare 1913 Liberty Head nickel from a reputable dealer for $10,000 and is looking to insure it, researching how to determine its value for insurance purposes.[^e-3a1c37e3fa] ^c4fc046e

[^e-3a1c37e3fa]: Time: `2023-05-28`; Sources: [locomo/thread_e85fb7a5fdaa/msg_6ec44c120a29](../../sources/locomo/thread_e85fb7a5fdaa.md#source-9980cb2edaac333d)

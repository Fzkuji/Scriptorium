The user is planning a dinner party for 8-10 guests using their grandmother's antique fine china and is leaning towards a 'Classic Elegance' menu.[^e-610631f641] ^05c37988

[^e-610631f641]: Time: `2023-05-21`; Sources: [locomo/thread_5623a6557221/msg_aa8874e72af8](../../sources/locomo/thread_5623a6557221.md#source-69a42660a73a7919), [locomo/thread_5623a6557221/msg_04f911880f68](../../sources/locomo/thread_5623a6557221.md#source-feac40c29701a587)

The user plans to display antique pieces in the dining area for the dinner party, including a 1920s Art Deco vase on the mantel, possibly an antique clock on a side table, and their antique sewing machine on a decorative table near the window, keeping the surrounding area simple and uncluttered so the natural light highlights the piece's intricate details.[^e-9706e187e2][^e-b380fd71f2] ^6e015579 ^49d950ff

[^e-9706e187e2]: Time: `2023-05-21`; Sources: [locomo/thread_5623a6557221/msg_1ba1e9ca8f74](../../sources/locomo/thread_5623a6557221.md#source-b3179bdecb7e1f42), [locomo/thread_5623a6557221/msg_e1c7efab79a0](../../sources/locomo/thread_5623a6557221.md#source-8279591945f442ea)

[^e-b380fd71f2]: Time: `2023-05-21`; Sources: [locomo/thread_5623a6557221/msg_f5ddfcf04c2f](../../sources/locomo/thread_5623a6557221.md#source-643b864e1e3d96b8), [locomo/thread_5623a6557221/msg_07acb6b9a521](../../sources/locomo/thread_5623a6557221.md#source-b3bfe6740ba5aa23), [locomo/thread_5623a6557221/msg_a892551c56d4](../../sources/locomo/thread_5623a6557221.md#source-a504681d52bb5057)

The user is planning to attend a party at their new acquaintance Mike's place next weekend — they met Mike at lunch with their friend Rachel ([friends](../relationship/friends.md#^93371488)) — and has chosen to bring a Spinach and Artichoke Dip that takes about 15-25 minutes to prepare and serves 8-12 people.[^e-fd95c60283] ^73fe3791

[^e-fd95c60283]: Time: `2023-05-21`; Sources: [locomo/thread_bb376441501c/msg_ff4264064f14](../../sources/locomo/thread_bb376441501c.md#source-7e33fd17b92c937a), [locomo/thread_bb376441501c/msg_7db4a0d171c3](../../sources/locomo/thread_bb376441501c.md#source-d2e8015b5edc33e9)

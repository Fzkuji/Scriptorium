The user went on a winter hike on 2022-12-20 and took photos with their Sigma 24-70mm f/2.8 DG OS HSM Art lens that they plan to organize and upload to cloud storage.[^e-35d59efca5] ^8bd2a450

[^e-35d59efca5]: Time: `2022-12-20`; Sources: [locomo/thread_5c188c1c98ea/msg_c93b211f719c](../../sources/locomo/thread_5c188c1c98ea.md#source-ad7ffc82fccaa51c)

The user received a new Lowepro ProTactic 450 AW camera bag on 2023-05-20 and is using it to help stay organized with their camera gear.[^e-bb7821909f] ^932d3b08

[^e-bb7821909f]: Time: `2023-05-20`; Sources: [locomo/thread_5c188c1c98ea/msg_c93b211f719c](../../sources/locomo/thread_5c188c1c98ea.md#source-ad7ffc82fccaa51c), [locomo/thread_5c188c1c98ea/msg_279cbcfe7d3a](../../sources/locomo/thread_5c188c1c98ea.md#source-2eabfc9eb54aad15)

The user is considering buying a new tripod because their current one is not sturdy enough in windy conditions, and has been evaluating Gitzo tripod models, most recently researching the Gitzo GT3543LS for its stability, build quality, and 5-year warranty.[^e-87309c8a44][^e-6217e088b3] ^8da46215

[^e-87309c8a44]: Time: `2023-05-20`; Sources: [locomo/thread_5c188c1c98ea/msg_928d5ca1d997](../../sources/locomo/thread_5c188c1c98ea.md#source-e3c0d6abd583756c), [locomo/thread_5c188c1c98ea/msg_7e381a129fb8](../../sources/locomo/thread_5c188c1c98ea.md#source-b7c2e043c35761cf)

[^e-6217e088b3]: Time: `2023-05-30`; Sources: [locomo/thread_551cc7f69a7b/msg_aef5f2dcbddd](../../sources/locomo/thread_551cc7f69a7b.md#source-9439fe0e2fd6bf2e), [locomo/thread_551cc7f69a7b/msg_9d4f40933c71](../../sources/locomo/thread_551cc7f69a7b.md#source-15054298ca2916ee)

The user ordered a SanDisk Extreme PRO memory card reader on 2023-01-12 to replace their old, unreliable one, and is awaiting its arrival.[^e-7b736414be] ^717f1dcb

[^e-7b736414be]: Time: `2023-01-12`; Sources: [locomo/thread_5c188c1c98ea/msg_2857d8f8371a](../../sources/locomo/thread_5c188c1c98ea.md#source-869e410aa1a04c70), [locomo/thread_5c188c1c98ea/msg_345c325e19c4](../../sources/locomo/thread_5c188c1c98ea.md#source-fee814e703d95b15), [locomo/thread_5c188c1c98ea/msg_f1a20a57751d](../../sources/locomo/thread_5c188c1c98ea.md#source-5b89f5c0f4cf64e8)

The user sold their Canon EOS 80D camera to a friend on 2023-01-03.[^e-23f243eb12] ^2b78e7a3

[^e-23f243eb12]: Time: `2023-01-03`; Sources: [locomo/thread_5c188c1c98ea/msg_f1a20a57751d](../../sources/locomo/thread_5c188c1c98ea.md#source-5b89f5c0f4cf64e8)

The user has been putting off cleaning their camera sensor for weeks, and dust spots are starting to appear in their photos; they plan to start with an air blower as part of their photography maintenance routine.[^e-5002ba2904][^e-ebda95ba76] ^880b62fe

[^e-5002ba2904]: Time: `2023-05-20`; Sources: [locomo/thread_5c188c1c98ea/msg_f1a20a57751d](../../sources/locomo/thread_5c188c1c98ea.md#source-5b89f5c0f4cf64e8), [locomo/thread_5c188c1c98ea/msg_936750b91ac8](../../sources/locomo/thread_5c188c1c98ea.md#source-15a56a29778d86d3)

[^e-ebda95ba76]: Time: `2023-05-30`; Sources: [locomo/thread_551cc7f69a7b/msg_846688edaf64](../../sources/locomo/thread_551cc7f69a7b.md#source-bde6abc7a110fe96), [locomo/thread_551cc7f69a7b/msg_435bd8dc0602](../../sources/locomo/thread_551cc7f69a7b.md#source-6088dabed38e32d9)

The user is organizing their photography workflow in the cloud, planning to upload photos and create a descriptive, consistent folder structure for their files.[^e-e779e2c7b9] ^bb144375

[^e-e779e2c7b9]: Time: `2023-05-20`; Sources: [locomo/thread_5c188c1c98ea/msg_6d73cf4ac70b](../../sources/locomo/thread_5c188c1c98ea.md#source-118b979ce50ef488), [locomo/thread_5c188c1c98ea/msg_279cbcfe7d3a](../../sources/locomo/thread_5c188c1c98ea.md#source-2eabfc9eb54aad15), [locomo/thread_5c188c1c98ea/msg_29d274d997d0](../../sources/locomo/thread_5c188c1c98ea.md#source-0bfef0fc57c608ad)

The user acquired a Sony FE 24-70mm f/2.8 GM lens on 2023-02-10 after waiting for it, and used it on a weekend trip to Yosemite where it performed well.[^e-321c6b80eb][^e-7a7d853113] ^759efc86

[^e-321c6b80eb]: Time: `2023-02-10`; Sources: [locomo/thread_551cc7f69a7b/msg_aef5f2dcbddd](../../sources/locomo/thread_551cc7f69a7b.md#source-9439fe0e2fd6bf2e)

[^e-7a7d853113]: Time: `2023-05`; Sources: [locomo/thread_551cc7f69a7b/msg_aef5f2dcbddd](../../sources/locomo/thread_551cc7f69a7b.md#source-9439fe0e2fd6bf2e)

The user is considering buying a new camera backpack, the F-Stop Loka UL 40L, and asked about its features and where to find reviews.[^e-46e341e006] ^eecf6ab2

[^e-46e341e006]: Time: `2023-05-30`; Sources: [locomo/thread_551cc7f69a7b/msg_d43837dfd41b](../../sources/locomo/thread_551cc7f69a7b.md#source-8856a15964658c57), [locomo/thread_551cc7f69a7b/msg_f8859e8d75b5](../../sources/locomo/thread_551cc7f69a7b.md#source-31f309fc63c31363)

The user wants to organize their photography gear storage at home to keep filters, remotes, and extra batteries tidy and easily accessible, and plans to look into Pelican cases and Stack-On cabinets.[^e-efc1f07062] ^b0a6be2c

[^e-efc1f07062]: Time: `2023-05-30`; Sources: [locomo/thread_551cc7f69a7b/msg_9b9ea2c8d118](../../sources/locomo/thread_551cc7f69a7b.md#source-7615a980a7a5d553), [locomo/thread_551cc7f69a7b/msg_846688edaf64](../../sources/locomo/thread_551cc7f69a7b.md#source-bde6abc7a110fe96)

The user plans to sell their Sony RX100 Mark IV camera, which they haven't used in over a year, and will start with eBay and Facebook Marketplace.[^e-0421990a35] ^ce9ddfa5

[^e-0421990a35]: Time: `2023-05-30`; Sources: [locomo/thread_551cc7f69a7b/msg_435bd8dc0602](../../sources/locomo/thread_551cc7f69a7b.md#source-6088dabed38e32d9), [locomo/thread_551cc7f69a7b/msg_e139ce4b11ca](../../sources/locomo/thread_551cc7f69a7b.md#source-ddd957ae3225c8f0)

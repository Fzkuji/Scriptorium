## Home and neighborhood

The user recently moved into a new apartment and enjoys the shorter commute, which gives them an extra 30 minutes each morning to grab coffee and catch up on the news.[^e-5b2a05ccf7] ^74f120fd

[^e-5b2a05ccf7]: Time: `2023-04-29`; Sources: [locomo/thread_7a2d72a9009a/msg_733c22d0826c](../../sources/locomo/thread_7a2d72a9009a.md#source-80f4b4db0c7b2c23)

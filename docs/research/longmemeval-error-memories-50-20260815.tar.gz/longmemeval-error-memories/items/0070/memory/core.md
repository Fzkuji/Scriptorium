# Core Memory

The user lives in the Los Angeles area, works in an office, and runs a farm; they are a parent and their best friend is Rachel.[^e-91ccf86ce9] ^c4f9cf75

[^e-91ccf86ce9]: Time: `2023-02`; Sources: [locomo/thread_6bc2090ac4de/msg_a24e4dfe6c20](sources/locomo/thread_6bc2090ac4de.md#source-a32718f8a803603d), [locomo/thread_89990fbd2a44/msg_25234a4c1f69](sources/locomo/thread_89990fbd2a44.md#source-0e66929eee9ce800), [locomo/thread_7a2d72a9009a/msg_cef6e3a88f68](sources/locomo/thread_7a2d72a9009a.md#source-52c4794a71fd2442), [locomo/thread_37d993f7a9d6/msg_dfde6a0693d2](sources/locomo/thread_37d993f7a9d6.md#source-6069515421af360a)

Active ongoing plans include a solo trip to Medellín, Colombia with an Airbnb in El Poblado or La Llanura; expanding the farm's operations with Nigerian Dwarf goats and fencing for the north field; and attending more concerts and festivals in the Los Angeles area.[^e-604d50f5fc] ^b4806932

[^e-604d50f5fc]: Time: `2023-02`; Sources: [locomo/thread_37d993f7a9d6/msg_e62eacb084f2](sources/locomo/thread_37d993f7a9d6.md#source-2fff06198fb85b3f), [locomo/thread_7a2d72a9009a/msg_cef6e3a88f68](sources/locomo/thread_7a2d72a9009a.md#source-52c4794a71fd2442), [locomo/thread_7a2d72a9009a/msg_b2abf303cfe7](sources/locomo/thread_7a2d72a9009a.md#source-73f5889a2d354328), [locomo/thread_6bc2090ac4de/msg_f8754e93bfdc](sources/locomo/thread_6bc2090ac4de.md#source-dee9d2afa1a5912e)

The user prefers a mix of outdoor adventure and cultural exploration when traveling, with a budget of around $2000 for 5-7 days, preferring Airbnb and a blend of relaxation and adventure.[^e-33bb07a610] ^4713a947

[^e-33bb07a610]: Time: `2023-02`; Sources: [locomo/thread_37d993f7a9d6/msg_6c0a984c5fc6](sources/locomo/thread_37d993f7a9d6.md#source-5563975dea57329b)

The user enjoys cooking with seasonal ingredients, plays guitar, and manages a hedge fund.[^e-08ad61db30] ^b1004eb3

[^e-08ad61db30]: Time: `2023-02`; Sources: [locomo/thread_89990fbd2a44/msg_e94e6e841d8e](sources/locomo/thread_89990fbd2a44.md#source-72a40ff0043bd59d), [locomo/thread_cbcd98836154/msg_4efa0dd0ad5d](sources/locomo/thread_cbcd98836154.md#source-d36bc6e70ac12196), [locomo/thread_5c188c1c98ea/msg_c93b211f719c](sources/locomo/thread_5c188c1c98ea.md#source-ad7ffc82fccaa51c)

The user is planning a trip to San Francisco and a fishing trip to Canada with their dad in summer 2023.[^e-dee4791cf1] ^10c6ea43

[^e-dee4791cf1]: Time: `2023-02`; Sources: [locomo/thread_749fa3152137/msg_a642c1a18f3f](sources/locomo/thread_749fa3152137.md#source-4163a2571ab0f5e7), [locomo/thread_987adb9e3384/msg_cedd23a82653](sources/locomo/thread_987adb9e3384.md#source-a01f1646c2b15630)

The user is a [social media content creator](topics/career/social-media.md#^994b983e) posting vegan cooking and sustainable-living content on Instagram, Twitter, Facebook, and YouTube.[^e-4f8bf1e44c] ^897dbcb0

[^e-4f8bf1e44c]: Time: `2023-02`; Sources: [locomo/thread_2722126b02ae/msg_89c8fca8566c](sources/locomo/thread_2722126b02ae.md#source-ad3343c88e9e397f), [locomo/thread_2722126b02ae/msg_6ce52dc5c319](sources/locomo/thread_2722126b02ae.md#source-b1148d2c90a1c5e4)

The user commits to a 30-minute deep clean session every Sunday.[^e-bb10e3a09a] ^73c3d707

[^e-bb10e3a09a]: Time: `2023-02`; Sources: [locomo/thread_14f6bc69bb92/msg_85e2fa90cef9](sources/locomo/thread_14f6bc69bb92.md#source-907542218edfbb75)

The user also runs a [freelance writing business](topics/career/freelance-writing.md#^c36f639b), practices cityscape and street-art photography, and collects Funko Pops, action figures, comic books, coins, and vintage sports memorabilia.[^e-6d3f800f55][^e-b1270b8ca2] ^eff5bcf3

[^e-6d3f800f55]: Time: `2023-02`; Sources: [locomo/thread_3dfeec2de60c/msg_8c4ecc50b41f](sources/locomo/thread_3dfeec2de60c.md#source-7de3472b38635a32), [locomo/thread_7c96790ff4be/msg_78118bc0cf54](sources/locomo/thread_7c96790ff4be.md#source-0f9d10005397692e), [locomo/thread_100ba0195b99/msg_ebd760f46e80](sources/locomo/thread_100ba0195b99.md#source-b010eae73e629d10)

[^e-b1270b8ca2]: Time: `2023-02`; Sources: [locomo/thread_fbdbd86005d1/msg_4a557915a204](sources/locomo/thread_fbdbd86005d1.md#source-782ae62c6a6f2b1f)

The user is starting an e-commerce store selling eco-friendly home goods.[^e-e16a1561e3] ^2f8acd60

[^e-e16a1561e3]: Time: `2023-02`; Sources: [locomo/thread_de58813e57c1/msg_1f4f531023d1](sources/locomo/thread_de58813e57c1.md#source-4d44d4d1c7844697), [locomo/thread_de58813e57c1/msg_05234d01ebd2](sources/locomo/thread_de58813e57c1.md#source-fd9a3824899439d2)

The user started a dream job at a top consulting firm in mid-February 2023, a significant career milestone, and is adopting Todoist for task management.[^e-98bcce3982] ^016a35ee

[^e-98bcce3982]: Time: `2023-02-15`; Sources: [locomo/thread_7ad370356362/msg_cf31fbfc2cc1](sources/locomo/thread_7ad370356362.md#source-20ae3a1bdecb4216)

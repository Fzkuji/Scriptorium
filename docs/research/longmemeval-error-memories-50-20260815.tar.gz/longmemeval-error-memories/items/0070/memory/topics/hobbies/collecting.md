# Collecting

## Figures & Funko Pops

The user collects Funko Pops and asked for advice on removing dust without damaging the paint, including methods like soft brushes, compressed air, and microfiber cloths with distilled water.[^e-c732aecae1] ^fa5a0d44

[^e-c732aecae1]: Time: `2023-02`; Sources: [locomo/thread_100ba0195b99/msg_ebd760f46e80](../../sources/locomo/thread_100ba0195b99.md#source-b010eae73e629d10), [locomo/thread_100ba0195b99/msg_02c5ba44b74d](../../sources/locomo/thread_100ba0195b99.md#source-c9c32833b3daf545)

The user collects action figures and wants tips on arranging them into a visually appealing display, including grouping by theme, balancing heights and poses, using risers, and lighting.[^e-7a08033806] ^782af56f

[^e-7a08033806]: Time: `2023-02`; Sources: [locomo/thread_100ba0195b99/msg_8bc4719b42a4](../../sources/locomo/thread_100ba0195b99.md#source-d8856c22efaf2852), [locomo/thread_100ba0195b99/msg_7539b8e04787](../../sources/locomo/thread_100ba0195b99.md#source-be24f55d96db4f2f)

## Comic Books

The user recently acquired a vintage Spider-Man comic book and is a Spider-Man fan; they display a limited edition Spider-Man Funko Pop! figure on their desk alongside other Spider-Man collectibles.[^e-6b1d03bcf0] ^d223bfaf

[^e-6b1d03bcf0]: Time: `2023-02`; Sources: [locomo/thread_fbdbd86005d1/msg_0c0fc9080af6](../../sources/locomo/thread_fbdbd86005d1.md#source-a9317b62d3024ac0)

The user has a comic book collection and asked how to store and preserve it, including bagging and boarding, storage boxes, cataloging, climate control with temperature and humidity management, and light protection, and is interested in learning about the history of Spider-Man comics and the character's origins and evolution over the years.[^e-df923c4bc5][^e-c41e13ae02][^e-ef81d0a3b4] ^91f0a152 ^9a68bcd6

[^e-df923c4bc5]: Time: `2023-02`; Sources: [locomo/thread_100ba0195b99/msg_4e2302660f07](../../sources/locomo/thread_100ba0195b99.md#source-7c4c020011415634), [locomo/thread_100ba0195b99/msg_7c72bda5a8ce](../../sources/locomo/thread_100ba0195b99.md#source-1c82152d7010295f)

[^e-c41e13ae02]: Time: `2023-02`; Sources: [locomo/thread_fbdbd86005d1/msg_0c0fc9080af6](../../sources/locomo/thread_fbdbd86005d1.md#source-a9317b62d3024ac0)

[^e-ef81d0a3b4]: Time: `2023-02`; Sources: [locomo/thread_fbdbd86005d1/msg_4171fd7e8389](../../sources/locomo/thread_fbdbd86005d1.md#source-0a1411819a641c5c)

The user prefers collecting and displaying physical comics and plans to stick with single issues and trade paperbacks, after learning about the differences among comic book formats including single issues, trade paperbacks, hardcovers, and omnibuses.[^e-9832998c1a] ^3c4db7ab

[^e-9832998c1a]: Time: `2023-02`; Sources: [locomo/thread_fbdbd86005d1/msg_cfb210aeae85](../../sources/locomo/thread_fbdbd86005d1.md#source-b6e13ac4a1008240), [locomo/thread_fbdbd86005d1/msg_4a557915a204](../../sources/locomo/thread_fbdbd86005d1.md#source-782ae62c6a6f2b1f)

## Coins

The user is interested in coin grading and slabbing, asked about the process and requirements for getting their coins graded, and is planning to get their rare coins graded and slabbed to increase their value; they also asked how to determine the authenticity of a grading service, including checking its reputation, third-party accreditation, expertise, transparency, and physical security.[^e-1b0ec58a5b][^e-14149da6d9] ^41210b64 ^bac410e4

[^e-1b0ec58a5b]: Time: `2023-02`; Sources: [locomo/thread_100ba0195b99/msg_2d726ca3f2c5](../../sources/locomo/thread_100ba0195b99.md#source-45d9f4ca533e3a50)

[^e-14149da6d9]: Time: `2023-02`; Sources: [locomo/thread_100ba0195b99/msg_134d798c49b3](../../sources/locomo/thread_100ba0195b99.md#source-ec3a2b2a70281943), [locomo/thread_100ba0195b99/msg_620e79f5c784](../../sources/locomo/thread_100ba0195b99.md#source-5c3815bdf93e6c5f)

## Other Collectibles

The user is also thinking of getting their vintage NES console serviced to keep it working smoothly and asked for tips on finding a reputable repair service or technician, including checking specialization, credentials, referrals, and red flags.[^e-9c23f04ff4] ^190d74a6

[^e-9c23f04ff4]: Time: `2023-02`; Sources: [locomo/thread_100ba0195b99/msg_292dab1a066d](../../sources/locomo/thread_100ba0195b99.md#source-b4e6daa454973464), [locomo/thread_100ba0195b99/msg_2aa5e9b82bd5](../../sources/locomo/thread_100ba0195b99.md#source-239b73750d373fe3)

## Sports Memorabilia

The user collects vintage sports memorabilia and recently added new pieces from a garage sale, including a signed jersey from their favorite baseball player that they are excited to display.[^e-7883fbd74d] ^8ea557d0

[^e-7883fbd74d]: Time: `2023-02`; Sources: [locomo/thread_fbdbd86005d1/msg_4a557915a204](../../sources/locomo/thread_fbdbd86005d1.md#source-782ae62c6a6f2b1f)

The user is planning a dedicated shelf for their vintage sports memorabilia display, using a unifying theme of their favorite baseball team and a color scheme that complements the team's colors, grouping similar items like vintage baseballs and autographed photos, leaving space between items, making the signed jersey in a display case the focal point, and adding decorative items like vintage baseballs, sports-themed posters, and an old baseball glove.[^e-4e5b18669b] ^e7d60d03

[^e-4e5b18669b]: Time: `2023-02`; Sources: [locomo/thread_fbdbd86005d1/msg_6ef10bfbdf34](../../sources/locomo/thread_fbdbd86005d1.md#source-5a45bff779a88b66), [locomo/thread_fbdbd86005d1/msg_3d2906e5447d](../../sources/locomo/thread_fbdbd86005d1.md#source-977715e805058065)

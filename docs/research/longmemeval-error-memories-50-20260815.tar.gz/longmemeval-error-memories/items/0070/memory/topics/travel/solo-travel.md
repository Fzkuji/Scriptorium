# Solo Travel

The user is planning a solo trip and is leaning toward Medellín, Colombia.[^e-621e903cbd] ^e1e2e0c2

[^e-621e903cbd]: Time: `2023-02`; Sources: [locomo/thread_37d993f7a9d6/msg_dfde6a0693d2](../../sources/locomo/thread_37d993f7a9d6.md#source-6069515421af360a)

The user's travel preferences are a mix of outdoor adventure and cultural exploration, a budget of around $2000, 5-7 days, openness to new destinations, Airbnb accommodation, and a mix of relaxation and adventure; they have traveled solo before and enjoyed the freedom to do what they want.[^e-3cf3d17b26] ^dae4275f

[^e-3cf3d17b26]: Time: `2023-02`; Sources: [locomo/thread_37d993f7a9d6/msg_6c0a984c5fc6](../../sources/locomo/thread_37d993f7a9d6.md#source-5563975dea57329b)

The user is looking for Airbnb options in El Poblado or La Llanura in a safe and convenient area with access to good restaurants and transportation.[^e-411924d5ac] ^f39d73eb

[^e-411924d5ac]: Time: `2023-02`; Sources: [locomo/thread_37d993f7a9d6/msg_e62eacb084f2](../../sources/locomo/thread_37d993f7a9d6.md#source-2fff06198fb85b3f)

The user is concerned about safety in Medellín but acknowledges the city has made a lot of progress.[^e-d71d67eec9] ^7c5dd8b1

[^e-d71d67eec9]: Time: `2023-02`; Sources: [locomo/thread_37d993f7a9d6/msg_e62eacb084f2](../../sources/locomo/thread_37d993f7a9d6.md#source-2fff06198fb85b3f)

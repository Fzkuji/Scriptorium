# Sewing & Cross-Stitch

## Projects & Materials

The user does cross-stitch and quilting and received the DMC floss they ordered online today, so they are set to work on their cross-stitch pattern.[^e-46ee70748d] ^40411b43

[^e-46ee70748d]: Time: `2023-02-15`; Sources: [locomo/thread_b24a05483e4e/msg_f387e885504d](../../sources/locomo/thread_b24a05483e4e.md#source-1fd9321af352ff31)

## Organizing the Sewing Space

The user is organizing their sewing space and has already sorted their embroidery floss and beads into small containers stored in a separate box, and plans to get a thread sorter or rack to keep threads organized and accessible.[^e-9df36b344e] ^6cbbbe4f

[^e-9df36b344e]: Time: `2023-02`; Sources: [locomo/thread_b24a05483e4e/msg_f387e885504d](../../sources/locomo/thread_b24a05483e4e.md#source-1fd9321af352ff31), [locomo/thread_b24a05483e4e/msg_5b6d2ab006e6](../../sources/locomo/thread_b24a05483e4e.md#source-c7d4451767e5b42a), [locomo/thread_b24a05483e4e/msg_f05e00bb3bb4](../../sources/locomo/thread_b24a05483e4e.md#source-bf1708daf0aa8c0c)

The user has a large fabric stash with many scraps from old projects that they want to use in an upcoming quilt, and plans to sort fabrics by color, type, and value and set up a scrap bin with separate compartments for different colors.[^e-86b7c81149] ^02c524ab

[^e-86b7c81149]: Time: `2023-02`; Sources: [locomo/thread_b24a05483e4e/msg_f05e00bb3bb4](../../sources/locomo/thread_b24a05483e4e.md#source-bf1708daf0aa8c0c), [locomo/thread_b24a05483e4e/msg_62cf9d12f1a0](../../sources/locomo/thread_b24a05483e4e.md#source-9aa08c67a105c408), [locomo/thread_b24a05483e4e/msg_2d55a5f827cd](../../sources/locomo/thread_b24a05483e4e.md#source-2cd1a6a7cd76cc33)

The user is organizing their sewing book collection, including an old sewing book that belonged to their aunt, and plans to organize sewing patterns by type and store them in a dedicated organizer or storage box, sorting their many garment patterns by size or skill level.[^e-6cd590af1d] ^bd7b4762

[^e-6cd590af1d]: Time: `2023-02`; Sources: [locomo/thread_b24a05483e4e/msg_2d55a5f827cd](../../sources/locomo/thread_b24a05483e4e.md#source-2cd1a6a7cd76cc33), [locomo/thread_b24a05483e4e/msg_248efc7a5dc9](../../sources/locomo/thread_b24a05483e4e.md#source-79023fd204902ae0), [locomo/thread_b24a05483e4e/msg_864f72bd5bf1](../../sources/locomo/thread_b24a05483e4e.md#source-63cda7964ff3315e)

The user plans to organize buttons by type and size in a dedicated button organizer and to use labeled small storage containers for other notions like needles, pins, scissors, and tape measures.[^e-1a71ec522b] ^3017b852

[^e-1a71ec522b]: Time: `2023-02`; Sources: [locomo/thread_b24a05483e4e/msg_864f72bd5bf1](../../sources/locomo/thread_b24a05483e4e.md#source-63cda7964ff3315e), [locomo/thread_b24a05483e4e/msg_be725ca91973](../../sources/locomo/thread_b24a05483e4e.md#source-793c6a5c40669b6e), [locomo/thread_b24a05483e4e/msg_8d3c4630c55f](../../sources/locomo/thread_b24a05483e4e.md#source-0beefda6752136e6)

The user is also organizing their sewing machine accessories, including presser feet and needles, and asked for suggestions on how to store them.[^e-26716d9e8b] ^887956cb

[^e-26716d9e8b]: Time: `2023-02`; Sources: [locomo/thread_b24a05483e4e/msg_c61dbee98b98](../../sources/locomo/thread_b24a05483e4e.md#source-1268a06f5e153b7d), [locomo/thread_b24a05483e4e/msg_90ce7782058d](../../sources/locomo/thread_b24a05483e4e.md#source-8e38c3a28598983b)

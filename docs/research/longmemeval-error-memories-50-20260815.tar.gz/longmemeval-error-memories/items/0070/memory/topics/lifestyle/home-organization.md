# Home Organization

The user commits to a 30-minute deep clean session every Sunday and deep cleaned their living room last Sunday.[^e-3698de0e87][^e-7bdcf626c0] ^23cb98ad ^2ae039a9

[^e-3698de0e87]: Time: `2023-02`; Sources: [locomo/thread_14f6bc69bb92/msg_85e2fa90cef9](../../sources/locomo/thread_14f6bc69bb92.md#source-907542218edfbb75)

[^e-7bdcf626c0]: Time: `2023-02-12`; Sources: [locomo/thread_14f6bc69bb92/msg_85e2fa90cef9](../../sources/locomo/thread_14f6bc69bb92.md#source-907542218edfbb75)

The user is organizing their bookshelf to maximize space and has many books they haven't read in years that hold sentimental value.[^e-d7629ca5b7] ^f418d823

[^e-d7629ca5b7]: Time: `2023-02`; Sources: [locomo/thread_14f6bc69bb92/msg_85e2fa90cef9](../../sources/locomo/thread_14f6bc69bb92.md#source-907542218edfbb75), [locomo/thread_14f6bc69bb92/msg_de76b3f4fb6e](../../sources/locomo/thread_14f6bc69bb92.md#source-95cfdf1a5cf12c25)

To let go of sentimental books, the user likes the idea of photographing the book cover and writing down the memory associated with it, and wants creative ways to organize and display these memories aside from a digital album or scrapbook.[^e-ce9e9d8f1d] ^9b0a5c4d

[^e-ce9e9d8f1d]: Time: `2023-02`; Sources: [locomo/thread_14f6bc69bb92/msg_de76b3f4fb6e](../../sources/locomo/thread_14f6bc69bb92.md#source-95cfdf1a5cf12c25), [locomo/thread_14f6bc69bb92/msg_ad9ff0d6af6b](../../sources/locomo/thread_14f6bc69bb92.md#source-dc9853581dd70d00)

The user liked the idea of a Book Memory Wall and plans to build one on their living room wall, which has a lot of space and would serve as a conversation starter, arranging it in a staggered layout with mixed frame sizes and angles to add visual interest.[^e-4241ef1509][^e-0d121f8ad5] ^77e3dcab ^8f540acb

[^e-4241ef1509]: Time: `2023-02`; Sources: [locomo/thread_14f6bc69bb92/msg_ef96b87b06ca](../../sources/locomo/thread_14f6bc69bb92.md#source-61e9c221291303e7)

[^e-0d121f8ad5]: Time: `2023-02`; Sources: [locomo/thread_14f6bc69bb92/msg_40249297a064](../../sources/locomo/thread_14f6bc69bb92.md#source-1001eb0c5d07d83e)

The user has decided what books to keep and what to let go of and is starting to categorize their books into broad categories (fiction and non-fiction), then into subcategories like genres (romance, sci-fi, fantasy) and topics (self-help, biographies, history).[^e-2e3231c7cb] ^a08abc90

[^e-2e3231c7cb]: Time: `2023-02`; Sources: [locomo/thread_14f6bc69bb92/msg_13a7a1994b39](../../sources/locomo/thread_14f6bc69bb92.md#source-1ab4c017ff015b4d)

The user is decluttering their apartment and found a bunch of old [family heirlooms](../family/heirlooms.md#^66ac25a4) that they are considering selling, and asked for recommendations of online marketplaces (eBay, Etsy, Facebook Marketplace, Ruby Lane, Chairish, 1stdibs, and Mercari) and local shops and consignment options (antique stores, vintage and second-hand stores, consignment stores, pawn shops, auction houses, estate sale companies, and collectible shops).[^e-3b6bef5682] ^54cb52d6

[^e-3b6bef5682]: Time: `2023-02-15`; Sources: [locomo/thread_e85fb7a5fdaa/msg_89e527969c06](../../sources/locomo/thread_e85fb7a5fdaa.md#source-e961634308cd8289), [locomo/thread_e85fb7a5fdaa/msg_fd4953c05338](../../sources/locomo/thread_e85fb7a5fdaa.md#source-6ae9fafd63cff716)

# Eco-Friendly Living

The user uses eco-friendly grocery options including cloth bags, reusable produce bags, glass containers, and metal straws, and decided to start being more mindful of how they store and dispose of these items, being interested in reducing waste in general; after learning about the harmful effects of microplastic pollution on marine environments, they decided to start using reusable shopping bags and water bottles to reduce plastic waste and asked for eco-friendly brand recommendations.[^e-fc90e1905f][^e-7bcdf8c964][^e-fbcf6cfed2] ^ffbd7600 ^0c217673 ^269b7108

[^e-fc90e1905f]: Time: `2023-02`; Sources: [locomo/thread_f4407b5e69a3/msg_b7e48307cffc](../../sources/locomo/thread_f4407b5e69a3.md#source-feeae438fd5ea0c5)

[^e-7bcdf8c964]: Time: `2023-02`; Sources: [locomo/thread_f4407b5e69a3/msg_255d528a32f4](../../sources/locomo/thread_f4407b5e69a3.md#source-32adf334dc723fa7), [locomo/thread_f4407b5e69a3/msg_c0fc02ca5cef](../../sources/locomo/thread_f4407b5e69a3.md#source-7e2af5d7563f4b8e)

[^e-fbcf6cfed2]: Time: `2023-02`; Sources: [locomo/thread_e75d517f7f0b/msg_8b8a49210bee](../../sources/locomo/thread_e75d517f7f0b.md#source-c2f3b4cee2c49ff9), [locomo/thread_e75d517f7f0b/msg_0b0eb7d6844d](../../sources/locomo/thread_e75d517f7f0b.md#source-8e230d3f1517c473)

# Mosul Reconstruction

The user asked about the major economic players in Mosul and how reconstruction efforts are going, learning that the main economic sectors are agriculture, trade, construction, and petroleum, and that reconstruction has restored basic infrastructure such as water and electricity and rebuilt homes and businesses, with completed projects including the al-Nuri mosque, bridges, schools, and hospitals, though many challenges remain.[^e-dc97938e9a] ^9ffee7d0

[^e-dc97938e9a]: Time: `2023-02`; Sources: [locomo/thread_ae05743e8c30/msg_2321835183e7](../../sources/locomo/thread_ae05743e8c30.md#source-f336c7e1014dbcc8), [locomo/thread_ae05743e8c30/msg_b2d0ad460ac7](../../sources/locomo/thread_ae05743e8c30.md#source-aee41b66d1562ee0), [locomo/thread_ae05743e8c30/msg_75b0901b5e08](../../sources/locomo/thread_ae05743e8c30.md#source-bd51d9a5b7c04394), [locomo/thread_ae05743e8c30/msg_336ee2792c91](../../sources/locomo/thread_ae05743e8c30.md#source-806a29acfd8c7483), [locomo/thread_ae05743e8c30/msg_b9d247ef4b89](../../sources/locomo/thread_ae05743e8c30.md#source-366dfbcb6e6164fd), [locomo/thread_ae05743e8c30/msg_cb704212b8ec](../../sources/locomo/thread_ae05743e8c30.md#source-a4b7adbcaf547cd2)

The user is interested in supporting Mosul's reconstruction and was pointed to organizations including UNDP Iraq, the Mosul Cultural Heritage Trust, Mosul Eye, Direct Relief, and the Iraq and Afghanistan Veterans of America.[^e-10c48b54c5] ^0971da7a

[^e-10c48b54c5]: Time: `2023-02`; Sources: [locomo/thread_ae05743e8c30/msg_b7eab86cb12c](../../sources/locomo/thread_ae05743e8c30.md#source-7d4f7f031f0f4a99), [locomo/thread_ae05743e8c30/msg_67998f79b6f9](../../sources/locomo/thread_ae05743e8c30.md#source-c9daeddd901c9fe0)

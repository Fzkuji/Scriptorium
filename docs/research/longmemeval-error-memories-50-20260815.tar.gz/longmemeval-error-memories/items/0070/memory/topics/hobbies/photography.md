# Photography

The user recently visited a photography exhibition at the Local History Museum that showcased the city's transformation over the past century, spending about two and a half hours there taking notes and photographing their favorite pieces.[^e-97517051c0] ^22d45ef6

[^e-97517051c0]: Time: `2023-02`; Sources: [locomo/thread_7c96790ff4be/msg_78118bc0cf54](../../sources/locomo/thread_7c96790ff4be.md#source-0f9d10005397692e), [locomo/thread_7c96790ff4be/msg_d11c1233809b](../../sources/locomo/thread_7c96790ff4be.md#source-675930aca64e0510)

The user is working on improving their cityscape photography, including nighttime shots (using a tripod, slow shutter speeds, low ISO, RAW, and the blue hour) and daytime shots (managing harsh sunlight and shadows with polarizing filters and overcast light).[^e-817deca904] ^0b90e2bd

[^e-817deca904]: Time: `2023-02`; Sources: [locomo/thread_7c96790ff4be/msg_315d5febadfe](../../sources/locomo/thread_7c96790ff4be.md#source-0612c1f9a88c6133), [locomo/thread_7c96790ff4be/msg_5b0e76041f3f](../../sources/locomo/thread_7c96790ff4be.md#source-40c60a2411a45fac)

The user wants to capture cityscapes that show the city's transformation over time and has researched how to find locations that demonstrate change, such as areas contrasting old and new architecture, historic districts, and sites of gentrification or urban renewal.[^e-55eb761583] ^70dca545

[^e-55eb761583]: Time: `2023-02`; Sources: [locomo/thread_7c96790ff4be/msg_4c34f8bf8d0f](../../sources/locomo/thread_7c96790ff4be.md#source-e4c9760e1bb82cca)

The user is also interested in capturing the city's street art and graffiti scene as a way to document its transformation and creative energy.[^e-ca244199b2] ^dba783d8

[^e-ca244199b2]: Time: `2023-02`; Sources: [locomo/thread_7c96790ff4be/msg_a08c2f41f173](../../sources/locomo/thread_7c96790ff4be.md#source-ee98e2c0e9217fb1), [locomo/thread_7c96790ff4be/msg_d11c1233809b](../../sources/locomo/thread_7c96790ff4be.md#source-675930aca64e0510)

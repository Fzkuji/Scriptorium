# Art

The user is looking for inspiration for their next art project, exploring abstract expressionist artists; they want to try the impasto technique and combine it with collage elements, planning to use botanical illustrations and their own sketches and drawings as collage elements in the painting.[^e-38edc4c1b3][^e-6951279b5c][^e-8b6ad0ba12] ^d104e1aa ^440d04d4 ^088b963e

[^e-38edc4c1b3]: Time: `2023-02`; Sources: [locomo/thread_bb376441501c/msg_ff4264064f14](../../sources/locomo/thread_bb376441501c.md#source-7e33fd17b92c937a)

[^e-6951279b5c]: Time: `2023-02`; Sources: [locomo/thread_bb376441501c/msg_d95014e7d966](../../sources/locomo/thread_bb376441501c.md#source-83b06f4b29a06e05), [locomo/thread_bb376441501c/msg_b336ce7c40ad](../../sources/locomo/thread_bb376441501c.md#source-520911356138312f)

[^e-8b6ad0ba12]: Time: `2023-02`; Sources: [locomo/thread_bb376441501c/msg_264e6fe14057](../../sources/locomo/thread_bb376441501c.md#source-62941d18cdbf33e6), [locomo/thread_bb376441501c/msg_00f465059b48](../../sources/locomo/thread_bb376441501c.md#source-f321809c2ad2a8d1)

# Fishing

The user's fishing license expired in January 2023 and they planned to renew it before their next fishing trip.[^e-dafc82a779] ^a496b952

[^e-dafc82a779]: Time: `2023-01`; Sources: [locomo/thread_987adb9e3384/msg_49916e9f133b](../../sources/locomo/thread_987adb9e3384.md#source-3476c113605b1c56)

The user recently went on a fishing trip with their buddies at a lake, using spinners and crawdads as bait, and had a blast despite the cloudy weather.[^e-9a259fea8a] ^9f343b13

[^e-9a259fea8a]: Time: `2023-01-28`; Sources: [locomo/thread_987adb9e3384/msg_49916e9f133b](../../sources/locomo/thread_987adb9e3384.md#source-3476c113605b1c56), [locomo/thread_987adb9e3384/msg_f9630cd69044](../../sources/locomo/thread_987adb9e3384.md#source-482b57b767e06b70)

The user is planning a fishing trip to Canada with their dad in summer 2023.[^e-a4741887b9] ^ccebfca1

[^e-a4741887b9]: Time: `2023`; Sources: [locomo/thread_987adb9e3384/msg_cedd23a82653](../../sources/locomo/thread_987adb9e3384.md#source-a01f1646c2b15630)

The user's tackle box is a mess and they planned to organize it; they bought new hooks and a fishing net at Joe's Tackle Shop but are not entirely satisfied with the net, and planned to check Joe's Tackle Shop, including its website, for hook organizers and fishing nets.[^e-f8a12e52d8][^e-d891f425bb] ^8242372b ^807ff337

[^e-f8a12e52d8]: Time: `2023-02`; Sources: [locomo/thread_987adb9e3384/msg_93ccddf82484](../../sources/locomo/thread_987adb9e3384.md#source-24da4a402bb04a09), [locomo/thread_987adb9e3384/msg_f9630cd69044](../../sources/locomo/thread_987adb9e3384.md#source-482b57b767e06b70)

[^e-d891f425bb]: Time: `2023-02`; Sources: [locomo/thread_987adb9e3384/msg_f9630cd69044](../../sources/locomo/thread_987adb9e3384.md#source-482b57b767e06b70), [locomo/thread_987adb9e3384/msg_860def65ef76](../../sources/locomo/thread_987adb9e3384.md#source-57d135f1603352ec), [locomo/thread_987adb9e3384/msg_3bb059d845a8](../../sources/locomo/thread_987adb9e3384.md#source-79c2bf60832ee966)

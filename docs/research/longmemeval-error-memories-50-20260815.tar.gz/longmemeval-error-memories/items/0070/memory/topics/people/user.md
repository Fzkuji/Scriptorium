# User

The user is a parent; a past [family trip to Hawaii](../travel/family-trips.md#^6866c0b9) involved managing the kids' schedules and nap times.[^e-1fd991278b] ^13ca8b17

[^e-1fd991278b]: Time: `undated`; Sources: [locomo/thread_37d993f7a9d6/msg_dfde6a0693d2](../../sources/locomo/thread_37d993f7a9d6.md#source-6069515421af360a)

The user lives in the Los Angeles area and attends [concerts](../music/la-music.md#^d8e8c630) at venues such as the Los Angeles Forum and the Hollywood Bowl.[^e-08e19a0881] ^1aab29f9

[^e-08e19a0881]: Time: `2023-02`; Sources: [locomo/thread_6bc2090ac4de/msg_a24e4dfe6c20](../../sources/locomo/thread_6bc2090ac4de.md#source-a32718f8a803603d), [locomo/thread_6bc2090ac4de/msg_751195df2930](../../sources/locomo/thread_6bc2090ac4de.md#source-8e2c6b6819bdc31c)

The user runs a [farm](../farm/farm-operations.md#^1e052cb1) with a cowshed, a chicken coop with hens, and a north field.[^e-627dfcf6ab] ^201637f4

[^e-627dfcf6ab]: Time: `2023-02`; Sources: [locomo/thread_7a2d72a9009a/msg_cef6e3a88f68](../../sources/locomo/thread_7a2d72a9009a.md#source-52c4794a71fd2442), [locomo/thread_7a2d72a9009a/msg_733c22d0826c](../../sources/locomo/thread_7a2d72a9009a.md#source-80f4b4db0c7b2c23)

The user works in an office and takes a 10-minute walk outside in a nearby park during lunch breaks, which helps them feel more focused and productive.[^e-72ad706adc] ^557f4311

[^e-72ad706adc]: Time: `2023-02`; Sources: [locomo/thread_89990fbd2a44/msg_25234a4c1f69](../../sources/locomo/thread_89990fbd2a44.md#source-0e66929eee9ce800), [locomo/thread_89990fbd2a44/msg_40f5ab477866](../../sources/locomo/thread_89990fbd2a44.md#source-d9c003c83db4ef69)

The user has noticed that since the winter solstice the days have been getting longer, leaving them feeling more energized and motivated.[^e-0422f45936] ^b3234d52

[^e-0422f45936]: Time: `2022-12`; Sources: [locomo/thread_89990fbd2a44/msg_e94e6e841d8e](../../sources/locomo/thread_89990fbd2a44.md#source-72a40ff0043bd59d)

In the nearby park the user has seen more birds and spotted daffodils starting to bloom earlier than usual, signs of spring.[^e-61ab0f277d] ^bcdba2d3

[^e-61ab0f277d]: Time: `2023-02`; Sources: [locomo/thread_89990fbd2a44/msg_40f5ab477866](../../sources/locomo/thread_89990fbd2a44.md#source-d9c003c83db4ef69)

The user manages a [hedge fund](../career/hedge-fund.md#^8b25e0f2).[^e-25c6313b86] ^b6bd8925

[^e-25c6313b86]: Time: `2023-02`; Sources: [locomo/thread_5c188c1c98ea/msg_c93b211f719c](../../sources/locomo/thread_5c188c1c98ea.md#source-ad7ffc82fccaa51c)

The user plays [guitar](../hobbies/guitar.md#^1f03570e) and is getting back into it after the instrument sat unused for years.[^e-263acdd35f] ^d30ba73d

[^e-263acdd35f]: Time: `2023-02`; Sources: [locomo/thread_cbcd98836154/msg_4efa0dd0ad5d](../../sources/locomo/thread_cbcd98836154.md#source-d36bc6e70ac12196)

The user is also developing [cityscape](../hobbies/photography.md#^0b90e2bd) and [street-art photography](../hobbies/photography.md#^dba783d8) skills and collects [Funko Pops, action figures, comic books, and coins](../hobbies/collecting.md#^fa5a0d44).[^e-f721a80ad4] ^43f27d4c

[^e-f721a80ad4]: Time: `2023-02`; Sources: [locomo/thread_7c96790ff4be/msg_78118bc0cf54](../../sources/locomo/thread_7c96790ff4be.md#source-0f9d10005397692e), [locomo/thread_100ba0195b99/msg_ebd760f46e80](../../sources/locomo/thread_100ba0195b99.md#source-b010eae73e629d10)

The user is trying to set boundaries with their kids while making sure they feel loved and respected, and is seeking advice on promoting respectful and loving communication with children.[^e-74e8b124f0] ^a762bbbf

[^e-74e8b124f0]: Time: `2023-02-15`; Sources: [locomo/thread_6e68d84c9eb7/msg_1bb8cc175d85](../../sources/locomo/thread_6e68d84c9eb7.md#source-211273aecf443912), [locomo/thread_6e68d84c9eb7/msg_2305e4dad9b9](../../sources/locomo/thread_6e68d84c9eb7.md#source-949167dad9aff055), [locomo/thread_6e68d84c9eb7/msg_a6c25b17a85a](../../sources/locomo/thread_6e68d84c9eb7.md#source-8267e5a813efb80b)

The user especially appreciated the advice to focus on the child's behavior rather than their character when disciplining and setting boundaries, and plans to keep that principle in mind.[^e-a48b3103d6] ^9f96ac87

[^e-a48b3103d6]: Time: `2023-02-15`; Sources: [locomo/thread_6e68d84c9eb7/msg_2be7cdd4bb07](../../sources/locomo/thread_6e68d84c9eb7.md#source-6581fd6c442c711e), [locomo/thread_6e68d84c9eb7/msg_4d513b056e22](../../sources/locomo/thread_6e68d84c9eb7.md#source-e64311435136cbcc)

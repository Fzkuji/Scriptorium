# Consulting

The user started their dream job at a top consulting firm on February 15, 2023, which they described as another significant milestone in their career, and wants to make a good impression.[^e-ae7333b28b] ^0efb0d3f

[^e-ae7333b28b]: Time: `2023-02-15`; Sources: [locomo/thread_7ad370356362/msg_cf31fbfc2cc1](../../sources/locomo/thread_7ad370356362.md#source-20ae3a1bdecb4216)

The user is setting up a task management system for their consulting work and chose to start with Todoist, planning to integrate it with Google Calendar and use priority levels (P1-P4), Labels for categorizing tasks, and Filters for custom views of the task list.[^e-5d5f57a68b] ^b7c58857

[^e-5d5f57a68b]: Time: `2023-02-15`; Sources: [locomo/thread_7ad370356362/msg_37a8ed176ced](../../sources/locomo/thread_7ad370356362.md#source-fcb254a2d25d6a29), [locomo/thread_7ad370356362/msg_ea7646ca78b8](../../sources/locomo/thread_7ad370356362.md#source-85dbb7853648edf3), [locomo/thread_7ad370356362/msg_fa994f441834](../../sources/locomo/thread_7ad370356362.md#source-083ef022c95c5910), [locomo/thread_7ad370356362/msg_2b7efd389e24](../../sources/locomo/thread_7ad370356362.md#source-8ba640741ca71e59), [locomo/thread_7ad370356362/msg_4690d0ff07cd](../../sources/locomo/thread_7ad370356362.md#source-72dda7e8710e58c9), [locomo/thread_7ad370356362/msg_31c3e388359e](../../sources/locomo/thread_7ad370356362.md#source-1e87f0fe4b43586c), [locomo/thread_7ad370356362/msg_259f09de3bbe](../../sources/locomo/thread_7ad370356362.md#source-bedd177eca667cfc)

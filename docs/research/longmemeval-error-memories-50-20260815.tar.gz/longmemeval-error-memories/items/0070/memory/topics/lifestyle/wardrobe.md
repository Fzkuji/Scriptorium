# Wardrobe

## Closet Organization

The user is organizing their closet and started decluttering by category, beginning with their tops and then their short-sleeve shirts, sorting items into keep, donate, and discard piles.[^e-bcd804a5d5] ^68e573c9

[^e-bcd804a5d5]: Time: `2023-02`; Sources: [locomo/thread_782f9c17d73c/msg_b64a37705e35](../../sources/locomo/thread_782f9c17d73c.md#source-9a835dadfbf53491), [locomo/thread_782f9c17d73c/msg_d909c89fe56c](../../sources/locomo/thread_782f9c17d73c.md#source-ad23f3045e42eeca), [locomo/thread_782f9c17d73c/msg_c12d70257935](../../sources/locomo/thread_782f9c17d73c.md#source-5e8321495a35e8c0), [locomo/thread_782f9c17d73c/msg_a6b059ce2b87](../../sources/locomo/thread_782f9c17d73c.md#source-787a4f9d4f6b08ac)

The user is organizing their closet after the holiday season and still has winter clothes to put away, and is considering storing out-of-season clothes in labeled containers; they plan to organize their closet this weekend by season, storing winter clothes like their thick grey scarf and gloves in boxes they already have at home and bringing out spring clothes like their yellow sundress.[^e-59e9914e1d][^e-ec3312031a] ^2b1d2642 ^c6655890

[^e-59e9914e1d]: Time: `2023-02`; Sources: [locomo/thread_aaa7a92208f6/msg_8b3dc879fb94](../../sources/locomo/thread_aaa7a92208f6.md#source-102bf208edd54a78), [locomo/thread_aaa7a92208f6/msg_f6fae4c00dfe](../../sources/locomo/thread_aaa7a92208f6.md#source-44823ba473b45d8c)

[^e-ec3312031a]: Time: `2023-02`; Sources: [locomo/thread_85a4c6cb88e4/msg_7d4597b48c1f](../../sources/locomo/thread_85a4c6cb88e4.md#source-3e1244b164ec31b8), [locomo/thread_85a4c6cb88e4/msg_306129b77529](../../sources/locomo/thread_85a4c6cb88e4.md#source-aa4b8849c9b101b3)

## Clothing & Purchases

The user recently bought new black jeans from Levi's and a white button-down shirt from H&M and is considering how these new pieces fit into their wardrobe; they wore the new black jeans on a dinner date last Friday.[^e-2a5e50fc98][^e-1d40dc8798] ^6cf78d22

[^e-2a5e50fc98]: Time: `2023-02`; Sources: [locomo/thread_782f9c17d73c/msg_0bf7a1000f32](../../sources/locomo/thread_782f9c17d73c.md#source-a54ce35ac3e2c0e0)

[^e-1d40dc8798]: Time: `2023-02-10`; Sources: [locomo/thread_85a4c6cb88e4/msg_09c255ae0eb8](../../sources/locomo/thread_85a4c6cb88e4.md#source-b753ff2e5aa7b201)

The user bought boots at Zara on February 5th that were too small, exchanged them for a larger size, and still needs to pick up the new pair.[^e-839e1da25f] ^712f3d04

[^e-839e1da25f]: Time: `2023-02-05`; Sources: [locomo/thread_aaa7a92208f6/msg_3b8e306169b8](../../sources/locomo/thread_aaa7a92208f6.md#source-6f360b8fd76a3e9f), [locomo/thread_aaa7a92208f6/msg_9e1fa9b79ac9](../../sources/locomo/thread_aaa7a92208f6.md#source-717cdf0c6d16c210)

The user plans to use a notes app on their phone to keep track of items they need to pick up or return, such as the Zara boots exchange, because they sometimes forget when they rely on memory.[^e-954312a5dd] ^15779c61

[^e-954312a5dd]: Time: `2023-02`; Sources: [locomo/thread_85a4c6cb88e4/msg_306129b77529](../../sources/locomo/thread_85a4c6cb88e4.md#source-aa4b8849c9b101b3), [locomo/thread_85a4c6cb88e4/msg_5137ed1d4de5](../../sources/locomo/thread_85a4c6cb88e4.md#source-6f6ff93e083c6fa8)

The user is deciding what to wear to an outdoor [concert](../music/la-music.md#^8991ae3b) this weekend in the winter; they lent their green sweater to their sister and aren't sure when it will be returned, and they also considered their yellow sundress before being advised it is too early in the season for an outdoor winter concert.[^e-0e53693b17] ^4650c846

[^e-0e53693b17]: Time: `2023-02`; Sources: [locomo/thread_aaa7a92208f6/msg_d775b76e59a0](../../sources/locomo/thread_aaa7a92208f6.md#source-00354b3efdd90ed0), [locomo/thread_aaa7a92208f6/msg_7a87c69c4444](../../sources/locomo/thread_aaa7a92208f6.md#source-55b06a2c50f7bdbd), [locomo/thread_aaa7a92208f6/msg_47a8a6a34e5a](../../sources/locomo/thread_aaa7a92208f6.md#source-2ebd1848184c96fa), [locomo/thread_aaa7a92208f6/msg_36450f4424a0](../../sources/locomo/thread_aaa7a92208f6.md#source-346d40c6a750cb5d)

## Laundry & Care

The user still needs to pick up their dry cleaning for the navy blue blazer they wore to a meeting a few weeks ago.[^e-095b67ee10] ^25eac93a

[^e-095b67ee10]: Time: `2023-02`; Sources: [locomo/thread_782f9c17d73c/msg_b64a37705e35](../../sources/locomo/thread_782f9c17d73c.md#source-9a835dadfbf53491), [locomo/thread_782f9c17d73c/msg_44649b04c9bb](../../sources/locomo/thread_782f9c17d73c.md#source-3dacea34f86da7ae)

The user planned to do a load of laundry this weekend and asked for tips on preventing socks from getting lost in the wash, and also planned to wash their favorite yoga pants, which they wore to the gym last Thursday, and asked how to keep them looking their best.[^e-c19173c512][^e-5ecada97e1] ^99f84c42 ^c37ed523

[^e-c19173c512]: Time: `2023-02`; Sources: [locomo/thread_aaa7a92208f6/msg_75ad9734e141](../../sources/locomo/thread_aaa7a92208f6.md#source-cbfd99d1cd502542), [locomo/thread_aaa7a92208f6/msg_de4fe160bc75](../../sources/locomo/thread_aaa7a92208f6.md#source-c5936b7ee355c6d7)

[^e-5ecada97e1]: Time: `2023-02-09`; Sources: [locomo/thread_aaa7a92208f6/msg_b3397aecbed5](../../sources/locomo/thread_aaa7a92208f6.md#source-ee22dda4d2930c63), [locomo/thread_aaa7a92208f6/msg_6f3f180b9e1a](../../sources/locomo/thread_aaa7a92208f6.md#source-48385c3c98226616)

The user's gym bag has been smelling and needs to be cleaned, and they are thinking of dedicating a specific day each week to doing laundry and cleaning their gym gear to keep their workout clothes organized and fresh.[^e-d4982065cc] ^73fde626

[^e-d4982065cc]: Time: `2023-02`; Sources: [locomo/thread_85a4c6cb88e4/msg_e92371480974](../../sources/locomo/thread_85a4c6cb88e4.md#source-c487346a7806b798), [locomo/thread_85a4c6cb88e4/msg_17e408ca2f35](../../sources/locomo/thread_85a4c6cb88e4.md#source-14950ade077300af)

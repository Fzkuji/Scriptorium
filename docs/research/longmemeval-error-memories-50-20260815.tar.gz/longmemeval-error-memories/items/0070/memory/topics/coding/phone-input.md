# Phone Input JavaScript

The user is working on a JavaScript phone-input keypad that wires `input[type=button]` buttons to an `input[type=tel]` field, giving each button a tabIndex for keyboard navigation and using Shift+Tab on the first button to return focus to the tel input.[^e-f27ec869fb] ^aecc1d8c

[^e-f27ec869fb]: Time: `2023-02`; Sources: [locomo/thread_01ea86c3d49e/msg_099b87789e90](../../sources/locomo/thread_01ea86c3d49e.md#source-9753659f08da0f61), [locomo/thread_01ea86c3d49e/msg_323bf8521193](../../sources/locomo/thread_01ea86c3d49e.md#source-6e632e623a19c523), [locomo/thread_01ea86c3d49e/msg_2f041590d6d6](../../sources/locomo/thread_01ea86c3d49e.md#source-ccbbd07326267011)

The user refactored the phone-input code to attach event listeners with `forEach` over arrays of event/action objects, and discussed further refactoring such as extracting an `addEventListeners` helper, grouping events per input into a single object, or using a class.[^e-366e8acbe7] ^a4ff2f1a

[^e-366e8acbe7]: Time: `2023-02`; Sources: [locomo/thread_01ea86c3d49e/msg_38308d4cbd48](../../sources/locomo/thread_01ea86c3d49e.md#source-0817bfdeaae8ee78), [locomo/thread_01ea86c3d49e/msg_9b96d338f175](../../sources/locomo/thread_01ea86c3d49e.md#source-99ffec8bc9ba20ae), [locomo/thread_01ea86c3d49e/msg_e7e524d0b642](../../sources/locomo/thread_01ea86c3d49e.md#source-eef94db99f377467), [locomo/thread_01ea86c3d49e/msg_809277cf7b19](../../sources/locomo/thread_01ea86c3d49e.md#source-d875231feb01ea52), [locomo/thread_01ea86c3d49e/msg_ac620abc2e9b](../../sources/locomo/thread_01ea86c3d49e.md#source-53c9562aa914398e)

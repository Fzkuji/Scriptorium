# Religious History

The user is interested in the practices and customs of Anabaptist communities during the Reformation, including adult baptism, communal living, pacifism, separation from the world, simple living, mutual aid, self-government, and religious freedom, and learned that these communities were persecuted by both Protestant and Catholic authorities; they are also interested in how the Anabaptist movement influenced other religious groups such as the Mennonites, Amish, Hutterites, Brethren, and Quakers, and asked whether Anabaptist ideas could still be relevant today.[^e-6bf8779cb3][^e-9c53093872] ^55703e55 ^c5d19f62

[^e-6bf8779cb3]: Time: `2023-02`; Sources: [locomo/thread_023f8650f638/msg_0225eb431b77](../../sources/locomo/thread_023f8650f638.md#source-0e82838c5d4f1111), [locomo/thread_023f8650f638/msg_5cc39f69fb27](../../sources/locomo/thread_023f8650f638.md#source-065a44001a08aed1)

[^e-9c53093872]: Time: `2023-02`; Sources: [locomo/thread_023f8650f638/msg_73b99f46c32b](../../sources/locomo/thread_023f8650f638.md#source-727d7a6d83be22ec), [locomo/thread_023f8650f638/msg_583f63aa40db](../../sources/locomo/thread_023f8650f638.md#source-c68105d4a5571f3e)

The user agreed that Anabaptist values such as community and nonviolence are still relevant today and learned about modern-day communities that follow these principles, including Mennonite and Amish communities, the Bruderhof (an intentional Christian community founded in 1920s Germany committed to economic sharing, sustainability, and peacemaking), Quaker communities, the Catholic Worker movement (founded in the 1930s), and various intentional communities.[^e-e250d8f6d3] ^4ebc1f79

[^e-e250d8f6d3]: Time: `2023-02-15`; Sources: [locomo/thread_023f8650f638/msg_472474116c3b](../../sources/locomo/thread_023f8650f638.md#source-7ecfee72f542f955), [locomo/thread_023f8650f638/msg_b2bed7b0b88e](../../sources/locomo/thread_023f8650f638.md#source-8da43f2995b7895f)

The user asked whether the Anabaptist movement had an impact on the civil rights movement and learned that Anabaptist ideas of nonviolence, solidarity and community building, religious freedom and tolerance, and peaceful civil disobedience were an important influence on civil rights activists in the United States and beyond.[^e-473227a30f] ^b2fed07a

[^e-473227a30f]: Time: `2023-02-15`; Sources: [locomo/thread_023f8650f638/msg_267560f5af42](../../sources/locomo/thread_023f8650f638.md#source-af3d6d0787d62c08), [locomo/thread_023f8650f638/msg_ddb8e14bcb4d](../../sources/locomo/thread_023f8650f638.md#source-1745549ded17252d)

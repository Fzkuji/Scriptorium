# Los Angeles Music Scene

The user attended a Billie Eilish concert at the Los Angeles Forum with their best friend [Rachel](../people/rachel.md#^dd6197eb) on 2023-02-15, and their favorite moment was Billie performing "Bad Guy" with the whole crowd singing along.[^e-4674fa98cf] ^d8e8c630

[^e-4674fa98cf]: Time: `2023-02-15`; Sources: [locomo/thread_6bc2090ac4de/msg_a24e4dfe6c20](../../sources/locomo/thread_6bc2090ac4de.md#source-a32718f8a803603d), [locomo/thread_6bc2090ac4de/msg_2719e25a26a0](../../sources/locomo/thread_6bc2090ac4de.md#source-3dd95118165ede9d)

The user is looking to buy headphones for music festivals and concerts that can block out loud noise.[^e-89f79a4baa] ^76ee09e7

[^e-89f79a4baa]: Time: `2023-02`; Sources: [locomo/thread_6bc2090ac4de/msg_a24e4dfe6c20](../../sources/locomo/thread_6bc2090ac4de.md#source-a32718f8a803603d)

The user plans to attend more concerts and festivals in the Los Angeles area.[^e-7c5c8d8ae7] ^8991ae3b

[^e-7c5c8d8ae7]: Time: `2023-02`; Sources: [locomo/thread_6bc2090ac4de/msg_f8754e93bfdc](../../sources/locomo/thread_6bc2090ac4de.md#source-dee9d2afa1a5912e)

The user is thinking of attending a classical concert at the Hollywood Bowl with the LA Philharmonic, which would be their first classical concert, and is interested in Tchaikovsky's 1812 Overture.[^e-d474fb3e60] ^913c8a6c

[^e-d474fb3e60]: Time: `2023-02`; Sources: [locomo/thread_6bc2090ac4de/msg_2719e25a26a0](../../sources/locomo/thread_6bc2090ac4de.md#source-3dd95118165ede9d), [locomo/thread_6bc2090ac4de/msg_286878ba2ab6](../../sources/locomo/thread_6bc2090ac4de.md#source-830dfa66711d3ef2)

# Family Trips

The user's last [family trip to Hawaii](../people/user.md#^13ca8b17) was amazing but hectic, requiring them to manage the kids' schedules and nap times.[^e-a3b86490b7] ^6866c0b9

[^e-a3b86490b7]: Time: `undated`; Sources: [locomo/thread_37d993f7a9d6/msg_dfde6a0693d2](../../sources/locomo/thread_37d993f7a9d6.md#source-6069515421af360a)

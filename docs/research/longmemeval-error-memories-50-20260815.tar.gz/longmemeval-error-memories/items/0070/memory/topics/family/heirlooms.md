# Family Heirlooms

The user's family heirlooms include their grandmother's vintage diamond necklace, an antique music box, and a vintage typewriter; they are considering getting the necklace insured and [selling some of these items](../lifestyle/home-organization.md#^54cb52d6).[^e-fd2c68e3a3] ^66ac25a4

[^e-fd2c68e3a3]: Time: `2023-02-15`; Sources: [locomo/thread_e85fb7a5fdaa/msg_9cf6ec6ac876](../../sources/locomo/thread_e85fb7a5fdaa.md#source-78e91c3cb4189370), [locomo/thread_e85fb7a5fdaa/msg_6fc8dcacf93d](../../sources/locomo/thread_e85fb7a5fdaa.md#source-b22c0b6375e06159)

The user is researching their great-grandfather's antique clock collection and plans to start with the National Association of Watch and Clock Collectors website and the Clock Collectors Forum, reach out to local clock dealers and collectors in the area where their great-grandfather lived, and ask family members if they know anything about the clocks or have any photos or documents related to them.[^e-fb5c889026] ^67775da0

[^e-fb5c889026]: Time: `2023-02-15`; Sources: [locomo/thread_e85fb7a5fdaa/msg_aeb41ccca1d7](../../sources/locomo/thread_e85fb7a5fdaa.md#source-07df541c8aa32e38), [locomo/thread_e85fb7a5fdaa/msg_4db1ca81c322](../../sources/locomo/thread_e85fb7a5fdaa.md#source-f4bcfd718bec2398), [locomo/thread_e85fb7a5fdaa/msg_82036e3667b3](../../sources/locomo/thread_e85fb7a5fdaa.md#source-baa2ea07b4716887)

The user's grandmother told them she remembers trying on the vintage diamond necklace when she was a kid and feeling like a princess, and the user plans to ask her open-ended questions about the clock collection since she may have personal memories or photos and documents related to the clocks.[^e-631b89fa8c] ^b219d9ee

[^e-631b89fa8c]: Time: `2023-02-15`; Sources: [locomo/thread_e85fb7a5fdaa/msg_6ec44c120a29](../../sources/locomo/thread_e85fb7a5fdaa.md#source-9980cb2edaac333d), [locomo/thread_e85fb7a5fdaa/msg_4187f392cc94](../../sources/locomo/thread_e85fb7a5fdaa.md#source-d2a895a6e2e41d0e)

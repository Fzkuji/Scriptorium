# Health & Wellness

## Heart Health

The user asked about daily habits that can improve heart health, including eating a balanced diet, regular physical activity, maintaining a healthy weight, limiting alcohol and avoiding smoking, getting adequate sleep, managing stress, and monitoring blood pressure and cholesterol.[^e-6a7d313559] ^d37aa48b

[^e-6a7d313559]: Time: `2023-02`; Sources: [locomo/thread_22a07b103833/msg_9da1bd635b0c](../../sources/locomo/thread_22a07b103833.md#source-d42095b57ab716fd), [locomo/thread_22a07b103833/msg_b625ff29c59f](../../sources/locomo/thread_22a07b103833.md#source-025edd7557cacace)

The user plans to start going for a walk every morning to improve their heart health.[^e-4911f439c1] ^62b7fb0a

[^e-4911f439c1]: Time: `2023-02`; Sources: [locomo/thread_22a07b103833/msg_ced81efbac89](../../sources/locomo/thread_22a07b103833.md#source-a932703ce1aaf392), [locomo/thread_22a07b103833/msg_fdf24b7882b4](../../sources/locomo/thread_22a07b103833.md#source-c5eb0bf4c2b72ead)

## Healthy Eating

The user struggles to stick with healthy eating because they don't enjoy the taste of some healthy foods, and asked for advice on how to make healthy eating more enjoyable. They really like the idea of experimenting with new herbs and spices to add more flavor to meals, are excited to try new spices in their [cooking](../cooking/seasonal-cooking.md#^0c0fa74b), and asked for meal-planning tips to ensure they get a balanced diet.[^e-bfc3b923b5][^e-d3cfb6e747][^e-a7c225fd2d] ^8cbf2f91 ^e8109ba7

[^e-bfc3b923b5]: Time: `2023-02`; Sources: [locomo/thread_22a07b103833/msg_9e635e66f55b](../../sources/locomo/thread_22a07b103833.md#source-69b40aca959dfda8)

[^e-d3cfb6e747]: Time: `2023-02`; Sources: [locomo/thread_22a07b103833/msg_24d2799c070f](../../sources/locomo/thread_22a07b103833.md#source-2bc45866ec920d5f)

[^e-a7c225fd2d]: Time: `2023-02`; Sources: [locomo/thread_22a07b103833/msg_2bc824d8b759](../../sources/locomo/thread_22a07b103833.md#source-4d0cd054857164cd), [locomo/thread_22a07b103833/msg_27fb9ea80f92](../../sources/locomo/thread_22a07b103833.md#source-8cf4113f918ff4b2)

## Sleep

The user started having trouble falling asleep about three weeks before mid-February 2023 and has been improving their sleep by getting ready for bed around 10–10:30 PM, cutting back on afternoon caffeine (they used to enjoy coffee or tea around 4–5 PM), and [reading before bed](../hobbies/reading.md#^0b1f27bc), which has been helping a lot.[^e-a01ba2e0b7][^e-4a140f1957] ^aa7267cb

[^e-a01ba2e0b7]: Time: `2023-01-25`; Sources: [locomo/thread_cb51e23a7220/msg_527717f48654](../../sources/locomo/thread_cb51e23a7220.md#source-0d1840013b057532)

[^e-4a140f1957]: Time: `2023-02`; Sources: [locomo/thread_cb51e23a7220/msg_527717f48654](../../sources/locomo/thread_cb51e23a7220.md#source-0d1840013b057532), [locomo/thread_cb51e23a7220/msg_076547da6156](../../sources/locomo/thread_cb51e23a7220.md#source-631de7cd30430e75), [locomo/thread_cb51e23a7220/msg_6303874eeb15](../../sources/locomo/thread_cb51e23a7220.md#source-31035d170ccbcdf0)

## Speech Therapy

The user is pursuing speech therapy to improve their communication skills, plans to find a speech-language pathologist in their area, and is committed to completing the recommended course of therapy and practicing consistently outside of sessions.[^e-f4dc0e5b00][^e-e96a54b286] ^eec415bb

[^e-f4dc0e5b00]: Time: `2023-02`; Sources: [locomo/thread_4b21292cb720/msg_585af530996e](../../sources/locomo/thread_4b21292cb720.md#source-140b6c7130febcf4), [locomo/thread_4b21292cb720/msg_6717c54de530](../../sources/locomo/thread_4b21292cb720.md#source-e43cbdbd9cc27615)

[^e-e96a54b286]: Time: `2023-02`; Sources: [locomo/thread_4b21292cb720/msg_b98e03f7e622](../../sources/locomo/thread_4b21292cb720.md#source-74be01f6ec33464a), [locomo/thread_4b21292cb720/msg_d8a272cf1565](../../sources/locomo/thread_4b21292cb720.md#source-81e31b5dfe2e7fe2)

For speech therapy practice, the user plans to break practice into shorter sessions throughout the day and is looking for fun games and activities, such as tongue twisters, word games, charades, and Mad Libs, to make practice engaging.[^e-fd823fdf85] ^a5352a14

[^e-fd823fdf85]: Time: `2023-02`; Sources: [locomo/thread_4b21292cb720/msg_4c12f8dbf610](../../sources/locomo/thread_4b21292cb720.md#source-3566ca66dc1a409f), [locomo/thread_4b21292cb720/msg_b50682e5fd45](../../sources/locomo/thread_4b21292cb720.md#source-f8ca063389d9f617)

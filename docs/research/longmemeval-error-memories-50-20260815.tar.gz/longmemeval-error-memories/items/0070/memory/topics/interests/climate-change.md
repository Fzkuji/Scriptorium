# Climate Change

The user is interested in climate change reporting and has been reading The Independent's coverage, which began with the UN Framework Convention on Climate Change in 1992 and has evolved into an increasingly urgent call for action, including criticism of governments and corporations and coverage of solutions such as renewable energy.[^e-085431cf6a] ^f89d5749

[^e-085431cf6a]: Time: `2023-02`; Sources: [locomo/thread_810c4bac6d0f/msg_40ebc5271110](../../sources/locomo/thread_810c4bac6d0f.md#source-9f03b52650c20a1d), [locomo/thread_810c4bac6d0f/msg_f541f64c9f38](../../sources/locomo/thread_810c4bac6d0f.md#source-7c695f93c62976f3)

The user is concerned about whether mainstream media does enough on climate change reporting and has considered how media coverage both raises awareness and can get caught up in political debate.[^e-abc1b2d3db] ^cb4cc268

[^e-abc1b2d3db]: Time: `2023-02`; Sources: [locomo/thread_810c4bac6d0f/msg_71e8197a0b28](../../sources/locomo/thread_810c4bac6d0f.md#source-d683ad061cc66eb8), [locomo/thread_810c4bac6d0f/msg_047289756f75](../../sources/locomo/thread_810c4bac6d0f.md#source-34ec6a65e6718ed9)

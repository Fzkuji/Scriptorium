# Commute & Cycling

The user commutes by train, taking the 7:15 am train from station A to station B every weekday morning (for the past 3 months) and arriving at station B around 7:45 am, and is considering incorporating cycling into their routine with a foldable bike for the 10-15 minute ride from the station to work.[^e-0acedfe7b5] ^18674433

[^e-0acedfe7b5]: Time: `2023-02-15`; Sources: [locomo/thread_d5369eec43f1/msg_f4c416079023](../../sources/locomo/thread_d5369eec43f1.md#source-ee51e609c80a9198), [locomo/thread_d5369eec43f1/msg_0c02aad8863e](../../sources/locomo/thread_d5369eec43f1.md#source-14684dae2d2281d3), [locomo/thread_d5369eec43f1/msg_df6584837c48](../../sources/locomo/thread_d5369eec43f1.md#source-30508f9f81cde9ff)

The user, who is not an avid cyclist, is researching foldable bikes for a short commute and considered models including the Tern Link D8, Brompton M6L, Dahon Curve D3, GoCycle GS, and Decathlon B'Twin Tilt 120, and is looking for bike shops near station B that open by 7:30 am so they can test ride before work.[^e-ab34d5d42e] ^6de7c35a

[^e-ab34d5d42e]: Time: `2023-02-15`; Sources: [locomo/thread_d5369eec43f1/msg_f494b6626eb1](../../sources/locomo/thread_d5369eec43f1.md#source-2ee7d0024a6a5b56), [locomo/thread_d5369eec43f1/msg_de327104af40](../../sources/locomo/thread_d5369eec43f1.md#source-dac99eed0b2fe6be), [locomo/thread_d5369eec43f1/msg_a0d4abf57702](../../sources/locomo/thread_d5369eec43f1.md#source-bfbb3d24e39ec99e)

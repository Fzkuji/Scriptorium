# Invasive Species

The user is interested in how invasive species impact food web dynamics and ecosystem functioning in temperate forests, including disrupting nutrient cycles, altering habitat structure, and outcompeting or preying on native species.[^e-8637eb4d4d] ^8eeea8e7

[^e-8637eb4d4d]: Time: `2023-02`; Sources: [locomo/thread_6e5fb66a8677/msg_08f7475963fc](../../sources/locomo/thread_6e5fb66a8677.md#source-2059ace6acacdfb8), [locomo/thread_6e5fb66a8677/msg_23f06e476787](../../sources/locomo/thread_6e5fb66a8677.md#source-3bbdd5ff7d83bb85)

The user wants to help prevent the spread of invasive species and plans to learn to identify local invasive species, check camping gear and boats for hitchhiking species, dispose of trash properly, plant native species, and volunteer with conservation organizations.[^e-4b999470a9] ^23d27d09

[^e-4b999470a9]: Time: `2023-02`; Sources: [locomo/thread_6e5fb66a8677/msg_88ea2a72357e](../../sources/locomo/thread_6e5fb66a8677.md#source-3ab9d49353290d8d), [locomo/thread_6e5fb66a8677/msg_a3dff09a9f15](../../sources/locomo/thread_6e5fb66a8677.md#source-15e665898f5596e7)

The user hikes and camps and will keep an eye out for invasive species, reporting any suspected sightings with photos and location information rather than removing them, and will be more careful when camping or traveling to a new area.[^e-c7b07ec363] ^9526ee3f

[^e-c7b07ec363]: Time: `2023-02`; Sources: [locomo/thread_6e5fb66a8677/msg_ecc74d9a0ecf](../../sources/locomo/thread_6e5fb66a8677.md#source-0101ef3aa2d582ee), [locomo/thread_6e5fb66a8677/msg_0d0337d3fde6](../../sources/locomo/thread_6e5fb66a8677.md#source-2453286123c71556), [locomo/thread_6e5fb66a8677/msg_cb47dfad1a3a](../../sources/locomo/thread_6e5fb66a8677.md#source-a19a7bf435aa858a), [locomo/thread_6e5fb66a8677/msg_cfa40338e702](../../sources/locomo/thread_6e5fb66a8677.md#source-d3b430494dc9ca8b)

The user asked for recommendations of resources to help them learn to identify invasive species, including iNaturalist, the USDA Plants Database, and their state department of natural resources.[^e-99273e691a] ^3048fa9b

[^e-99273e691a]: Time: `2023-02`; Sources: [locomo/thread_6e5fb66a8677/msg_ecc74d9a0ecf](../../sources/locomo/thread_6e5fb66a8677.md#source-0101ef3aa2d582ee), [locomo/thread_6e5fb66a8677/msg_32636dae5f43](../../sources/locomo/thread_6e5fb66a8677.md#source-e7566968c2f5e575)

# Rachel

Rachel is the user's best friend; they attended the [Billie Eilish concert at the Los Angeles Forum](../music/la-music.md#^d8e8c630) together on 2023-02-15.[^e-ca3a472de0] ^dd6197eb

[^e-ca3a472de0]: Time: `2023-02-15`; Sources: [locomo/thread_6bc2090ac4de/msg_a24e4dfe6c20](../../sources/locomo/thread_6bc2090ac4de.md#source-a32718f8a803603d)

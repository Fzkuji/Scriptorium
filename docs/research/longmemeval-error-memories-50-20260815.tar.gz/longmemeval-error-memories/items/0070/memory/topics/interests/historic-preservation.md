# Historic Preservation

The user is interested in the history of Gorton, Manchester and how its historical landmarks evolved over time, and in the community's role in preserving them; they are also curious about the role of technology in preserving historical landmarks and cultural heritage.[^e-898ab05ff0][^e-88825e4357] ^a35f73d3 ^85a00438

[^e-898ab05ff0]: Time: `2023-02`; Sources: [locomo/thread_5623a6557221/msg_aa8874e72af8](../../sources/locomo/thread_5623a6557221.md#source-69a42660a73a7919), [locomo/thread_5623a6557221/msg_04f911880f68](../../sources/locomo/thread_5623a6557221.md#source-feac40c29701a587)

[^e-88825e4357]: Time: `2023-02`; Sources: [locomo/thread_5623a6557221/msg_1ba1e9ca8f74](../../sources/locomo/thread_5623a6557221.md#source-b3179bdecb7e1f42), [locomo/thread_5623a6557221/msg_e1c7efab79a0](../../sources/locomo/thread_5623a6557221.md#source-8279591945f442ea), [locomo/thread_5623a6557221/msg_76f2ebf48b74](../../sources/locomo/thread_5623a6557221.md#source-2c6aa351cbcfb665)

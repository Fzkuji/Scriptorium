# San Francisco Trip

The user is planning a trip to San Francisco and is looking for bars with outdoor seating and live music in Fisherman's Wharf or nearby; they recently stayed at the Hotel Zeppelin in San Francisco for a friend's bachelor party, in a room with a great view of the Bay Bridge.[^e-14d38129c3][^e-946b8a5859] ^cf09c25d ^3bb5480b

[^e-14d38129c3]: Time: `2023-02`; Sources: [locomo/thread_749fa3152137/msg_a642c1a18f3f](../../sources/locomo/thread_749fa3152137.md#source-4163a2571ab0f5e7), [locomo/thread_749fa3152137/msg_c88501022bd8](../../sources/locomo/thread_749fa3152137.md#source-a1367db7ea2ffd30)

[^e-946b8a5859]: Time: `2023-02`; Sources: [locomo/thread_749fa3152137/msg_a642c1a18f3f](../../sources/locomo/thread_749fa3152137.md#source-4163a2571ab0f5e7), [locomo/thread_749fa3152137/msg_c88501022bd8](../../sources/locomo/thread_749fa3152137.md#source-a1367db7ea2ffd30)

The user asked about The Ramp, a waterfront bar and grill in China Basin near Oracle Park about a 10-15 minute walk from Fisherman's Wharf, and learned it has a casual, lively atmosphere with nautical decor and a large outdoor patio offering views of the Bay and the Bay Bridge, plus live music on weekends in genres like rock, pop, blues, and folk.[^e-7bdb167646] ^b51e0bde

[^e-7bdb167646]: Time: `2023-02`; Sources: [locomo/thread_749fa3152137/msg_0913bf8fc1b5](../../sources/locomo/thread_749fa3152137.md#source-c0d518f692b45fef), [locomo/thread_749fa3152137/msg_4536eecce9e8](../../sources/locomo/thread_749fa3152137.md#source-28639cf425bc392e), [locomo/thread_749fa3152137/msg_16db1c60e078](../../sources/locomo/thread_749fa3152137.md#source-3a296cc6891580d1), [locomo/thread_749fa3152137/msg_5874bcc16857](../../sources/locomo/thread_749fa3152137.md#source-d341808becf35c40)

The user also looked into The Ramp's food, learning about its seafood, burgers, and sandwiches with most dishes priced $15-$30, a daily 3-6pm happy hour, and a seafood tower priced $40-$60.[^e-813be3b01a] ^6daabe4d

[^e-813be3b01a]: Time: `2023-02`; Sources: [locomo/thread_749fa3152137/msg_a4c530391d7b](../../sources/locomo/thread_749fa3152137.md#source-8b1d6903462f2310), [locomo/thread_749fa3152137/msg_389fd8353426](../../sources/locomo/thread_749fa3152137.md#source-a4be88521ed7e3fe), [locomo/thread_749fa3152137/msg_a0fdefbb25d7](../../sources/locomo/thread_749fa3152137.md#source-9305f94c7e7b42b2), [locomo/thread_749fa3152137/msg_4d533b6188b6](../../sources/locomo/thread_749fa3152137.md#source-2261945359ac6c8b)

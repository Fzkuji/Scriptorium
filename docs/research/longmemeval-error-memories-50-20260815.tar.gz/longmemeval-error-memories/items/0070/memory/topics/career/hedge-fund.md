# Hedge Fund

The user runs a hedge fund and asked for help pitching its competitive advantage to investors; the pitch focuses on advanced scientific R&D in the investment process combined with the wisdom that comes with experience, expressed in plain language without jargon.[^e-ea99d8b2f9][^e-57757c3062] ^8b25e0f2 ^f9233c9f

[^e-ea99d8b2f9]: Time: `2023-02`; Sources: [locomo/thread_5c188c1c98ea/msg_c93b211f719c](../../sources/locomo/thread_5c188c1c98ea.md#source-ad7ffc82fccaa51c)

[^e-57757c3062]: Time: `2023-02`; Sources: [locomo/thread_5c188c1c98ea/msg_2857d8f8371a](../../sources/locomo/thread_5c188c1c98ea.md#source-869e410aa1a04c70), [locomo/thread_5c188c1c98ea/msg_f1a20a57751d](../../sources/locomo/thread_5c188c1c98ea.md#source-5b89f5c0f4cf64e8)

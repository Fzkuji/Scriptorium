# E-commerce Store

## Store Setup

The user is starting an online e-commerce store focused on [sustainable products](../lifestyle/eco-friendly.md#^269b7108), specifically eco-friendly home goods, targeting a national audience with an average order value of around $50 and package weights of 2–3 pounds.[^e-47394fc7f4] They attended a seminar on starting an online business on January 15, 2023, which they found informative and helpful.[^e-7881911265] ^a4ffd6eb

[^e-47394fc7f4]: Time: `2023-02`; Sources: [locomo/thread_de58813e57c1/msg_1f4f531023d1](../../sources/locomo/thread_de58813e57c1.md#source-4d44d4d1c7844697), [locomo/thread_de58813e57c1/msg_05234d01ebd2](../../sources/locomo/thread_de58813e57c1.md#source-fd9a3824899439d2)

[^e-7881911265]: Time: `2023-01-15`; Sources: [locomo/thread_de58813e57c1/msg_1f4f531023d1](../../sources/locomo/thread_de58813e57c1.md#source-4d44d4d1c7844697)

## Shipping & Logistics

For shipping, the user plans to offer free shipping on orders over $75 and is considering USPS Priority Mail as a starting carrier option.[^e-5b9ec5c2cf] ^bbf8f465

[^e-5b9ec5c2cf]: Time: `2023-02`; Sources: [locomo/thread_de58813e57c1/msg_05234d01ebd2](../../sources/locomo/thread_de58813e57c1.md#source-fd9a3824899439d2), [locomo/thread_de58813e57c1/msg_3287fb60bae5](../../sources/locomo/thread_de58813e57c1.md#source-1b767bf8c936083d), [locomo/thread_de58813e57c1/msg_66c72d052f8f](../../sources/locomo/thread_de58813e57c1.md#source-394d3725ea2b1586)

## Returns & Customer Service

The user is setting up their returns and refunds process and is looking into returns management software (such as Returnly, Happy Returns, Narvar, and AfterShip), as well as customer service software (such as Zendesk, Freshdesk, Gorgias, and Reamaze) and a knowledge base to reduce inquiries.[^e-7bab2f1214] ^d0a84aca

[^e-7bab2f1214]: Time: `2023-02`; Sources: [locomo/thread_de58813e57c1/msg_66c72d052f8f](../../sources/locomo/thread_de58813e57c1.md#source-394d3725ea2b1586), [locomo/thread_de58813e57c1/msg_6f2c8fad9077](../../sources/locomo/thread_de58813e57c1.md#source-679ac46dff4da528), [locomo/thread_de58813e57c1/msg_d790286faeeb](../../sources/locomo/thread_de58813e57c1.md#source-d80e2d4a986f8779), [locomo/thread_de58813e57c1/msg_ec83171f3efb](../../sources/locomo/thread_de58813e57c1.md#source-c3c4a36f269a1082)

## Growth & Measurement

The user is planning how to measure their store's success, including setting up Google Analytics and tracking e-commerce and customer metrics, and is building a content marketing strategy to attract and engage their target audience.[^e-6fd2b7fc30] ^f64ae3a0

[^e-6fd2b7fc30]: Time: `2023-02`; Sources: [locomo/thread_de58813e57c1/msg_31c7ba4c5cac](../../sources/locomo/thread_de58813e57c1.md#source-fc89b14202eb4cad), [locomo/thread_de58813e57c1/msg_02624d7d2f20](../../sources/locomo/thread_de58813e57c1.md#source-640cf2eff09b8097), [locomo/thread_de58813e57c1/msg_631d1ceefbfc](../../sources/locomo/thread_de58813e57c1.md#source-40dec2f9e5c492f5), [locomo/thread_de58813e57c1/msg_70cd2b465faa](../../sources/locomo/thread_de58813e57c1.md#source-08022d9f4953c3a0)

# AutoCAD LT 2013

The user is working with AutoCAD LT 2013 and wants to customize the shortcut menu that opens on a right-click so that Zoom Window is the default option.[^e-57569ff99e] ^e0cb7e84

[^e-57569ff99e]: Time: `2023-02-15`; Sources: [locomo/thread_b6fdc3c2643b/msg_f0d74ae50aaa](../../sources/locomo/thread_b6fdc3c2643b.md#source-1c124a978a422942), [locomo/thread_b6fdc3c2643b/msg_051c3dbc49ff](../../sources/locomo/thread_b6fdc3c2643b.md#source-92acb03cae2f997a)

Customizing the right-click menu in AutoCAD LT 2013 proved more limited than in newer versions: the user reported that the CUI dialog has no New Command button, no RButton option in the Customizations In Main CUI pane, and the Mouse Buttons section lists only Click, Shift+Click, Control+Click, and Control+Shift+Click.[^e-12e2416767] ^7b4a35aa

[^e-12e2416767]: Time: `2023-02-15`; Sources: [locomo/thread_b6fdc3c2643b/msg_7679159943d0](../../sources/locomo/thread_b6fdc3c2643b.md#source-ea454525e1b4f702), [locomo/thread_b6fdc3c2643b/msg_79b1830ae93f](../../sources/locomo/thread_b6fdc3c2643b.md#source-7b1e75cde58993c0), [locomo/thread_b6fdc3c2643b/msg_b219c71099df](../../sources/locomo/thread_b6fdc3c2643b.md#source-a93d559dd0b53b50), [locomo/thread_b6fdc3c2643b/msg_e77022dc0d54](../../sources/locomo/thread_b6fdc3c2643b.md#source-3a03cff87f73f1c6), [locomo/thread_b6fdc3c2643b/msg_704761d1e176](../../sources/locomo/thread_b6fdc3c2643b.md#source-702037947ca1b7e9)

The working approach for AutoCAD LT 2013 was to open the Options dialog box, go to the User Preferences tab, open Right-click Customization, and in the CUI dialog select Shortcuts under Customizations In Main CUI, then find the Zoom Window command in the All Commands list, right-click it, and choose Add to Shortcut Menu so Zoom Window becomes the default option on the right-click shortcut menu.[^e-c942171878] ^d901e3bd

[^e-c942171878]: Time: `2023-02-15`; Sources: [locomo/thread_b6fdc3c2643b/msg_0cd7e73387e3](../../sources/locomo/thread_b6fdc3c2643b.md#source-ef793567e7275124)

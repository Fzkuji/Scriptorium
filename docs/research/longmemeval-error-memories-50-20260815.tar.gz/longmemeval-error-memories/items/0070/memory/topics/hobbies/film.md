# Film

The user judged a film festival at their university for the first time and gave a tie for first place in the fiction category; one of the winning films was a semi-autobiographical story about the director's experience growing up as a first-generation immigrant, which stood out for its honesty and vulnerability.[^e-6e23189d8e] ^fef1ba08

[^e-6e23189d8e]: Time: `2023-02`; Sources: [locomo/thread_046276ceb02b/msg_91d0c2e3d774](../../sources/locomo/thread_046276ceb02b.md#source-8f402b2f3ebddfcc), [locomo/thread_046276ceb02b/msg_07f43e3f2ff4](../../sources/locomo/thread_046276ceb02b.md#source-35efa00fe81f235c), [locomo/thread_046276ceb02b/msg_817878b93de4](../../sources/locomo/thread_046276ceb02b.md#source-2d741f259a00a35d)

The user has been enjoying dramas and documentaries lately, prefers feature films and recent releases, and considers strong storytelling and characters the most important aspects of a film.[^e-a9135167d9] ^5716fe4f

[^e-a9135167d9]: Time: `2023-02`; Sources: [locomo/thread_046276ceb02b/msg_20610c3cfbd0](../../sources/locomo/thread_046276ceb02b.md#source-bfb012a87e2319f9), [locomo/thread_046276ceb02b/msg_7940ea7fea7c](../../sources/locomo/thread_046276ceb02b.md#source-aaceada76ff8beba)

The user decided to check out the film Minari, a semi-autobiographical Korean-American drama, because themes of family and identity resonate with them.[^e-1f4604610a] ^2aa9e4ca

[^e-1f4604610a]: Time: `2023-02`; Sources: [locomo/thread_046276ceb02b/msg_07f43e3f2ff4](../../sources/locomo/thread_046276ceb02b.md#source-35efa00fe81f235c)

# Social Media Content Creation

The user runs social media accounts on Instagram, Twitter, Facebook, and YouTube centered on vegan cooking and [sustainable-living content](../lifestyle/eco-friendly.md#^269b7108), and their vegan pizza recipe post was a recent successful post.[^e-6e5a6cbd0b] ^994b983e

[^e-6e5a6cbd0b]: Time: `2023-02`; Sources: [locomo/thread_2722126b02ae/msg_89c8fca8566c](../../sources/locomo/thread_2722126b02ae.md#source-ad3343c88e9e397f), [locomo/thread_2722126b02ae/msg_6ce52dc5c319](../../sources/locomo/thread_2722126b02ae.md#source-b1148d2c90a1c5e4)

On Instagram the user gains an average of 15 new followers per week; on Twitter they gain around 5-7 new followers per week from participating in hashtag challenges; on Facebook the follower count has been stagnant but engagement has increased through joining sustainable-living and zero-waste groups; and on YouTube their most recent video got 120 views in the first week, a significant increase over previous videos.[^e-ec2070c1c6] ^756ecbc2

[^e-ec2070c1c6]: Time: `2023-02`; Sources: [locomo/thread_2722126b02ae/msg_6ce52dc5c319](../../sources/locomo/thread_2722126b02ae.md#source-b1148d2c90a1c5e4)

The user is planning Instagram content for the next month and has researched vegan influencers and engagement strategies to grow their following.[^e-a2df02b604] ^e92502ee

[^e-a2df02b604]: Time: `2023-02`; Sources: [locomo/thread_2722126b02ae/msg_89c8fca8566c](../../sources/locomo/thread_2722126b02ae.md#source-ad3343c88e9e397f), [locomo/thread_2722126b02ae/msg_7f3100be9a74](../../sources/locomo/thread_2722126b02ae.md#source-da4ff7e4d1994078), [locomo/thread_2722126b02ae/msg_b5ca012a7ed8](../../sources/locomo/thread_2722126b02ae.md#source-92114de8daacb4f9)

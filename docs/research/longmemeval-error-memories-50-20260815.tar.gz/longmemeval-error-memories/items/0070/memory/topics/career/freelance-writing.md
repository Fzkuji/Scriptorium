# Freelance Writing Business

The user runs a freelance writing business and is working on improving its social media presence; on Twitter they found that researched hashtags increased engagement, with the same post receiving 5 comments after they used researched hashtags.[^e-e461292a2b] ^c36f639b

[^e-e461292a2b]: Time: `2023-02`; Sources: [locomo/thread_3dfeec2de60c/msg_8c4ecc50b41f](../../sources/locomo/thread_3dfeec2de60c.md#source-7de3472b38635a32)

On Instagram the user focuses on self-care and mindfulness content and found that using more specific niche hashtags and posting every day for a week with a different self-care theme increased engagement.[^e-2ebd51b0e5] ^c3cc3f09

[^e-2ebd51b0e5]: Time: `2023-02`; Sources: [locomo/thread_3dfeec2de60c/msg_1ad73b6abe91](../../sources/locomo/thread_3dfeec2de60c.md#source-8b203e1d58e7608f), [locomo/thread_3dfeec2de60c/msg_2ec661761e54](../../sources/locomo/thread_3dfeec2de60c.md#source-69f1c27a63f1799a)

The user decided to plan Instagram content in advance using a content calendar while leaving room for spontaneity, and to post at the same time most days while occasionally mixing up the posting schedule to reach a broader audience.[^e-fa393b058e] ^9d01b3da

[^e-fa393b058e]: Time: `2023-02`; Sources: [locomo/thread_3dfeec2de60c/msg_700c3abe7a3c](../../sources/locomo/thread_3dfeec2de60c.md#source-6211eb4f9f499a3f), [locomo/thread_3dfeec2de60c/msg_273992d43d51](../../sources/locomo/thread_3dfeec2de60c.md#source-c780e7db104e3cb5), [locomo/thread_3dfeec2de60c/msg_c6071a918886](../../sources/locomo/thread_3dfeec2de60c.md#source-7e4f1cf580fca35a)

# Farm Operations

The user is thinking of expanding their farm's operations and is considering raising Nigerian Dwarf goats.[^e-41cd79be46] ^1e052cb1

[^e-41cd79be46]: Time: `2023-02`; Sources: [locomo/thread_7a2d72a9009a/msg_cef6e3a88f68](../../sources/locomo/thread_7a2d72a9009a.md#source-52c4794a71fd2442)

The user's water buckets arrived two days after they were ordered, which was convenient and has made a big difference in daily operations.[^e-6f87ebefd2] ^6c020987

[^e-6f87ebefd2]: Time: `2023-02`; Sources: [locomo/thread_7a2d72a9009a/msg_cef6e3a88f68](../../sources/locomo/thread_7a2d72a9009a.md#source-52c4794a71fd2442), [locomo/thread_7a2d72a9009a/msg_db5b60cf8fd1](../../sources/locomo/thread_7a2d72a9009a.md#source-09eb5fd0b8dae9a0)

The user is considering getting new fencing for the north field.[^e-b019f45c98] ^36436a61

[^e-b019f45c98]: Time: `2023-02`; Sources: [locomo/thread_7a2d72a9009a/msg_b2abf303cfe7](../../sources/locomo/thread_7a2d72a9009a.md#source-73f5889a2d354328)

The user plans to check the cowshed's ventilation system because the hens have been laying fewer eggs lately, which they suspect may be related to the changing weather.[^e-ec4946bbb6] ^8a8dc00a

[^e-ec4946bbb6]: Time: `2023-02`; Sources: [locomo/thread_7a2d72a9009a/msg_733c22d0826c](../../sources/locomo/thread_7a2d72a9009a.md#source-80f4b4db0c7b2c23)

The user is looking into regulations and guidelines for disposing of manure and waste from the farm.[^e-d0947d71df] ^ca38b03f

[^e-d0947d71df]: Time: `2023-02`; Sources: [locomo/thread_7a2d72a9009a/msg_db5b60cf8fd1](../../sources/locomo/thread_7a2d72a9009a.md#source-09eb5fd0b8dae9a0)

The user is planning to organize a farm open house event to invite the local community to see the farm's operations.[^e-806ff384a7] ^58bc28d2

[^e-806ff384a7]: Time: `2023-02`; Sources: [locomo/thread_7a2d72a9009a/msg_4bd0847b5056](../../sources/locomo/thread_7a2d72a9009a.md#source-5d4e66e508c196bc)

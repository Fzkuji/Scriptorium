# Economic History

The user asked about the causes and effects of the Dutch East India Company's collapse, including corruption, mismanagement, overexpansion, and competition from other European nations, and the resulting economic, political, and social decline for the Dutch state; they are also interested in how corporate corruption and mismanagement have brought down powerful companies, comparing the Dutch East India Company with the South Sea Company and Enron, and asked how companies can be kept ethical and accountable in the long term through corporate governance, anti-corruption laws, whistleblower protections, and international standards.[^e-598fa7e58c][^e-9545b073c1] ^f6d8d103 ^0556661a

[^e-598fa7e58c]: Time: `2023-02`; Sources: [locomo/thread_6058016e3a4c/msg_762f576eb113](../../sources/locomo/thread_6058016e3a4c.md#source-bfa33625fad44ed5)

[^e-9545b073c1]: Time: `2023-02`; Sources: [locomo/thread_6058016e3a4c/msg_972e74206ba7](../../sources/locomo/thread_6058016e3a4c.md#source-54d8abcfbeb69e44), [locomo/thread_6058016e3a4c/msg_b30cc70bd0b5](../../sources/locomo/thread_6058016e3a4c.md#source-406d4ec7c788f20d)

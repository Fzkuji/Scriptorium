# Seasonal Cooking

The user has been cooking more with seasonal ingredients and recently made a delicious batch of roasted root vegetables.[^e-3a5dcfcaaf] ^0c0fa74b

[^e-3a5dcfcaaf]: Time: `2023-02`; Sources: [locomo/thread_89990fbd2a44/msg_e94e6e841d8e](../../sources/locomo/thread_89990fbd2a44.md#source-72a40ff0043bd59d)

The user is interested in recipes using citrus fruits like oranges and lemons, which they note are in season from December to May.[^e-232b0a021c] ^1c5d894f

[^e-232b0a021c]: Time: `2023-02`; Sources: [locomo/thread_89990fbd2a44/msg_e94e6e841d8e](../../sources/locomo/thread_89990fbd2a44.md#source-72a40ff0043bd59d)

The user is particularly interested in trying the Citrus and Avocado Salad and the Lemon and Herb Roasted Chicken, and planned to try the Citrus and Avocado Salad for lunch at work during their walk break.[^e-23a398049c][^e-5eb95b2b3a] ^1a43f0d4 ^20d16700

[^e-23a398049c]: Time: `2023-02`; Sources: [locomo/thread_89990fbd2a44/msg_159ca96fc9cf](../../sources/locomo/thread_89990fbd2a44.md#source-dbb89dc4c282dd9b)

[^e-5eb95b2b3a]: Time: `2023-02`; Sources: [locomo/thread_89990fbd2a44/msg_25234a4c1f69](../../sources/locomo/thread_89990fbd2a44.md#source-0e66929eee9ce800)

The user's cooking shifts with the seasons: heartier dishes like stews and casseroles in winter, and lighter flavors with fresh herbs, leafy greens, and spring vegetables like asparagus and peas as spring approaches; they have been experimenting with spring-inspired desserts like lemon bars and rhubarb crisps.[^e-a90dedd82a][^e-22b5807408] ^15c8fa7e ^d4f438af

[^e-a90dedd82a]: Time: `2023-02`; Sources: [locomo/thread_89990fbd2a44/msg_c244041f6031](../../sources/locomo/thread_89990fbd2a44.md#source-ff89edb83210d740)

[^e-22b5807408]: Time: `2023-02`; Sources: [locomo/thread_89990fbd2a44/msg_c244041f6031](../../sources/locomo/thread_89990fbd2a44.md#source-ff89edb83210d740)

# Guitar

The user is getting back into playing guitar after the instrument sat in the corner of their room collecting dust for years while life got busy.[^e-36f36e3088] ^1f03570e

[^e-36f36e3088]: Time: `2023-02`; Sources: [locomo/thread_cbcd98836154/msg_4efa0dd0ad5d](../../sources/locomo/thread_cbcd98836154.md#source-d36bc6e70ac12196)

The user is looking for recommendations on acoustic-electric guitars and advice on what to look for when buying one.[^e-65cd1c5386] ^8a3e9206

[^e-65cd1c5386]: Time: `2023-02`; Sources: [locomo/thread_cbcd98836154/msg_4efa0dd0ad5d](../../sources/locomo/thread_cbcd98836154.md#source-d36bc6e70ac12196)

The user decided to take group guitar lessons at a local music shop that offers them for adults and signed up for a 6-week course starting in late February 2023, planning to practice with a metronome to improve their timing and rhythm before it began.[^e-7f26b52e15][^e-424622fcfd] ^fd9b13c0 ^d6f71318

[^e-7f26b52e15]: Time: `2023-02`; Sources: [locomo/thread_cbcd98836154/msg_8efa0e8abaf5](../../sources/locomo/thread_cbcd98836154.md#source-ecffe79b3060cdbc), [locomo/thread_cbcd98836154/msg_7c06b61cdcef](../../sources/locomo/thread_cbcd98836154.md#source-706d1189b6a8a254)

[^e-424622fcfd]: Time: `2023-02`; Sources: [locomo/thread_cbcd98836154/msg_7c06b61cdcef](../../sources/locomo/thread_cbcd98836154.md#source-706d1189b6a8a254)

The user is excited to dive into fingerstyle guitar techniques and planned to start with simple patterns and exercises, following recommendations to practice consistently and to use YouTube channels, websites, and books to learn fingerstyle guitar.[^e-99a6d6a331] ^c5c7fa89

[^e-99a6d6a331]: Time: `2023-02`; Sources: [locomo/thread_cbcd98836154/msg_ff7fe86bebe6](../../sources/locomo/thread_cbcd98836154.md#source-cccac808cfb93f55), [locomo/thread_cbcd98836154/msg_77411b635093](../../sources/locomo/thread_cbcd98836154.md#source-ccd4d9ee8a7dd4c6), [locomo/thread_cbcd98836154/msg_6aa0279dcf94](../../sources/locomo/thread_cbcd98836154.md#source-8761e1d7fb10ed5e)

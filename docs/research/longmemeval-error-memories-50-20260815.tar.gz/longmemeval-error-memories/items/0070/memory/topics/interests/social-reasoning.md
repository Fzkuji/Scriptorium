# Social Reasoning

The user worked through a belief-reasoning scenario about Alice, Bob, and Charlie, incrementally adding updates — Bob having an affair, visiting his mistress' apartment before going to Safeway, and all the eggs being chicken eggs — and asking what each person believed about where Bob went and what he bought.[^e-95438b30fd] ^f1e2dada

[^e-95438b30fd]: Time: `2023-02`; Sources: [locomo/thread_774d07d5ad9c/msg_ac35608ad987](../../sources/locomo/thread_774d07d5ad9c.md#source-ea451f52847287de), [locomo/thread_774d07d5ad9c/msg_08c63977e8e1](../../sources/locomo/thread_774d07d5ad9c.md#source-264373bbfefa777e), [locomo/thread_774d07d5ad9c/msg_944c6a38b2b8](../../sources/locomo/thread_774d07d5ad9c.md#source-38a1f003cc5db977), [locomo/thread_774d07d5ad9c/msg_106297cc6efc](../../sources/locomo/thread_774d07d5ad9c.md#source-b39d9572aa62d17f), [locomo/thread_774d07d5ad9c/msg_51a5be8b8d8c](../../sources/locomo/thread_774d07d5ad9c.md#source-5b5a4935764b3ff1)

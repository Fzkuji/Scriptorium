# Reading

The user is looking for books similar to "The Nightingale" by Kristin Hannah and decided to try "All the Light We Cannot See" by Anthony Doerr next.[^e-612c1cbbeb] ^726c7669

[^e-612c1cbbeb]: Time: `2023-02`; Sources: [locomo/thread_cb51e23a7220/msg_ca1a1221cb88](../../sources/locomo/thread_cb51e23a7220.md#source-be0d5789cc715f43), [locomo/thread_cb51e23a7220/msg_159b43a374ae](../../sources/locomo/thread_cb51e23a7220.md#source-4d366ca8d318d0cc)

The user reads before bed for about 20–30 minutes each night to wind down, and recently read their vintage [Spider-Man comic book](collecting.md#^d223bfaf) every night before bed, which brought back childhood memories.[^e-60a9735cdc] ^0b1f27bc

[^e-60a9735cdc]: Time: `2023-02`; Sources: [locomo/thread_cb51e23a7220/msg_6303874eeb15](../../sources/locomo/thread_cb51e23a7220.md#source-31035d170ccbcdf0), [locomo/thread_fbdbd86005d1/msg_4171fd7e8389](../../sources/locomo/thread_fbdbd86005d1.md#source-0a1411819a641c5c)

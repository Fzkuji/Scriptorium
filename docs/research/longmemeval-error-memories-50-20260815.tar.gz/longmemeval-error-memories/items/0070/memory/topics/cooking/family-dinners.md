# Family Dinners

The user, a [parent](../people/user.md#^13ca8b17), has been making an effort to have dinner with their family at least three times a week, and it has been nice to cook together and catch up; they are planning a healthy dinner for the week and chose Quinoa and Black Bean Chili, served with Roasted Sweet Potato Wedges and a Mixed Greens salad with cherry tomatoes and cilantro, followed by a Fresh Fruit Salad for dessert.[^e-246bb59c3e][^e-e3e019a3a4] ^947186b1 ^4c05bf1c

[^e-246bb59c3e]: Time: `2023-02`; Sources: [locomo/thread_4c22fc1ada7e/msg_f204f7793441](../../sources/locomo/thread_4c22fc1ada7e.md#source-8cb8a421e0b22842)

[^e-e3e019a3a4]: Time: `2023-02`; Sources: [locomo/thread_4c22fc1ada7e/msg_05e8ee0a2b46](../../sources/locomo/thread_4c22fc1ada7e.md#source-0b45a5bc5531b50b), [locomo/thread_4c22fc1ada7e/msg_3e783a257c9d](../../sources/locomo/thread_4c22fc1ada7e.md#source-fbad34d9cd97c871)

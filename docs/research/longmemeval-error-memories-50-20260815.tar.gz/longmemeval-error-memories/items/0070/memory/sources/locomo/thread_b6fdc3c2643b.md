# thread_b6fdc3c2643b

<a id="source-1c124a978a422942"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_f0d74ae50aaa -->
[2023-02-15] user: Is this for Autocad LT13? Because I cannot see the application menu in the options dialog box. i'm also not sure what you mean about step 3.

<a id="source-c4e2f8308737eac6"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_b9f4e21096c7 -->
[2023-02-15] assistant: I apologize for the confusion. The steps I provided were for a newer version of AutoCAD, and the user interface has changed over the years.

For AutoCAD LT 2013, you can try the following steps to customize the mouse buttons and assign the zoom window function to the right-click button:

1. Open the Customize User Interface (CUI) dialog box: Type "CUI" in the command line and hit Enter.
2. Expand the Mouse Buttons section: In the CUI dialog box, expand the Mouse Buttons section.
3. Locate the "ZOOM" category: Under the Mouse Buttons section, locate the "ZOOM" category.
4. Assign the "Zoom Window" function to the right-click button: Drag the "Zoom Window" function from the "ZOOM" category and drop it onto the Right Button item.
5. Save the changes: Click on the Save button in the CUI dialog box to save the changes.

Once these steps are completed, the right-click button should perform the zoom window function in AutoCAD LT 2013. If the right-click button still does not work as expected, you can try resetting AutoCAD LT to its default settings or checking for updates to the software.

<a id="source-ea454525e1b4f702"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_7679159943d0 -->
[2023-02-15] user: in the mouse buttons section there is no right mouse button. There is only click shift plus click, control plus click control plus shift click

<a id="source-1e351e33f451c229"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_d93aadd0ee10 -->
[2023-02-15] assistant: I see. In that case, you can try the following steps to customize the right-click button in AutoCAD LT 2013:

1. Go to the Options dialog box: Go to the Application menu and click on Options, or type "OPTIONS" in the command line and hit Enter.
2. Go to the User Preferences tab: Select the User Preferences tab in the Options dialog box.
3. Customize the right-click button: In the Mouse section, click on the "Customize Button" button.
4. Assign the zoom window function: In the Customize Button dialog box, select "Button 2" (which should correspond to the right-click button on your mouse). Then, in the "Macro" field, type the command "\_.ZOOM" (without quotes).
5. Save the changes: Click on the Apply and OK buttons to save the changes.

Once these steps are completed, the right-click button should perform the zoom window function in AutoCAD LT 2013. If the right-click button still does not work as expected, you can try resetting AutoCAD LT to its default settings or checking for updates to the software.

<a id="source-7b1e75cde58993c0"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_79b1830ae93f -->
[2023-02-15] user: remember Autocad LT13, I can't see a mouse section here. Just a button called right click customization

<a id="source-1cd60bba8b0e24ef"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_4c7b63adf7ef -->
[2023-02-15] assistant: I apologize for the confusion. In AutoCAD LT 2013, the right-click button customization is available under the "Right-click Customization" option, as you mentioned.

To assign the zoom window function to the right-click button, please follow these steps:

1. Go to the Options dialog box: Go to the Application menu and click on Options, or type "OPTIONS" in the command line and hit Enter.
2. Go to the User Preferences tab: Select the User Preferences tab in the Options dialog box.
3. Customize the right-click button: In the "Right-click Customization" section, click on the "Customize" button.
4. Assign the zoom window function: In the Customize User Interface dialog box that appears, expand the "Shortcuts" section and then the "All Commands" section. Scroll down the list of commands until you find "Zoom" and expand it. Then select "Zoom Window" and drag it to the "Customizations in Main CUI" section. Drop it onto the "RButton" (which corresponds to the right-click button on your mouse).
5. Save the changes: Click on the Save button in the Customize User Interface dialog box to save the changes.

Once these steps are completed, the right-click button should perform the zoom window function in AutoCAD LT 2013. If the right-click button still does not work as expected, you can try resetting AutoCAD LT to its default settings or checking for updates to the software.

<a id="source-a93d559dd0b53b50"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_b219c71099df -->
[2023-02-15] user: autocad LT13 remember. The customer's user interface does not appear here Please help me

<a id="source-a339acf14e66c4e5"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_fb9801ef5199 -->
[2023-02-15] assistant: I apologize for the confusion. Here are the steps you can take to customize the right-click button in AutoCAD LT 2013:

1. Go to the Options dialog box: Go to the Application menu and click on Options, or type "OPTIONS" in the command line and hit Enter.
2. Go to the User Preferences tab: Select the User Preferences tab in the Options dialog box.
3. Customize the right-click button: In the "Right-click Customization" section, click on the "Customize" button.
4. Create a new command: In the Customize User Interface dialog box that appears, click on the "New Command" button.
5. Name the command: In the "Command Name" field, type a name for the command (e.g., "Zoom Window").
6. Assign the command: In the "Macro" field, type the command "\_ZOOMW". This is the command for the Zoom Window function.
7. Assign the command to the right-click button: In the "Customizations In Main CUI" pane, expand the "RButton Menus" section and select "Default". Then, drag the "Zoom Window" command that you just created to the "Default" section.
8. Save the changes: Click on the Save button in the Customize User Interface dialog box to save the changes.

Once these steps are completed, the right-click button should perform the zoom window function in AutoCAD LT 2013. If the right-click button still does not work as expected, you can try resetting AutoCAD LT to its default settings or checking for updates to the software.

<a id="source-3a03cff87f73f1c6"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_e77022dc0d54 -->
[2023-02-15] user: there is no new command button here in this version!

<a id="source-e970f583b2f37866"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_97a142d92e39 -->
[2023-02-15] assistant: I apologize for the confusion. Here are the steps to assign the zoom window function to the right-click button in AutoCAD LT 2013:

1. Go to the Options dialog box: Go to the Application menu and click on Options, or type "OPTIONS" in the command line and hit Enter.
2. Go to the User Preferences tab: Select the User Preferences tab in the Options dialog box.
3. Customize the right-click button: In the "Right-click Customization" section, click on the "Customize" button.
4. Assign the zoom window function: In the Customize User Interface dialog box that appears, select "RButton Menu" in the "Customizations In Main CUI" section.
5. Add the "Zoom Window" function: In the "RButton Menu" section, click on the "Add Command" button. In the "Add Command" dialog box that appears, select "All Commands" from the "Categories" list and find the "Zoom Window" command. Then, select "Zoom Window" from the list of available commands and click "OK".
6. Save the changes: Click on the Save button in the Customize User Interface dialog box to save the changes.

Once these steps are completed, the right-click button should perform the zoom window function in AutoCAD LT 2013. If the right-click button still does not work as expected, you can try resetting AutoCAD LT to its default settings or checking for updates to the software.

<a id="source-92acb03cae2f997a"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_051c3dbc49ff -->
[2023-02-15] user: In autocad lt 2013, is it possible to customize the shortcut menu that opens on a right click I want to default it to zoom window

<a id="source-19583c1d87da52ff"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_34fc35f752e8 -->
[2023-02-15] assistant: Yes, it is possible to customize the shortcut menu that opens on a right-click in AutoCAD LT 2013 and set the default option to "Zoom Window." Here's how you can do it:

1. Go to the Options dialog box: Go to the Application menu and click on Options, or type "OPTIONS" in the command line and hit Enter.
2. Go to the User Preferences tab: Select the User Preferences tab in the Options dialog box.
3. Customize the right-click button: In the "Right-click Customization" section, click on the "Customize" button.
4. Customize the shortcut menu: In the Customize User Interface dialog box that appears, select "RButton Menu" in the "Customizations In Main CUI" section.
5. Set "Zoom Window" as the default option: Find the "Zoom Window" command in the "All Commands" list, and drag and drop it to the top of the "RButton Menu" section.
6. Save the changes: Click on the Save button in the Customize User Interface dialog box to save the changes.

Once these steps are completed, the "Zoom Window" option should be the default option in the shortcut menu that appears on a right-click in AutoCAD LT 2013.

<a id="source-702037947ca1b7e9"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_704761d1e176 -->
[2023-02-15] user: the rbutton option is missing in the main CUI window

<a id="source-ef793567e7275124"></a>
<!-- source-id:locomo/thread_b6fdc3c2643b/msg_0cd7e73387e3 -->
[2023-02-15] assistant: I apologize for the confusion. In AutoCAD LT 2013, the "RButton" option is not available in the "Customizations In Main CUI" section, and instead you need to customize the shortcut menu directly.

Here are the steps to customize the shortcut menu and set "Zoom Window" as the default option when right-clicking in AutoCAD LT 2013:

1. Go to the Options dialog box: Go to the Application menu and click on Options, or type "OPTIONS" in the command line and hit Enter.
2. Go to the User Preferences tab: Select the User Preferences tab in the Options dialog box.
3. Customize the right-click button: In the "Right-click Customization" section, click on the "Customize" button.
4. Customize the shortcut menu: In the Customize User Interface dialog box that appears, select "Shortcuts" in the "Customizations In Main CUI" section.
5. Set "Zoom Window" as the default option: Scroll down and find the "Zoom Window" command in the "All Commands" list, right-click on it, and select "Add to Shortcut Menu".
6. Save the changes: Click on the Save button in the Customize User Interface dialog box to save the changes.

Once these steps are completed, the "Zoom Window" option should be added to the shortcut menu when you right-click in AutoCAD LT 2013, and it will be the default option.

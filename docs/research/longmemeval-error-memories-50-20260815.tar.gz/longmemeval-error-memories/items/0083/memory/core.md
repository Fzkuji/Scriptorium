# Core Memory

## User profile

The user is a runner who completed a first 5K, plans another race, and is interested in theme park events and the Disney Princess Half Marathon.[^e-cfcadb4263]

The user enjoys board games (Ticket to Ride, Carcassonne, Settlers of Catan, Forbidden Island) and is getting into tabletop RPGs (D&D Starter Set; beginner session planned).[^e-9c604e7981]

The user is a solicitor and construction lawyer with 10+ years' experience advising homeowners and builders in NSW, Australia.[^e-82b81aa043]

The user takes yoga classes three times a week, exploring inversions and arm balances.[^e-b0c9619a3c]

The user is a senior software engineer (recently promoted; ceremony May 29) leading a junior engineering team, preparing for the IEEE CSDP exam, and considering a personal brand.[^e-ddb8238391][^e-84f8e8f5ed]

The user is a frequent traveler based near DC (fifth NYC trip since January), holds United Premier Silver status, and is planning a Boston weekend getaway.[^e-3ba7c7f657]

The user has a toddler and a growing family, recently bought a new house (kid-friendly living room: LVT/LVP flooring, coastal theme), and has a new apartment where they take salsa classes and need local services (dry cleaner, workout clothes, dance shoes).[^e-61be76ed22]

## Active ongoing work

The user is producing SEO content for NSW homeowners and builders: repudiating a building contract (SILO support pages, persona outlines) and mediation vs arbitration (outline, keywords, Australian English sections).[^e-a7481118db][^e-c127d43fb9]

The user is building a community-based app and developing engagement features for quality users.[^e-a30ca3bce6]

The user is planning a food bank food drive, possibly an annual Easter tradition at their church.[^e-757910b7cc]

The user is planning a birthday party for their niece at a children's museum.[^e-20915d1a90]

[^e-cfcadb4263]: Time: `2023-05-20`; Sources: [locomo/thread_89990fbd2a44/msg_e94e6e841d8e](sources/locomo/thread_89990fbd2a44.md#source-72a40ff0043bd59d), [locomo/thread_89990fbd2a44/msg_8f7f0003d1e3](sources/locomo/thread_89990fbd2a44.md#source-fb1edc4c9f22e8e2), [locomo/thread_89990fbd2a44/msg_40f5ab477866](sources/locomo/thread_89990fbd2a44.md#source-d9c003c83db4ef69)
[^e-9c604e7981]: Time: `2023-05-20`; Sources: [locomo/thread_5c188c1c98ea/msg_f1a20a57751d](sources/locomo/thread_5c188c1c98ea.md#source-5b89f5c0f4cf64e8), [locomo/thread_5c188c1c98ea/msg_6d73cf4ac70b](sources/locomo/thread_5c188c1c98ea.md#source-118b979ce50ef488)
[^e-a7481118db]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_34fa12ce3947](sources/locomo/thread_37d993f7a9d6.md#source-eae59293bb940b5e), [locomo/thread_37d993f7a9d6/msg_2a68a35126ba](sources/locomo/thread_37d993f7a9d6.md#source-bc27ba3385c0f728)
[^e-82b81aa043]: Time: `2023-05-21`; Sources: [locomo/thread_749fa3152137/msg_a0fdefbb25d7](sources/locomo/thread_749fa3152137.md#source-9305f94c7e7b42b2)
[^e-c127d43fb9]: Time: `2023-05-21`; Sources: [locomo/thread_749fa3152137/msg_a642c1a18f3f](sources/locomo/thread_749fa3152137.md#source-4163a2571ab0f5e7), [locomo/thread_749fa3152137/msg_6122171936cb](sources/locomo/thread_749fa3152137.md#source-0d783ebded5190c7), [locomo/thread_749fa3152137/msg_0913bf8fc1b5](sources/locomo/thread_749fa3152137.md#source-c0d518f692b45fef)
[^e-a30ca3bce6]: Time: `2023-05-21`; Sources: [locomo/thread_bb376441501c/msg_ff4264064f14](sources/locomo/thread_bb376441501c.md#source-7e33fd17b92c937a), [locomo/thread_bb376441501c/msg_114b947f2803](sources/locomo/thread_bb376441501c.md#source-7c3e92b5894d1328)
[^e-b0c9619a3c]: Time: `2023-05-23`; Sources: [locomo/thread_100ba0195b99/msg_ebd760f46e80](sources/locomo/thread_100ba0195b99.md#source-b010eae73e629d10)
[^e-757910b7cc]: Time: `2023-05-22`; Sources: [locomo/thread_7c96790ff4be/msg_315d5febadfe](sources/locomo/thread_7c96790ff4be.md#source-0612c1f9a88c6133), [locomo/thread_7c96790ff4be/msg_5b0e76041f3f](sources/locomo/thread_7c96790ff4be.md#source-40c60a2411a45fac)
[^e-20915d1a90]: Time: `2023-05-24`; Sources: [locomo/thread_01ea86c3d49e/msg_099b87789e90](sources/locomo/thread_01ea86c3d49e.md#source-9753659f08da0f61)
[^e-ddb8238391]: Time: `2023-05-29`; Sources: [locomo/thread_8e09fa96d2c5/msg_3323362a8a5e](sources/locomo/thread_8e09fa96d2c5.md#source-edbc4ca6bb5825f4), [locomo/thread_8e09fa96d2c5/msg_4d38dab909a4](sources/locomo/thread_8e09fa96d2c5.md#source-ba535e061d734b7b)
[^e-3ba7c7f657]: Time: `2023-05-29`; Sources: [locomo/thread_d7ef2bcadc43/msg_c207762bb83b](sources/locomo/thread_d7ef2bcadc43.md#source-ca0ae7e6388f4710), [locomo/thread_d7ef2bcadc43/msg_0882565edb96](sources/locomo/thread_d7ef2bcadc43.md#source-472d2a85c3331097)
[^e-84f8e8f5ed]: Time: `2023-05-29`; Sources: [locomo/thread_8e09fa96d2c5/msg_36357bc96c67](sources/locomo/thread_8e09fa96d2c5.md#source-d0271dac8a46d0c4)

[^e-61be76ed22]: Time: `2023-05-30`; Sources: [locomo/thread_8012f247a034/msg_1a78f58e1289](sources/locomo/thread_8012f247a034.md#source-cef03c796e1758ff), [locomo/thread_0c1e1040f326/msg_3fea6be02369](sources/locomo/thread_0c1e1040f326.md#source-b1aeed3355d53570), [locomo/thread_0c1e1040f326/msg_aa0b89faa10b](sources/locomo/thread_0c1e1040f326.md#source-bc0648aedb56395c)

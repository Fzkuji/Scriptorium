# thread_d7ef2bcadc43

<a id="source-d7e974963db3cfe9"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_6e7dcb803047 -->
[2023-05-29] user: I've been meaning to start tracking my travel rewards more closely. Can you help me figure out how to optimize my frequent flyer miles and credit card points?

<a id="source-e152c1dd1f602451"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_195681a47156 -->
[2023-05-29] assistant: Optimizing your frequent flyer miles and credit card points can be a game-changer for travel enthusiasts. I'd be happy to help you get started.

To optimize your rewards, let's break it down into a few steps:

1. **Take stock of your current situation**:
	* Make a list of your:
		+ Frequent flyer programs (FFPs) and their corresponding balances
		+ Credit cards with rewards programs and their balances
		+ Travel credit cards with annual fees and rewards earning structures
2. **Set travel goals**:
	* Identify your short-term and long-term travel goals (e.g., a specific trip, a type of travel, or a certain number of free flights)
	* Consider your travel style (e.g., solo, with family, business, or leisure)
3. **Understand your earning and burning opportunities**:
	* Research the earning rates and rewards structures for each of your credit cards and FFPs
	* Familiarize yourself with the transfer partners and redemption options for each program
	* Learn about any opportunities for bonus earning (e.g., category bonuses, sign-up bonuses, or limited-time offers)
4. **Prioritize your rewards**:
	* Focus on the programs that align best with your travel goals and earning opportunities
	* Consider the transferability of points between programs (e.g., Chase Ultimate Rewards, American Express Membership Rewards, or Citi ThankYou Rewards)
5. **Optimize your earning**:
	* Use the right credit cards for your daily purchases, considering categories like:
		+ Groceries
		+ Dining
		+ Travel
		+ Gas
		+ Everyday spending
	* Take advantage of sign-up bonuses, referral offers, and limited-time promotions
	* Consider supplementing your earnings with online shopping portals, dining rewards programs, or other loyalty schemes
6. **Maximize your redemptions**:
	* Learn the sweet spots for redeeming your points and miles (e.g., booking awards in advance, using transfer partners, or exploiting loopholes)
	* Understand the redemption rates and fees associated with each program
	* Plan ahead to ensure you have the necessary points or miles for your desired redemptions
7. **Monitor and adjust**:
	* Regularly track your balances, earning rates, and redemption opportunities
	* Adjust your strategy as needed to ensure you're optimizing your rewards

To help you get started, here are some popular tools and resources:

* AwardWallet: A travel rewards tracking platform that helps you monitor your balances and alerts you to expiration dates.
* Expert Flyer: A tool for searching award availability and tracking flight schedules.
* The Points Guy: A website offering expert advice, news, and resources for maximizing travel rewards.
* Reddit's r/churning and r/travelrewards: Active communities sharing knowledge and experiences in the world of travel rewards.

Feel free to share more about your current situation, travel goals, and rewards programs, and I'll be happy to provide more tailored guidance!

<a id="source-aaa80229ca9fe769"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_1ca767639772 -->
[2023-05-29] user: Can you recommend any apps or tools to help me track my travel expenses, like my spreadsheet?

<a id="source-54da2ccfe0aa2c53"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_ec899e8d02b5 -->
[2023-05-29] assistant: Spreadsheets are great, but there are many apps and tools that can make tracking your travel expenses more efficient and enjoyable. Here are some popular options:

1. **Travel expense tracking apps:**
	* **Trail Wallet** (iOS, Android): A simple, user-friendly app for tracking daily expenses, with features like automatic currency conversion and budgeting.
	* **TripCoin** (iOS, Android): A travel expense tracker that also helps you earn rewards and cashback on your purchases.
	* **Expensify** (iOS, Android): A comprehensive expense tracking app with features like receipt scanning, categorization, and reimbursement management.
	* **Mint** (iOS, Android): A personal finance app that also tracks travel expenses, with features like budgeting, categorization, and alerts.
2. **Digital wallets and credit card apps:**
	* **Chase Mobile** (iOS, Android): Chase credit card holders can track their expenses, earn rewards, and redeem points through the app.
	* **American Express** (iOS, Android): Amex cardholders can track expenses, earn rewards, and access exclusive benefits through the app.
	* **Capital One Travel** (iOS, Android): Capital One credit card holders can track expenses, earn rewards, and book travel through the app.
3. **Itinerary and travel planning tools:**
	* **TripIt** (iOS, Android): A travel planning app that helps you organize your trips, track expenses, and receive real-time travel alerts.
	* **Google Trips** (iOS, Android): A free travel planning app that helps you organize your trips, track expenses, and access travel recommendations.
4. **Spreadsheet alternatives:**
	* **Google Sheets** (Web): A cloud-based spreadsheet solution that allows real-time collaboration and automatic saving.
	* **Microsoft Excel Online** (Web): A cloud-based spreadsheet solution with features like real-time collaboration and automatic saving.

These apps and tools can help you track your travel expenses more efficiently, and many of them offer additional features like budgeting, receipt scanning, and rewards tracking.

If you're already comfortable with spreadsheets, you might consider using Google Sheets or Microsoft Excel Online, which offer more flexibility and customization options.

However, if you're looking for a more streamlined and user-friendly experience, one of the travel expense tracking apps or digital wallets might be a better fit.

Feel free to explore these options and find the one that best suits your needs!

<a id="source-ca0ae7e6388f4710"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_c207762bb83b -->
[2023-05-29] user: I've been trying to get Premier Silver status on United Airlines. I just hit 20,000 miles, so I'm curious to know more about the benefits I'll get with this status. Can you walk me through what I can expect?

<a id="source-0287ca90f53f8eef"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_16ded3ef1607 -->
[2023-05-29] assistant: Congratulations on reaching 20,000 miles and earning Premier Silver status on United Airlines! As a Premier Silver member, you'll enjoy a range of benefits that will enhance your travel experience. Here's a breakdown of what you can expect:

**Priority Check-in, Baggage Handling, and Boarding:**

* Priority check-in at designated Silver check-in counters
* Priority baggage handling, which means your bags will be among the first to be loaded onto the plane and unloaded at your destination
* Group 2 boarding, which allows you to board the plane earlier and secure a better seat

**Seat Selection and Upgrades:**

* Complimentary access to Economy Plus seats at check-in (subject to availability)
* 50% discount on Economy Plus seats at booking
* Ability to upgrade to First Class or Business Class using miles or upgrade certificates (subject to availability)

**Lounge Access:**

* Two one-time passes to United Club lounges, which can be used on domestic or international flights
* Access to Star Alliance lounges when flying internationally on a Star Alliance carrier

**Baggage Allowance:**

* Two free checked bags (up to 70 lbs each) on United and United Express flights
* Three free checked bags (up to 70 lbs each) on international flights

**Waived Fees:**

* Waived same-day flight change fees
* Waived award ticket redeposit fees

**Other Perks:**

* 25% bonus on award miles earned on United and United Express flights
* Priority customer service phone line
* Star Alliance Silver status, which provides benefits on other Star Alliance carriers

**Star Alliance Benefits:**

* Priority check-in, baggage handling, and boarding on Star Alliance carriers
* Access to Star Alliance lounges when flying internationally on a Star Alliance carrier
* Priority baggage delivery on Star Alliance carriers

**Complimentary Upgrades:**

* As a Premier Silver member, you'll be eligible for complimentary upgrades to First Class or Business Class on domestic flights, subject to availability. Upgrades are processed based on availability and prioritized by status level, with Premier Silver members being upgraded after Premier Gold and Premier Platinum members.

Keep in mind that some benefits may vary depending on the specific flight or route. It's always a good idea to review the United Airlines website or consult with a United representative for the most up-to-date information.

Enjoy your Premier Silver status and the perks that come with it!

<a id="source-472d2a85c3331097"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_0882565edb96 -->
[2023-05-29] user: I just got back from my fifth trip to New York City since January, and I'm thinking of planning another trip soon. Do you think I could use my Premier Silver status to get upgraded on a domestic flight from DC to NYC?

<a id="source-938225b1c31bcc66"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_771c093402ec -->
[2023-05-29] assistant: A frequent NYC visitor, eh? As a Premier Silver member, you do have a chance to get upgraded on a domestic flight from DC to NYC, but it's not a guarantee.

Here's how United's upgrade process works:

1. **Upgrade priority:** As a Premier Silver member, you'll be prioritized for upgrades after Premier Gold and Premier Platinum members, but before General Members.
2. **Availability:** Upgrades are subject to availability, which means there need to be open seats in the higher cabin (First Class or Business Class).
3. **Flight-specific factors:** United's upgrade algorithm considers various factors, including:
	* Flight duration: Shorter flights like DC to NYC (about 1 hour) are less likely to have open upgrade seats.
	* Flight demand: If the flight is heavily booked, there might be fewer upgrade opportunities.
	* Aircraft configuration: Some planes have fewer premium seats, making upgrades less likely.
4. **Upgrade windows:** United typically opens upgrade windows at specific times before the flight:
	* 24 hours before departure: Premier Silver members can request upgrades.
	* 12 hours before departure: United may start clearing some upgrade requests.
	* At the gate: Last-minute upgrade opportunities might arise due to no-shows or last-minute seat availability.

Given that you're flying from DC to NYC, which is a relatively short and frequent route, the upgrade competition might be higher. However, as a Premier Silver member, you still have a chance to get upgraded, especially if you're flexible with your travel dates and times.

To increase your chances of getting upgraded:

* **Be flexible:** Consider flying on off-peak days (e.g., Tuesdays, Wednesdays, and Saturdays) or during off-peak times (e.g., early morning or late evening).
* **Monitor flight loads:** Use tools like ExpertFlyer or United's website to check flight loads and availability. If the flight is relatively empty, your chances of getting upgraded might be higher.
* **Request an upgrade:** Log in to your United account and request an upgrade 24 hours before your flight. You can also ask the gate agent about upgrade availability when you check in.

Remember, upgrades are not guaranteed, and you should be prepared to fly in your original cabin. However, as a Premier Silver member, you've got a better shot at getting upgraded than General Members.

Good luck, and I hope you get upgraded on your next trip to NYC!

<a id="source-eb4032581fcce6b3"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_bc162f52cd6a -->
[2023-05-29] user: I'm actually thinking of planning a weekend getaway to Boston soon. Do you think I could use my Premier Silver status to get upgraded on a domestic flight from DC to Boston?

<a id="source-c78ff8eefbcdfb65"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_d486d29f7aab -->
[2023-05-29] assistant: A weekend getaway to Boston sounds like a great idea! As a Premier Silver member, you do have a chance to get upgraded on a domestic flight from DC to Boston, and I'd say your chances are slightly better than on a DC to NYC flight.

Here's why:

1. **Less competition:** Boston is a smaller market compared to NYC, which means there might be fewer passengers competing for upgrades.
2. **Fewer flights:** There are fewer flights from DC to Boston compared to DC to NYC, which could lead to a higher upgrade success rate.
3. **Shorter flight duration:** The flight from DC to Boston is about 1.5 hours, which is still a relatively short flight. However, it's slightly longer than the DC to NYC flight, which might make upgrades more likely.

That being said, it's still important to remember that upgrades are subject to availability, and United's upgrade algorithm will consider various factors, such as:

* Flight demand
* Aircraft configuration
* Premier member priority

To increase your chances of getting upgraded:

* **Be flexible:** Consider flying on off-peak days (e.g., Saturdays or Sundays) or during off-peak times (e.g., early morning or late evening).
* **Monitor flight loads:** Use tools like ExpertFlyer or United's website to check flight loads and availability. If the flight is relatively empty, your chances of getting upgraded might be higher.
* **Request an upgrade:** Log in to your United account and request an upgrade 24 hours before your flight. You can also ask the gate agent about upgrade availability when you check in.

As a Premier Silver member, you'll be prioritized for upgrades after Premier Gold and Premier Platinum members, but before General Members. Keep in mind that upgrades are not guaranteed, and you should be prepared to fly in your original cabin.

If you're flexible with your travel dates and times, and you're willing to take a chance, you might be able to snag an upgrade to First Class or Business Class on your flight from DC to Boston. Good luck, and I hope you enjoy your weekend getaway to Boston!

<a id="source-c2599d80d8360fb6"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_d0d164269b27 -->
[2023-05-29] user: I think I'll try to book a morning flight on a Saturday, since it's usually less busy. Do you think I should also consider booking a different airline, like American or Delta, to see if they have better upgrade options?

<a id="source-dfe877cef0e8b722"></a>
<!-- source-id:locomo/thread_d7ef2bcadc43/msg_505eaf071043 -->
[2023-05-29] assistant: Booking a morning flight on a Saturday is a great strategy to increase your chances of getting upgraded! Fewer passengers tend to travel on weekends, especially early in the morning, which might lead to more available upgrade seats.

Regarding your question about considering other airlines, it's definitely worth exploring. As a Premier Silver member on United, you might not have the same level of status on American or Delta. However, you can still try to leverage your Premier Silver status to get upgraded on those airlines.

Here's a brief rundown of the upgrade policies for American and Delta:

* **American Airlines:** As a United Premier Silver member, you don't have equivalent status on American. However, you can still try to upgrade using your United miles or by purchasing an upgrade at check-in (subject to availability). American's upgrade policy is more restrictive than United's, but it's still worth a shot.
* **Delta Air Lines:** Delta has a more generous upgrade policy than American, but it's still different from United's. As a United Premier Silver member, you don't have equivalent status on Delta. However, you can try to upgrade using your United miles or by purchasing an upgrade at check-in (subject to availability). Delta's upgrade policy prioritizes its own elite members, but you might still have a chance to get upgraded.

Before booking on another airline, consider the following:

* **Familiarity:** If you're used to flying United, you might prefer to stick with what you know. Familiarity can be comforting, especially when it comes to airport layouts, check-in processes, and in-flight amenities.
* **Loyalty program:** If you're invested in United's loyalty program, you might want to focus on earning more miles and redeeming upgrades within their system.
* **Route network:** If you frequently fly to destinations served by United, it might be more convenient to stick with them.

That being said, if you're willing to explore other options, you can try searching for flights on American or Delta to see if they have better upgrade opportunities. Keep in mind that you'll need to factor in the cost of upgrading, as well as any potential differences in in-flight amenities and services.

Remember to weigh the pros and cons before making a decision. If you do decide to book on another airline, make sure to research their upgrade policies and procedures to increase your chances of getting upgraded. Good luck!

# thread_551cc7f69a7b

<a id="source-8856a15964658c57"></a>
<!-- source-id:locomo/thread_551cc7f69a7b/msg_d43837dfd41b -->
[2023-05-30] assistant: Certainly! Here's how you can establish guidelines for determining complexity:

1. Develop a checklist: Create a checklist of the characteristics you've identified as indicative of a complex property. This checklist should be clear, concise, and easy to follow, and it should include objective criteria that can be consistently applied.
2. Assign a score: For each characteristic on the checklist, assign a score that reflects the level of complexity the characteristic contributes to the property. For example, you could assign a score of 1 for characteristics that are relatively simple or straightforward, and a score of 5 for characteristics that are highly complex or challenging.
3. Determine a threshold score: Based on the scores you've assigned, determine a threshold score that indicates when an appraisal order qualifies as complex. This threshold score could be set based on the average score for past appraisal orders, industry standards, or other relevant factors.
4. Provide clear instructions: Make sure the guidelines are clear and easy to follow, and provide detailed instructions on how to use the checklist and scoring system to determine whether an appraisal order is complex.
5. Review and adjust: Regularly review and adjust the guidelines as necessary to ensure that they remain relevant and effective. This could involve updating the checklist, changing the threshold score, or making other modifications as needed.

By following these steps, you should be able to establish clear and objective guidelines for determining complexity that your team can use consistently. These guidelines will help ensure that your team is able to accurately determine when an appraisal order is complex and request a higher fee when appropriate.

<a id="source-31f309fc63c31363"></a>
<!-- source-id:locomo/thread_551cc7f69a7b/msg_f8859e8d75b5 -->
[2023-05-30] user: To establish guidelines for determining complexity, help me "Develop a checklist: Create a checklist of the characteristics you've identified as indicative of a complex property. This checklist should be clear, concise, and easy to follow, and it should include objective criteria that can be consistently applied"

<a id="source-9439fe0e2fd6bf2e"></a>
<!-- source-id:locomo/thread_551cc7f69a7b/msg_aef5f2dcbddd -->
[2023-05-30] assistant: Sure! Here's an example of how you could develop a checklist of the characteristics of a complex property:

1. Location:
	* Is the property located in a remote area or an area with limited access?
	* Does the property have unique environmental or geographical features?
2. Size:
	* Is the total living area of the property significantly larger or smaller than the average for the area?
	* Does the property have multiple structures, separate living spaces, or unusual floor plans?
3. Age:
	* Was the property built before 1940 or after 2020?
	* Does the property have unique historical or architectural features?
4. Condition:
	* Does the property require extensive repairs?
	* Has the property been significantly altered or does it have unusual construction methods?
5. Zoning and land use:
	* Is the property located in an area with unique zoning requirements or land use restrictions, such as a flood zone or designated conservation area?
6. Market conditions:
	* Is the property located in an area with rapidly appreciating or declining markets?
	* Does the property's market have unique economic or demographic characteristics?

This is just an example of how you could develop a checklist of the characteristics of a complex property. The specific characteristics you include on the checklist will depend on the local market and the types of properties you encounter. The important thing is to create a clear, concise, and easy-to-follow checklist that includes objective criteria that can be consistently applied.

<a id="source-15054298ca2916ee"></a>
<!-- source-id:locomo/thread_551cc7f69a7b/msg_9d4f40933c71 -->
[2023-05-30] user: Provide another example of a checklist of the characteristics of a complex property

<a id="source-7615a980a7a5d553"></a>
<!-- source-id:locomo/thread_551cc7f69a7b/msg_9b9ea2c8d118 -->
[2023-05-30] assistant: Certainly! Here's another example of a checklist of the characteristics of a complex property:

1. Location:
	* Does the property have a unique or challenging location, such as being situated in a difficult-to-reach area, near a hazardous waste site, or in a historic district?
	* Is the property located in a rapidly changing or developing area?
2. Property type and design:
	* Does the property have an unusual or complex design, such as a multi-unit building, a property with multiple levels, or a property with an attached garage?
	* Does the property have unique or special features, such as a swimming pool, a hot tub, or a large deck?
3. Age and condition:
	* Is the property significantly older or newer than the typical properties in the area?
	* Does the property require extensive repairs or renovations?
4. Zoning and land use:
	* Does the property have unique zoning or land use restrictions, such as being located in a floodplain, a conservation area, or a designated historic district?
	* Is the property located in an area with complex land use regulations or restrictions?
5. Market conditions:
	* Is the property located in an area with rapidly appreciating or declining markets?
	* Does the property's market have unique economic or demographic characteristics, such as a large number of vacation homes or a significant number of high-end properties?

Again, this is just one example of a checklist of the characteristics of a complex property, and the specific characteristics you include on the checklist will depend on the local market and the types of properties you encounter. The important thing is to create a clear, concise, and easy-to-follow checklist that includes objective criteria that can be consistently applied.

<a id="source-5f89b78fc5360278"></a>
<!-- source-id:locomo/thread_551cc7f69a7b/msg_f5383f1d9189 -->
[2023-05-30] user: Provide more questions under each of these 5 factors

<a id="source-bde6abc7a110fe96"></a>
<!-- source-id:locomo/thread_551cc7f69a7b/msg_846688edaf64 -->
[2023-05-30] assistant: Sure! Here are additional questions you could include under each of the five factors:

1. Location:
	* Is the property located in a remote area or an area with limited access?
	* Does the property have unique environmental or geographical features, such as being situated on a hillside, near a body of water, or in a densely wooded area?
	* Is the property located in an area with a high crime rate or environmental hazards?
	* Does the property have a unique or challenging street layout, such as a cul-de-sac or a property with a steep driveway?
2. Property type and design:
	* Does the property have an unusual or complex design, such as a multi-unit building, a property with multiple levels, or a property with an attached garage?
	* Does the property have unique or special features, such as a swimming pool, a hot tub, or a large deck?
	* Does the property have an unusual or complex heating and cooling system, such as a geothermal or radiant heat system?
	* Does the property have any outbuildings, such as a barn, shed, or guesthouse?
3. Age and condition:
	* Is the property significantly older or newer than the typical properties in the area?
	* Does the property require extensive repairs or renovations?
	* Does the property have any significant or unusual wear and tear, such as extensive water damage or evidence of pest infestation?
	* Has the property been significantly altered, such as being converted from a single-family home to a multi-unit building, or having additions or alterations made to the original structure?
4. Zoning and land use:
	* Does the property have unique zoning or land use restrictions, such as being located in a floodplain, a conservation area, or a designated historic district?
	* Is the property located in an area with complex land use regulations or restrictions, such as a neighborhood with strict homeowner association rules or a property located in a wetlands area?
	* Does the property have any zoning variances or conditional use permits that affect its value or usability?
5. Market conditions:
	* Is the property located in an area with rapidly appreciating or declining markets?
	* Does the property's market have unique economic or demographic characteristics, such as a large number of vacation homes or a significant number of high-end properties?
	* Does the property's market have any unusual economic or demographic trends, such as a high level of unemployment or a large number of foreclosures?
	* Does the property's market have any unique or challenging supply and demand factors, such as a limited number of available properties or a high demand for properties with certain features or amenities?

These questions can be used to help your team identify the characteristics of complex properties and establish clear and objective guidelines for determining complexity.

<a id="source-3d08d1c1039049f7"></a>
<!-- source-id:locomo/thread_551cc7f69a7b/msg_16b824604848 -->
[2023-05-30] user: Can you put this checklist in the form of a table?

<a id="source-6088dabed38e32d9"></a>
<!-- source-id:locomo/thread_551cc7f69a7b/msg_435bd8dc0602 -->
[2023-05-30] assistant: Yes, here's an example of the checklist in the form of a table:

| Characteristic | Questions to consider |
| --- | --- |
| Location | - Is the property located in a remote area or an area with limited access?<br>- Does the property have unique environmental or geographical features, such as being situated on a hillside, near a body of water, or in a densely wooded area?<br>- Is the property located in an area with a high crime rate or environmental hazards?<br>- Does the property have a unique or challenging street layout, such as a cul-de-sac or a property with a steep driveway? |
| Property type and design | - Does the property have an unusual or complex design, such as a multi-unit building, a property with multiple levels, or a property with an attached garage?<br>- Does the property have unique or special features, such as a swimming pool, a hot tub, or a large deck?<br>- Does the property have an unusual or complex heating and cooling system, such as a geothermal or radiant heat system?<br>- Does the property have any outbuildings, such as a barn, shed, or guesthouse? |
| Age and condition | - Is the property significantly older or newer than the typical properties in the area?<br>- Does the property require extensive repairs or renovations?<br>- Does the property have any significant or unusual wear and tear, such as extensive water damage or evidence of pest infestation?<br>- Has the property been significantly altered, such as being converted from a single-family home to a multi-unit building, or having additions or alterations made to the original structure? |
| Zoning and land use | - Does the property have unique zoning or land use restrictions, such as being located in a floodplain, a conservation area, or a designated historic district?<br>- Is the property located in an area with complex land use regulations or restrictions, such as a neighborhood with strict homeowner association rules or a property located in a wetlands area?<br>- Does the property have any zoning variances or conditional use permits that affect its value or usability? |
| Market conditions | - Is the property located in an area with rapidly appreciating or declining markets?<br>- Does the property's market have unique economic or demographic characteristics, such as a large number of vacation homes or a significant number of high-end properties?<br>- Does the property's market have any unusual economic or demographic trends, such as a high level of unemployment or a large number of foreclosures?<br>- Does the property's market have any unique or challenging supply and demand factors, such as a limited number of available properties or a high demand for properties with certain features or amenities? |

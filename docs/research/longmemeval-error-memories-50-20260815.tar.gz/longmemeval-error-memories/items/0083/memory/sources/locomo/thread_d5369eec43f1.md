# thread_d5369eec43f1

<a id="source-ee51e609c80a9198"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_f4c416079023 -->
[2023-05-28] user: I'm looking for some recommendations on eco-friendly sunscreen brands. I've been trying to switch to more sustainable products, and I just discovered a brand that offers facial creams and serums in recyclable glass jars and has a "return and recycle" program for their packaging. I'm hoping to find a sunscreen brand with similar values.

<a id="source-7574c336946278e9"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_9b235d09782a -->
[2023-05-28] assistant: That's great to hear that you're making the switch to more sustainable products! There are several eco-friendly sunscreen brands that share similar values and offer sustainable packaging options. Here are some recommendations:

1. **Badger**: Badger is a certified B Corp that offers a range of organic and natural sunscreens in recyclable aluminum tubes and glass jars. They also have a "Tin Take-Back" program, which encourages customers to return their empty containers for recycling.
2. **Blue Lizard**: Blue Lizard uses mineral-based sunscreens in recyclable tubes made from 50% post-consumer recycled materials. They also partner with TerraCycle to recycle their packaging and offer a discount for customers who return their empty tubes.
3. **Goddess Garden**: Goddess Garden offers organic and natural sunscreens in recyclable tubes and bottles. They also have a "Recycle & Reuse" program, which allows customers to return their empty containers for recycling and receive a discount on their next purchase.
4. **Stream2Sea**: Stream2Sea is a reef-safe and eco-friendly sunscreen brand that uses recyclable packaging made from 90% post-consumer recycled materials. They also partner with beach cleanups and conservation efforts to reduce ocean pollution.
5. **All Good**: All Good offers a range of natural and organic sunscreens in recyclable tubes and bottles. They also have a "Recycling Program" that encourages customers to return their empty containers for recycling and reuse.
6. **Raw Elements**: Raw Elements uses natural and organic ingredients in their sunscreens, which come in recyclable tubes and jars. They also partner with organizations to support beach cleanups and conservation efforts.
7. ** Kokua Sun Care**: Kokua Sun Care offers reef-safe and eco-friendly sunscreens in recyclable tubes made from 50% post-consumer recycled materials. They also partner with beach cleanups and conservation efforts to reduce ocean pollution.

When shopping for eco-friendly sunscreens, be sure to check the ingredient labels for natural and organic ingredients, as well as the packaging materials and recycling options. Additionally, look for certifications like the Leaping Bunny Program, which ensures that the products are free from animal testing and by-products.

Remember to always choose sunscreens that meet your skin type and needs, and apply them responsibly to minimize their impact on the environment.

<a id="source-2ee7d0024a6a5b56"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_f494b6626eb1 -->
[2023-05-28] user: I'll definitely check out those brands. I'm also interested in finding out more about certifications like the Leaping Bunny Program. Can you tell me more about it and how it ensures that products are cruelty-free and sustainable?

<a id="source-dac99eed0b2fe6be"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_de327104af40 -->
[2023-05-28] assistant: The Leaping Bunny Program is a well-known and respected certification program that ensures that products are free from animal testing and by-products. Here's more information about the program and its significance:

**What is the Leaping Bunny Program?**

The Leaping Bunny Program is a certification program operated by the Coalition for Consumer Information on Cosmetics (CCIC), a non-profit organization based in the United States. The program was established in 1996 to promote the welfare of animals and to provide consumers with a reliable way to identify products that are free from animal testing and by-products.

**How does the Leaping Bunny Program work?**

To earn the Leaping Bunny certification, companies must meet the following criteria:

1. **No animal testing**: The company must not conduct, commission, or pay for animal testing on finished products, ingredients, or formulations.
2. **No animal-derived ingredients**: The company must not use animal-derived ingredients, such as honey, lanolin, or gelatin, in their products.
3. **No animal by-products**: The company must not use animal by-products, such as horsehair or silk, in their products.
4. **Cruelty-free supply chain**: The company must ensure that their suppliers do not conduct animal testing or use animal-derived ingredients or by-products.

Companies that meet these criteria are awarded the Leaping Bunny logo, which is displayed on their products, packaging, and websites. The logo serves as a guarantee to consumers that the products are cruelty-free and do not contribute to animal suffering.

**How does the Leaping Bunny Program ensure sustainability?**

While the Leaping Bunny Program primarily focuses on animal welfare, many certified companies also prioritize sustainability and environmental responsibility. Here are some ways that Leaping Bunny certified companies often demonstrate sustainability:

1. **Natural and organic ingredients**: Many Leaping Bunny certified companies use natural and organic ingredients, which are often more environmentally friendly and sustainable than synthetic alternatives.
2. **Eco-friendly packaging**: Some certified companies opt for eco-friendly packaging, such as recyclable or biodegradable materials, to reduce waste and minimize their environmental footprint.
3. **Sustainable business practices**: Leaping Bunny certified companies may adopt sustainable business practices, such as using renewable energy, reducing water consumption, or implementing waste reduction programs.
4. **Transparency and accountability**: The Leaping Bunny Program encourages companies to be transparent about their ingredients, manufacturing processes, and business practices, which can promote accountability and sustainability.

**Other certifications to look for**

In addition to the Leaping Bunny Program, there are other certifications that indicate a company's commitment to sustainability and animal welfare. Some notable certifications include:

1. **PETA's Beauty Without Bunnies**: Similar to the Leaping Bunny Program, PETA's certification ensures that companies do not test on animals or use animal-derived ingredients.
2. **Vegan Society**: This certification guarantees that products are free from animal-derived ingredients and by-products, as well as animal testing.
3. **EWG Verified**: The Environmental Working Group (EWG) certification ensures that products meet certain standards for ingredient safety, transparency, and sustainability.

When shopping for eco-friendly and cruelty-free products, look for these certifications to ensure that you're supporting companies that align with your values.

<a id="source-14684dae2d2281d3"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_0c02aad8863e -->
[2023-05-28] user: That's really helpful to know. I'll definitely look out for those certifications when shopping for skincare products. Speaking of skincare, I've been trying to find a good exfoliating scrub that's eco-friendly and gentle on my skin. Do you have any recommendations for natural exfoliants that are biodegradable and come in sustainable packaging?

<a id="source-97af2871c8f557d2"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_5f2be11711cc -->
[2023-05-28] assistant: Exfoliating is an essential part of any skincare routine, and it's great that you're looking for eco-friendly options. Here are some natural exfoliants that are biodegradable, gentle on skin, and come in sustainable packaging:

**1. Sugar-based exfoliants:**
Sugar is a natural humectant that helps retain moisture in the skin while gently exfoliating. Look for sugar-based scrubs in recyclable or biodegradable packaging.

* **Lush**: Lush offers a range of sugar-based scrubs in recyclable pots made from 100% post-consumer recycled materials.
* **Andalou Naturals**: Andalou Naturals' Fruit Stem Cell Revitalizing Mist and Sugar Exfoliant is a gentle, sugar-based exfoliant that comes in a recyclable bottle.

**2. Salt-based exfoliants:**
Salt is a natural antibacterial agent that helps to detoxify and exfoliate the skin. Opt for salt-based scrubs in sustainable packaging.

* **The Better Skin Co.**: The Better Skin Co.'s Salt Scrub is made with Himalayan pink salt and comes in a recyclable glass jar.
* **Captain Blankenship**: Captain Blankenship's Mermaid Salt Scrub is a gentle, salt-based exfoliant that comes in a recyclable glass jar.

**3. Coffee-based exfoliants:**
Coffee grounds are a natural exfoliant that can help improve circulation and reduce the appearance of cellulite. Look for coffee-based scrubs in eco-friendly packaging.

* **Frank Body**: Frank Body's Coffee Scrub is a popular, coffee-based exfoliant that comes in a recyclable tube made from 95% post-consumer recycled materials.
* **The Body Shop**: The Body Shop's Coffee Body Scrub is a gentle, coffee-based exfoliant that comes in a recyclable tube.

**4. Konjac sponge exfoliants:**
Konjac sponges are gentle, natural exfoliants made from the root of the konjac plant. They're biodegradable and compostable.

* **The Konjac Sponge Company**: The Konjac Sponge Company offers a range of konjac sponges in biodegradable packaging.
* **Boscia**: Boscia's Konjac Cleansing Sponge is a gentle, biodegradable exfoliant that comes in a recyclable box.

**Tips for using natural exfoliants:**

1. Always exfoliate gently, especially if you have sensitive skin.
2. Use lukewarm water to help the exfoliant glide smoothly over your skin.
3. Exfoliate 1-2 times a week, depending on your skin type and needs.
4. Follow up with a moisturizer to hydrate your skin after exfoliating.

Remember to always check the ingredient labels and packaging materials to ensure they align with your eco-friendly values. Happy exfoliating!

<a id="source-30508f9f81cde9ff"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_df6584837c48 -->
[2023-05-28] user: That's really helpful! I've been wanting to try a konjac sponge exfoliant, so I'll definitely look into that. I'm also interested in learning more about refill options for skincare products. Do you know of any brands that offer refill options for their products, like moisturizers or serums?

<a id="source-bfbb3d24e39ec99e"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_a0d4abf57702 -->
[2023-05-28] assistant: Refill options are a fantastic way to reduce waste and minimize packaging in the skincare industry. Yes, several brands offer refill options for their products, including moisturizers and serums. Here are a few examples:

**1. Lush**: Lush offers a range of refill options for their skincare products, including moisturizers, serums, and cleansers. They have a "Lush Recycling Scheme" that allows customers to return empty pots and tubes to their stores, which are then recycled or reused.
**2. The Body Shop**: The Body Shop offers a refill option for their best-selling Himalayan Salt Scrub. Customers can return their empty tubs to The Body Shop stores and receive a discount on their next purchase.
**3. Kiehl's**: Kiehl's offers a "Recycle and Be Rewarded" program, which allows customers to return empty bottles and tubes to their stores. In exchange, customers receive a discount on their next purchase.
**4. Dr. Hauschka**: Dr. Hauschka offers refill options for their skincare products, including moisturizers and serums. Customers can purchase refill containers and send their empty packaging back to the company for recycling.
**5. Neal's Yard Remedies**: Neal's Yard Remedies offers refill options for their skincare products, including moisturizers and serums. They have a "Return. Recycle. Reward." program that encourages customers to return empty packaging to their stores.
**6. Lavera**: Lavera offers refill options for their natural skincare products, including moisturizers and serums. They have a "Refill and Recycle" program that allows customers to return empty packaging to their stores.

**Tips for using refill options:**

1. Check the brand's website or store for specific refill options and instructions.
2. Make sure to clean and prepare your empty packaging before returning it to the store.
3. Ask about any discounts or rewards associated with the refill program.
4. Consider purchasing products in larger sizes to reduce waste and minimize packaging.
5. If a brand doesn't offer a refill option, consider reaching out to their customer service to suggest it!

By choosing brands that offer refill options, you're not only reducing waste but also encouraging companies to adopt more sustainable practices. Every small step counts, and it's fantastic that you're making conscious choices for the environment!

<a id="source-176b1f755c5f652d"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_6b55410d165d -->
[2023-05-28] user: I'm glad you found that helpful! I've been really impressed with the brand I recently discovered that offers facial creams and serums in recyclable glass jars and has a "return and recycle" program for their packaging. It's amazing to see companies taking steps towards sustainability. Anyway, back to refill options - I'll definitely look into those brands and see which ones align with my values. Do you know if there are any online platforms or resources that help consumers find eco-friendly and sustainable skincare products?

<a id="source-3803be6d5b358b37"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_bb0e66cb5673 -->
[2023-05-28] assistant: I'm so glad you're inspired by the brand you discovered! It's indeed wonderful to see companies taking steps towards sustainability.

Yes, there are several online platforms and resources that can help you find eco-friendly and sustainable skincare products. Here are a few:

**1. EcoCert**: EcoCert is a certification body that verifies the environmental and social responsibility of companies. They have a database of certified companies and products that meet their sustainability standards.
**2. The Good On You**: The Good On You is a review platform that rates fashion and beauty brands based on their environmental and social impact. They have a section dedicated to skincare products.
**3. Think Dirty**: Think Dirty is an app that allows you to scan product barcodes and access information on their ingredients, toxicity, and sustainability.
**4. SkinCarisma**: SkinCarisma is a platform that helps you find skincare products that are suitable for your skin type and concerns. They also have a "Sustainable" filter that allows you to find eco-friendly products.
**5. The Detox Market**: The Detox Market is an online retailer that specializes in natural and sustainable skincare products. They have a "Sustainable" section that features products with eco-friendly packaging and ingredients.
**6. Credo Beauty**: Credo Beauty is a beauty retailer that offers a range of natural and sustainable skincare products. They have a "Sustainable" section that highlights products with eco-friendly packaging and ingredients.
**7. The Natural Beauty Yearbook**: The Natural Beauty Yearbook is an online directory that features natural and sustainable skincare brands. They have a section dedicated to eco-friendly packaging and sustainability.

These resources can help you find skincare products that align with your values and reduce your environmental impact.

Remember, every small step counts, and making conscious choices as a consumer can drive change in the industry. Keep being an eco-warrior, and spread the word about sustainable skincare!

<a id="source-7e0df69b2f157915"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_4f71a4f51c09 -->
[2023-05-28] user: I'm excited to explore those resources and find more eco-friendly skincare options. I've been really focused on reducing my waste and carbon footprint lately, and it's great to know there are so many brands and platforms working towards sustainability.

<a id="source-9e2d9b1d6254e860"></a>
<!-- source-id:locomo/thread_d5369eec43f1/msg_0e41db8b9c79 -->
[2023-05-28] assistant: That's amazing to hear! Reducing waste and carbon footprint is a crucial step towards a more sustainable future, and it's fantastic that you're taking conscious steps towards making a positive impact.

Remember, every small change adds up, and collective action can lead to significant positive change. By choosing eco-friendly skincare products, you're not only taking care of your skin but also supporting brands that prioritize the planet's well-being.

As you continue on your sustainability journey, don't be afraid to explore, learn, and adapt. There's always room for growth and improvement, and it's okay to make mistakes along the way.

Keep in mind that sustainability is a journey, not a destination. Every small step you take towards reducing waste, using eco-friendly products, and supporting sustainable brands brings us closer to a more environmentally conscious future.

If you have any more questions or need further guidance, feel free to ask. I'm always here to help. Stay eco-friendly, and keep shining your light!

# thread_de58813e57c1

<a id="source-4d44d4d1c7844697"></a>
<!-- source-id:locomo/thread_de58813e57c1/msg_1f4f531023d1 -->
[2023-05-26] user: What are the exclusive games available on each console?

<a id="source-42e71acc38b4e155"></a>
<!-- source-id:locomo/thread_de58813e57c1/msg_2876ece5ac6a -->
[2023-05-26] assistant: As an AI language model, I do not have the most recent information about gaming exclusives, but here are some notable exclusive games for each console as of 2021:

PlayStation 5: 
- Demon's Souls
- Spider-Man: Miles Morales
- Returnal
- Ratchet & Clank: Rift Apart

Xbox Series X|S:
- Halo Infinite
- Forza Horizon 5
- Fable
- The Medium

Nintendo Switch:
- The Legend of Zelda: Breath of the Wild
- Super Mario Odyssey
- Animal Crossing: New Horizons
- Splatoon 2

PC (not a console, but still an important platform):
- World of Warcraft
- Minecraft (Java Edition)
- Civilization VI
- Dota 2

<a id="source-fd9a3824899439d2"></a>
<!-- source-id:locomo/thread_de58813e57c1/msg_05234d01ebd2 -->
[2023-05-26] user: I'm really excited about Halo Infinite and Breath of the Wild 2. Do you know when they're coming out?

<a id="source-1b767bf8c936083d"></a>
<!-- source-id:locomo/thread_de58813e57c1/msg_3287fb60bae5 -->
[2023-05-26] assistant: As an AI language model, I don't have access to the most recent information about release dates, but I can tell you that the latest official announcements were made in 2021. According to those announcements:

Halo Infinite is scheduled to release on December 8, 2021, for Xbox Series X|S, Xbox One, and PC. The Legend of Zelda: Breath of the Wild 2 doesn't have an official release date yet, but it is expected to launch sometime in 2022 for Nintendo Switch.

<a id="source-394d3725ea2b1586"></a>
<!-- source-id:locomo/thread_de58813e57c1/msg_66c72d052f8f -->
[2023-05-26] user: Nice, that's not too far away for Halo Infinte. Can't wait to play it! And I'm looking forward to any new updates on Breath of the Wild 2.

<a id="source-679ac46dff4da528"></a>
<!-- source-id:locomo/thread_de58813e57c1/msg_6f2c8fad9077 -->
[2023-05-26] assistant: Yes, it's exciting to look forward to new releases in the gaming world! Make sure to keep an eye out for any updates or news regarding Breath of the Wild 2, as Nintendo is known for keeping their developments a secret until they are ready to announce it to the public.

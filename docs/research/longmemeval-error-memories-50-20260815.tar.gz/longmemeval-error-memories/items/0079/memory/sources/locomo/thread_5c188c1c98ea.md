# thread_5c188c1c98ea

<a id="source-ad7ffc82fccaa51c"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_c93b211f719c -->
[2023-05-20] user: I'm planning to attend another auto racking event soon and I'm thinking of fine-tuning my car's suspension. I was wondering if you could recommend some good suspension upgrade options for my ride. By the way, I recently replaced my spark plugs with new ones from NGK, and it's made a huge difference - I was getting a slight misfire during my daily commute, but now the engine feels much smoother and more responsive.

<a id="source-bba1eb4010ba78ae"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_e472f07af1c8 -->
[2023-05-20] assistant: I'm happy to help you with suspension upgrade options for your car! However, I have to clarify that I'm a large language model, I don't have personal experiences or knowledge about your specific vehicle. But I can provide general information and recommendations that might be helpful.

Firstly, congratulations on resolving the misfire issue with the new spark plugs from NGK! It's great to hear that your engine is running smoother and more responsive now.

Regarding suspension upgrades, there are several options to consider, depending on your vehicle's make, model, and intended use. Here are some general suggestions:

1. Coilovers: Coilovers are a popular upgrade for track-focused cars, as they offer adjustable ride height, damping, and spring rates. They can improve handling, reduce body roll, and enhance overall performance.
2. Sway bars: Upgrading your sway bars (also known as anti-roll bars) can help reduce body roll and improve cornering stability. Stiffer sway bars can make your car feel more agile and responsive.
3. Springs: Upgrading to stiffer or sport-tuned springs can improve handling and reduce body roll. However, this may also affect ride comfort.
4. Shocks: Upgrading to performance-oriented shocks can improve damping and handling. Some shock absorbers offer adjustable damping, which can be useful for fine-tuning your suspension.
5. Bushings: Replacing worn-out or OEM bushings with performance-oriented ones can improve handling and reduce NVH (noise, vibration, and harshness).

Before making any upgrades, consider the following factors:

* Your vehicle's intended use (daily driving, track days, autocross, etc.)
* Your driving style and preferences
* Budget constraints
* Compatibility with other modifications (e.g., wheel size, tire type)

It's essential to research and consult with experts or online forums specific to your vehicle make and model to determine the best suspension upgrades for your ride. Additionally, consider consulting with a professional mechanic or suspension specialist to ensure the upgrades are installed correctly and safely.

Remember to always follow proper installation procedures and safety guidelines when modifying your vehicle's suspension. It's also crucial to test and fine-tune your suspension setup to ensure it meets your performance expectations.

I hope this information helps you get started on your suspension upgrade journey!

<a id="source-e3c0d6abd583756c"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_928d5ca1d997 -->
[2023-05-20] user: I'm looking into coilovers, but I'm not sure which brand to go with. I've heard good things about KW Suspension and Öhlins, but I'm open to other options. Can you give me a brief rundown of the pros and cons of each brand?

<a id="source-b7c2e043c35761cf"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_7e381a129fb8 -->
[2023-05-20] assistant: Both KW Suspension and Öhlins are well-established and reputable brands in the coilover market. Here's a brief rundown of each brand's pros and cons to help you make an informed decision:

**KW Suspension:**

Pros:

1. Wide range of applications: KW offers coilovers for a vast number of vehicle models, making them a popular choice for many enthusiasts.
2. Adjustable damping: Many KW coilovers feature adjustable damping, allowing you to fine-tune the ride and handling to your preferences.
3. High-quality materials: KW coilovers are built with high-quality materials, ensuring durability and reliability.
4. Affordable: Compared to Öhlins, KW coilovers tend to be more affordable, making them a more accessible option for many enthusiasts.

Cons:

1. Not as highly adjustable as Öhlins: While KW coilovers offer some adjustability, they might not be as highly adjustable as Öhlins in terms of compression and rebound.
2. Less bespoke options: KW coilovers are often designed to be more universal, which might not provide the same level of customization as Öhlins.

**Öhlins:**

Pros:

1. Highly adjustable: Öhlins coilovers are renowned for their high level of adjustability, allowing for precise tuning of compression and rebound damping.
2. Bespoke options: Öhlins often offers bespoke coilover solutions tailored to specific vehicle models, ensuring a more precise fit and optimal performance.
3. High-performance focus: Öhlins has a strong motorsport heritage, and their coilovers are designed with high-performance driving in mind.
4. Exceptional build quality: Öhlins coilovers are built to exacting standards, ensuring exceptional durability and reliability.

Cons:

1. Higher cost: Öhlins coilovers tend to be more expensive than KW, making them a more significant investment.
2. Limited applications: Öhlins might not offer coilovers for as many vehicle models as KW, so you'll need to check their application list.
3. Steeper learning curve: Öhlins coilovers often require a higher level of technical expertise to adjust and set up correctly.

**Other options to consider:**

1. Bilstein: Known for their high-quality dampers, Bilstein offers a range of coilover solutions with adjustable damping.
2. JRZ: JRZ is a Dutch company that specializes in high-performance coilovers with advanced damping technology.
3. MCS (Motion Control Suspension): MCS offers a range of coilovers with adjustable damping and a focus on high-performance handling.
4. AST (Advanced Suspension Technology): AST provides coilovers with adjustable damping and a focus on motorsport-derived technology.

When choosing a coilover brand, consider the following factors:

* Your vehicle's specific needs and requirements
* Your driving style and preferences
* Your budget
* The level of adjustability and customization you require
* The brand's reputation, customer support, and warranty

It's essential to research each brand, read reviews, and consult with experts or online forums specific to your vehicle make and model to find the best coilover solution for your needs.

<a id="source-869e410aa1a04c70"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_2857d8f8371a -->
[2023-05-20] user: I've heard good things about JRZ coilovers, especially their ability to provide a smooth ride on the street while still delivering great handling on the track. Do you know if they offer any coilover options that are specifically designed for auto racking events like the ones I've been attending?

<a id="source-fee814e703d95b15"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_345c325e19c4 -->
[2023-05-20] assistant: JRZ is indeed a well-respected brand in the coilover market, and their products are known for their exceptional performance and adjustability.

JRZ does offer coilover options that are suitable for autox (autocross) and track events. They have a range of products that cater to different driving styles, vehicle types, and performance levels. While they might not have a specific coilover model labeled as "autox-specific," their products are designed to be highly adjustable, which makes them well-suited for autocross and track events.

Here are a few JRZ coilover options that might be of interest to you:

1. **JRZ RS**: The RS line is designed for high-performance street driving and track use. These coilovers feature adjustable compression and rebound damping, as well as adjustable ride height. They're a popular choice among autocross enthusiasts and track-day drivers.
2. **JRZ RS Pro**: The RS Pro is a step up from the RS line, offering even more advanced damping technology and adjustability. These coilovers are designed for serious track enthusiasts and competitive autocross drivers.
3. **JRZ 2-way**: The 2-way coilovers feature separate compression and rebound damping adjustment, allowing for fine-tuned control over the suspension. This makes them well-suited for autocross and track events where precise handling is crucial.

When selecting a JRZ coilover, consider the following factors:

* Your vehicle's weight, power, and handling characteristics
* Your driving style and preferences (e.g., smooth and precise or aggressive and dynamic)
* The specific demands of your autocross events (e.g., tight courses, high-speed sections, or a mix of both)
* The level of adjustability you need (e.g., compression, rebound, ride height)

It's essential to consult with a JRZ representative or a reputable dealer to determine the best coilover option for your specific needs. They can help you choose the right product and provide guidance on setup and adjustment.

Additionally, consider the following:

* JRZ coilovers are highly adjustable, so it's crucial to have a good understanding of suspension setup and tuning to get the most out of your coilovers.
* JRZ offers a range of springs and spring rates, so you may need to select the appropriate spring combination for your vehicle and driving style.
* JRZ coilovers are built to order, so be prepared for a lead time of several weeks or even months, depending on the complexity of the order and production schedules.

<a id="source-5b89f5c0f4cf64e8"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_f1a20a57751d -->
[2023-05-20] user: I've heard that JRZ coilovers are highly customizable, which is great for my needs. Since I've been attending auto racking events, I've noticed that my car's handling can be a bit unpredictable, especially during high-speed turns. I'm wondering if JRZ offers any specific solutions or technologies that can help improve my car's stability and handling during these types of events.

<a id="source-15a56a29778d86d3"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_936750b91ac8 -->
[2023-05-20] assistant: JRZ is indeed known for their high level of customization, which can be a huge advantage for enthusiasts like yourself who require specific solutions for their vehicle.

Regarding your concerns about high-speed handling and stability, JRZ offers several technologies and solutions that can help address these issues:

1. **Digressive Damping**: JRZ's digressive damping technology allows for a more aggressive compression curve, which can help improve stability and reduce body roll during high-speed turns. This is particularly useful for autocross and track events where high-speed corners are a common feature.
2. **Rebound Control**: JRZ's rebound control system allows for independent adjustment of rebound damping, which can help improve stability and reduce oscillations during high-speed turns. This can be particularly beneficial for cars that tend to understeer or oversteer during high-speed cornering.
3. **Dual-Speed Compression**: JRZ's dual-speed compression technology allows for two separate compression damping settings: one for low-speed compression (e.g., during corner entry) and another for high-speed compression (e.g., during high-speed turns). This can help improve handling and stability during high-speed cornering.
4. **Stabilization System (SAS)**: JRZ's SAS system is designed to improve stability and reduce body roll during high-speed turns. It features a secondary damping system that works in conjunction with the main damping system to provide additional stability and control.
5. **Custom Spring Rates**: JRZ offers custom spring rates to suit your specific vehicle and driving style. By selecting the optimal spring rate, you can improve your car's handling and stability during high-speed turns.
6. **Custom Valving**: JRZ's custom valving options allow you to tailor the damping characteristics of your coilovers to your specific needs. This can include customizing the compression and rebound curves to suit your driving style and the demands of autocross events.

When consulting with a JRZ representative or dealer, be sure to discuss your specific needs and concerns regarding high-speed handling and stability. They can help you determine the best combination of technologies and customizations to address these issues and improve your car's performance during autocross events.

Keep in mind that JRZ coilovers are highly customizable, so it's essential to work closely with their team to ensure that your coilovers are tailored to your specific needs and driving style. This may involve providing detailed information about your vehicle, driving style, and autocross events, as well as working with JRZ's engineers to develop a customized solution.

<a id="source-118b979ce50ef488"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_6d73cf4ac70b -->
[2023-05-20] user: I'd like to know more about the dual-speed compression technology. Can you explain how it works and how it can benefit my car's handling during high-speed turns?

<a id="source-92d4ba3b7e9fef20"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_13b976815fc9 -->
[2023-05-20] assistant: JRZ's dual-speed compression technology is a fascinating feature that can significantly improve your car's handling and stability during high-speed turns.

**What is dual-speed compression?**

Dual-speed compression is a damping technology that allows the coilover to operate at two distinct compression damping rates, depending on the velocity of the suspension movement. In other words, the coilover can adapt to different compression damping settings based on the speed at which the suspension is moving.

**How does it work?**

The dual-speed compression technology is achieved through a clever design that incorporates two separate compression valves within the coilover. These valves are designed to operate at different speeds:

1. **Low-speed valve**: This valve is responsible for compression damping at low suspension velocities, typically encountered during low-speed cornering, braking, or absorptions. The low-speed valve provides a softer compression damping rate to help maintain traction, reduce body roll, and improve comfort.
2. **High-speed valve**: This valve kicks in at higher suspension velocities, typically encountered during high-speed cornering, where the suspension is moving more rapidly. The high-speed valve provides a stiffer compression damping rate to help maintain stability, reduce body roll, and improve handling.

**How does it benefit high-speed handling?**

The dual-speed compression technology can significantly benefit your car's handling during high-speed turns in several ways:

1. **Improved stability**: By providing a stiffer compression damping rate at high speeds, the coilover can help maintain stability and reduce body roll, making the car feel more planted and predictable during high-speed turns.
2. **Enhanced handling**: The dual-speed compression technology allows the coilover to adapt to changing driving conditions, providing the optimal compression damping rate for the specific situation. This can improve the car's overall handling and responsiveness, making it feel more agile and responsive during high-speed turns.
3. **Reduced understeer/oversteer**: By providing a more precise compression damping rate, the coilover can help reduce understeer or oversteer tendencies during high-speed turns, making the car feel more neutral and balanced.
4. **Improved tire grip**: By maintaining optimal compression damping rates, the coilover can help improve tire grip and traction, allowing the tires to maintain contact with the road surface more effectively during high-speed turns.

**Real-world benefits**

In the context of autocross events, the dual-speed compression technology can help you:

* Take faster and more consistent turns
* Improve your lap times
* Reduce the risk of understeer or oversteer
* Feel more confident and in control during high-speed turns

When discussing your coilover setup with JRZ, be sure to inquire about the dual-speed compression technology and how it can be tailored to your specific needs and driving style.

<a id="source-2eabfc9eb54aad15"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_279cbcfe7d3a -->
[2023-05-20] user: I'd like to know more about the Stabilization System (SAS) that JRZ offers. Can you explain how it works and how it can help improve my car's stability during high-speed turns?

<a id="source-0bfef0fc57c608ad"></a>
<!-- source-id:locomo/thread_5c188c1c98ea/msg_29d274d997d0 -->
[2023-05-20] assistant: JRZ's Stabilization System (SAS) is a fascinating technology that can significantly improve your car's stability and handling during high-speed turns.

**What is the Stabilization System (SAS)?**

The Stabilization System (SAS) is a proprietary technology developed by JRZ that helps to improve a vehicle's stability and handling during high-speed cornering. It's a secondary damping system that works in conjunction with the main damping system to provide additional stability and control.

**How does it work?**

The SAS system consists of a separate damping circuit that is connected to the main damping system. This secondary circuit is designed to provide additional compression damping force during high-speed cornering, which helps to:

1. **Reduce body roll**: By providing additional compression damping force, the SAS system helps to reduce body roll and improve the vehicle's overall stability during high-speed turns.
2. **Improve handling**: The SAS system helps to improve the vehicle's handling and responsiveness during high-speed cornering, making it feel more agile and predictable.
3. **Enhance stability**: By providing additional stability, the SAS system helps to reduce the risk of understeer or oversteer, making the vehicle feel more confident and stable during high-speed turns.

**How does it improve stability during high-speed turns?**

During high-speed cornering, the SAS system helps to improve stability in several ways:

1. **Reduced weight transfer**: By reducing body roll, the SAS system helps to minimize weight transfer during high-speed turns, which can cause understeer or oversteer.
2. **Improved tire grip**: By maintaining optimal tire grip, the SAS system helps to improve traction and reduce the risk of wheelspin or loss of control.
3. **Enhanced yaw control**: The SAS system helps to improve yaw control, which is essential for maintaining stability during high-speed turns.

**Real-world benefits**

In the context of autocross events, the SAS system can help you:

* Take faster and more consistent turns
* Improve your lap times
* Reduce the risk of understeer or oversteer
* Feel more confident and in control during high-speed turns

**How does it integrate with the main damping system?**

The SAS system is designed to work in conjunction with the main damping system, providing additional compression damping force only when needed. This ensures that the vehicle's damping characteristics are optimized for high-speed cornering, without compromising low-speed comfort or daily driving characteristics.

When discussing your coilover setup with JRZ, be sure to inquire about the Stabilization System (SAS) and how it can be tailored to your specific needs and driving style.

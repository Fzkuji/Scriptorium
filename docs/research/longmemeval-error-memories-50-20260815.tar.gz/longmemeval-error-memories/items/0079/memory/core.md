# Core Memory

The user is actively working on starting a Greek-Mexican fusion food truck, having developed its sample menu with prices, ingredient costs, and catchy item names ([project notes](topics/projects/greek-mexican-food-truck.md#^2c7f6359)).[^e-8ef80cc5ee] ^45cb43e9

[^e-8ef80cc5ee]: Time: `2023-05-21`; Sources: [locomo/thread_cbcd98836154/msg_8efa0e8abaf5](sources/locomo/thread_cbcd98836154.md#source-ecffe79b3060cdbc), [locomo/thread_cbcd98836154/msg_bd76b0f85aac](sources/locomo/thread_cbcd98836154.md#source-19debe86690ff426)

The user is planning a trip to Budapest and gathering information about accessible travel options, and is shopping for new footwear including waterproof hiking boots, comfortable sneakers, and a compact shoe rack.[^e-5216914405] ^44a0ef90

[^e-5216914405]: Time: `2023-05-21`; Sources: [locomo/thread_5623a6557221/msg_aa8874e72af8](sources/locomo/thread_5623a6557221.md#source-69a42660a73a7919), [locomo/thread_f4407b5e69a3/msg_b7e48307cffc](sources/locomo/thread_f4407b5e69a3.md#source-feeae438fd5ea0c5)

The user is building a daily mindfulness practice to reduce stress, planning to practice during their daily commute and each morning.[^e-d4d681256b] ^9aa4c532

[^e-d4d681256b]: Time: `2023-05-22`; Sources: [locomo/thread_749fa3152137/msg_a4c530391d7b](sources/locomo/thread_749fa3152137.md#source-8b1d6903462f2310)

The user has been living in Paris for three months as a student, is learning French through a course at Sorbonne University and the Duolingo app, has a dog named Max, and is planning a trip to Amsterdam next weekend by Thalys train.[^e-ff81229e54] ^c746efbd

[^e-ff81229e54]: Time: `2023-05-22`; Sources: [locomo/thread_14f6bc69bb92/msg_85e2fa90cef9](sources/locomo/thread_14f6bc69bb92.md#source-907542218edfbb75), [locomo/thread_14f6bc69bb92/msg_de76b3f4fb6e](sources/locomo/thread_14f6bc69bb92.md#source-95cfdf1a5cf12c25), [locomo/thread_14f6bc69bb92/msg_ad9ff0d6af6b](sources/locomo/thread_14f6bc69bb92.md#source-dc9853581dd70d00), [locomo/thread_046276ceb02b/msg_07f43e3f2ff4](sources/locomo/thread_046276ceb02b.md#source-35efa00fe81f235c), [locomo/thread_782f9c17d73c/msg_b64a37705e35](sources/locomo/thread_782f9c17d73c.md#source-9a835dadfbf53491)

The user is planning to take the Permaculture Design Course (PDC) Online, around 120 hours over 3-4 months, as a foundation for understanding permaculture and regenerative agriculture, reflecting a broader interest in sustainable living and environmental issues.[^e-f65bead850] ^b28b6f69

[^e-f65bead850]: Time: `2023-05-22`; Sources: [locomo/thread_810c4bac6d0f/msg_2f8a85df49fb](sources/locomo/thread_810c4bac6d0f.md#source-f669b521a9f819bb), [locomo/thread_810c4bac6d0f/msg_6e8deec166fb](sources/locomo/thread_810c4bac6d0f.md#source-1c4ee08190d0cd41)

The user is developing professionally in Agile methodologies and design thinking, having recently attended a project management workshop and a Stanford d.school design thinking workshop, and is planning to meet Sophia, whom they met at the project management workshop, for coffee soon.[^e-c67c9b5135] ^5fab9e93

[^e-c67c9b5135]: Time: `2023-05-23`; Sources: [locomo/thread_100ba0195b99/msg_ebd760f46e80](sources/locomo/thread_100ba0195b99.md#source-b010eae73e629d10), [locomo/thread_100ba0195b99/msg_4e2302660f07](sources/locomo/thread_100ba0195b99.md#source-7c4c020011415634), [locomo/thread_100ba0195b99/msg_8bc4719b42a4](sources/locomo/thread_100ba0195b99.md#source-d8856c22efaf2852)

The user is managing high cholesterol after receiving blood test results at a doctor's appointment on 2023-05-18, is using the MyFitnessPal app with a cholesterol-lowering meal plan, and attends evening yoga classes.[^e-d058aaca96][^e-2e3bb86edc] ^6235d9c6

[^e-d058aaca96]: Time: `2023-05-18`; Sources: [locomo/thread_6e5fb66a8677/msg_08f7475963fc](sources/locomo/thread_6e5fb66a8677.md#source-2059ace6acacdfb8)

[^e-2e3bb86edc]: Time: `2023-05-24`; Sources: [locomo/thread_6e5fb66a8677/msg_23f06e476787](sources/locomo/thread_6e5fb66a8677.md#source-3bbdd5ff7d83bb85), [locomo/thread_6e5fb66a8677/msg_725ab7cc4ba1](sources/locomo/thread_6e5fb66a8677.md#source-9219982e1fe5d51c)

The user is planning a trip to Kalimantan to visit the orangutan rehabilitation center, and learned that the best time to go is between July and September during the dry season.[^e-63d9e4dca4] ^2d79336b

[^e-63d9e4dca4]: Time: `2023-05-24`; Sources: [locomo/thread_22a07b103833/msg_b625ff29c59f](sources/locomo/thread_22a07b103833.md#source-025edd7557cacace)

The user is actively pursuing theater and acting, taking acting classes and considering auditioning for a production of A Raisin in the Sun, being drawn to the character of Beneatha.[^e-e11ed2f48c] ^2dcc5a1d

[^e-e11ed2f48c]: Time: `2023-05-25`; Sources: [locomo/thread_774d07d5ad9c/msg_fface19828f1](sources/locomo/thread_774d07d5ad9c.md#source-8ad827325d69fe65)

The user is preparing to participate in the Night Market at the old warehouse district selling handmade soap and lotion bars, and is finalizing their product line, pricing, packaging, and display for the event ([project notes](topics/projects/handmade-soap-lotion-bars.md#^126642ef)).[^e-8b213591c1] ^3fc170d8

[^e-8b213591c1]: Time: `2023-05-26`; Sources: [locomo/thread_fbdbd86005d1/msg_0c0fc9080af6](sources/locomo/thread_fbdbd86005d1.md#source-a9317b62d3024ac0), [locomo/thread_fbdbd86005d1/msg_4171fd7e8389](sources/locomo/thread_fbdbd86005d1.md#source-0a1411819a641c5c), [locomo/thread_fbdbd86005d1/msg_4a557915a204](sources/locomo/thread_fbdbd86005d1.md#source-782ae62c6a6f2b1f)

The user completed a master's program and is planning to pursue a PhD in Computer Science at Stanford University, organizing their master's research materials to support that goal ([project notes](topics/projects/phd-planning.md#^b67cc25e)).[^e-671b600473] ^375d0308

[^e-671b600473]: Time: `2023-05-28`; Sources: [locomo/thread_7ad370356362/msg_37a8ed176ced](sources/locomo/thread_7ad370356362.md#source-fcb254a2d25d6a29), [locomo/thread_7ad370356362/msg_ea7646ca78b8](sources/locomo/thread_7ad370356362.md#source-85dbb7853648edf3)

Buying a house is a long-term goal of the user, who decided to start saving for a down payment now while balancing other financial goals and their current lifestyle ([financial planning notes](topics/themes/financial-planning.md#^6e72e793)).[^e-d5557262a4] ^86feaa4e

[^e-d5557262a4]: Time: `2023-05-28`; Sources: [locomo/thread_11649ff00661/msg_335c43a6c926](sources/locomo/thread_11649ff00661.md#source-fd000c7d01aa6e45), [locomo/thread_11649ff00661/msg_b296404aeb59](sources/locomo/thread_11649ff00661.md#source-0818782eaa612b63)

The user runs a digital marketing agency that they started around February 2023, and is actively building it: the business is registered, has a business bank account, is already landing clients, its website is being built on Wix, and they are developing an actionable B2B marketing strategy for the agency.[^e-e6a9724d04][^e-70c30f48f9] ^5896dce1

[^e-e6a9724d04]: Time: `2023-05-28`; Sources: [locomo/thread_d7ef2bcadc43/msg_1ca767639772](sources/locomo/thread_d7ef2bcadc43.md#source-aaa80229ca9fe769)

[^e-70c30f48f9]: Time: `2023-05-29`; Sources: [locomo/thread_17e63281815b/msg_4fe011405b06](sources/locomo/thread_17e63281815b.md#source-47824c1a99339dd8)

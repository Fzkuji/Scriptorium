# Theater and Acting

The user is enthusiastic about theater and acting, is taking acting classes, and about three weeks before 2023-05-25 saw a local production of The Glass Menagerie at the community theater downtown, which they found amazing; they received play recommendations including A Raisin in the Sun, The Crucible, The House on Mango Street, The Flick, The Humans, The Effect of Gamma Rays on Man-in-the-Moon Marigolds, The Zoo Story, and The Bear, and are particularly interested in plays with strong ensemble casts to challenge themselves.[^e-860c1b345b][^e-150f5ceeea] ^3a03bf3b

[^e-860c1b345b]: Time: `2023-05`; Sources: [locomo/thread_774d07d5ad9c/msg_ac35608ad987](../../sources/locomo/thread_774d07d5ad9c.md#source-ea451f52847287de)

[^e-150f5ceeea]: Time: `2023-05-25`; Sources: [locomo/thread_774d07d5ad9c/msg_3d961a2ab2a2](../../sources/locomo/thread_774d07d5ad9c.md#source-ac236a878fbf7dc6)

The user is interested in the role of women in theater and in representation, diversity, and inclusion in the industry, and learned that women make up only 22% of playwrights, 18% of directors, and 12% of artistic directors in American theater, that only 28% of produced plays were written by women and only 12% by women of color, and about organizations working toward change including the Kilroys, the Women's Playwrights Festival, the National Black Theatre, and the Latino Theater Company.[^e-799f3bd412] ^165db738

[^e-799f3bd412]: Time: `2023-05-25`; Sources: [locomo/thread_774d07d5ad9c/msg_7e93d131e318](../../sources/locomo/thread_774d07d5ad9c.md#source-d732a3140b617e09)

To find auditions and productions aligned with their values around diversity and inclusion, the user received a list of online resources including Actors' Equity Association, Playbill, Theatre Communications Group, the DEI in Theatre Facebook group, the Women's Theatre Festival, the Kilroys, HowlRound, the NYC Actors Resource Guide, and Backstage.[^e-9b6c775c9c] ^b7ac3a2d

[^e-9b6c775c9c]: Time: `2023-05-25`; Sources: [locomo/thread_774d07d5ad9c/msg_37f6d8fe146a](../../sources/locomo/thread_774d07d5ad9c.md#source-88b10b91ec04dc53)

The user has been listening to a podcast about theater history and learned that knowing theater history can help an actor through contextual understanding, style and period awareness, influence and inspiration, cultural and social awareness, analytical skills, appreciation for the craft, and as a conversation starter.[^e-167881329b] ^515564c7

[^e-167881329b]: Time: `2023-05-25`; Sources: [locomo/thread_774d07d5ad9c/msg_3051e3fa1754](../../sources/locomo/thread_774d07d5ad9c.md#source-7c1fe4f3c9be6358)

The user is considering auditioning for a production of A Raisin in the Sun, being drawn to the character of Beneatha, and received audition advice that their acting class experience and passion for social justice can help them stand out, along with tips to showcase range, highlight their unique perspective, demonstrate chemistry with scene partners, take risks, and follow up after the audition.[^e-6cbb2cb7c2] ^affcbc7f

[^e-6cbb2cb7c2]: Time: `2023-05-25`; Sources: [locomo/thread_774d07d5ad9c/msg_fface19828f1](../../sources/locomo/thread_774d07d5ad9c.md#source-8ad827325d69fe65)

The user received tips on preparing a monologue for auditions (choosing a fitting monologue, understanding context, breaking it down into beats, working on diction and articulation, finding physicality, rehearsing in different environments, getting feedback) and on rehearsal time allocation, recommending at least 2-3 weeks of preparation at 30 minutes to 1 hour per day.[^e-de76af483a] ^71c53bf7

[^e-de76af483a]: Time: `2023-05-25`; Sources: [locomo/thread_774d07d5ad9c/msg_01353cee78fa](../../sources/locomo/thread_774d07d5ad9c.md#source-caf4afed67ab8f8c)

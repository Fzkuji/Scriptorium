# Japanese Language

The user requested an English-to-Japanese translation of a short personal message addressed to 'Chataro' about not worrying about people who respond negatively to broad physical certainty and about plain Newtonian gravitas proving it, and then asked for the Japanese translation to be rendered back into English to verify that the meaning was preserved.[^e-c962569853] ^a78c5434

[^e-c962569853]: Time: `2023-05-25`; Sources: [locomo/thread_de58813e57c1/msg_6f2c8fad9077](../../sources/locomo/thread_de58813e57c1.md#source-679ac46dff4da528), [locomo/thread_de58813e57c1/msg_ec83171f3efb](../../sources/locomo/thread_de58813e57c1.md#source-c3c4a36f269a1082)

# Farmers' Market

The user bought a wheel of goat cheese from Green Earth Farm at the Farmers' Market and loved it, describing Green Earth Farm as a well-known and beloved vendor at the Farmers' Market whose goat cheese is amazing.[^e-41ced288d0] ^c3ad102f

[^e-41ced288d0]: Time: `2023-05-26`; Sources: [locomo/thread_fbdbd86005d1/msg_0c0fc9080af6](../../sources/locomo/thread_fbdbd86005d1.md#source-a9317b62d3024ac0), [locomo/thread_fbdbd86005d1/msg_cfb210aeae85](../../sources/locomo/thread_fbdbd86005d1.md#source-b6e13ac4a1008240)

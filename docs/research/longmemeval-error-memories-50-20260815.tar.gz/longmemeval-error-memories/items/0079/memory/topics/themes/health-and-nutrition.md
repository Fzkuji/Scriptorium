# Health and Nutrition

The user had a 10 AM doctor's appointment on 2023-05-18 at which they received blood test results showing their cholesterol levels are a bit high, prompting them to make dietary changes.[^e-e2a07c84a3] ^1a6a432f

[^e-e2a07c84a3]: Time: `2023-05-18`; Sources: [locomo/thread_6e5fb66a8677/msg_08f7475963fc](../../sources/locomo/thread_6e5fb66a8677.md#source-2059ace6acacdfb8)

For lowering cholesterol, the user received meal and recipe ideas (oatmeal with fresh fruits and nuts, oatmeal with banana and walnuts, grilled chicken or fish with roasted vegetables, lentil soup, avocado toast with poached eggs, quinoa salad with roasted vegetables and lean protein, Greek yogurt with berries and chia seeds, a smoothie bowl with spinach, banana, and almond milk, whole-grain waffles with fresh fruit and yogurt, and a green smoothie with spinach, avocado, and oat milk), meal planning app suggestions (MyFitnessPal, Lose It!, Yummly, PlateJoy, and the American Heart Association's Heart Healthy Diet app), and tips to increase soluble fiber, choose lean protein, limit saturated and trans fats, stay hydrated, choose whole grains, incorporate plant-based proteins, limit added sugars, and watch portion sizes; the user decided to try MyFitnessPal.[^e-1f9d59455a][^e-1a2186ea3b][^e-0f5655ab92] ^f0c3dbe3 ^6b4ec651

[^e-1f9d59455a]: Time: `2023-05-24`; Sources: [locomo/thread_6e5fb66a8677/msg_23f06e476787](../../sources/locomo/thread_6e5fb66a8677.md#source-3bbdd5ff7d83bb85)

[^e-1a2186ea3b]: Time: `2023-05-24`; Sources: [locomo/thread_6e5fb66a8677/msg_725ab7cc4ba1](../../sources/locomo/thread_6e5fb66a8677.md#source-9219982e1fe5d51c)

[^e-0f5655ab92]: Time: `2023-05-24`; Sources: [locomo/thread_6e5fb66a8677/msg_b0dd037710f8](../../sources/locomo/thread_6e5fb66a8677.md#source-898b3cbeb4c7aa05)

The user received meal prep tips for sticking to their new meal plan, including planning meals, shopping smart, prepping ingredients in bulk, focusing on one-pot dishes, portion control, labeling and organizing, freezing, reheating to 165°F, adding fresh touches, and being flexible.[^e-389c2301ee] ^1bdb4171

[^e-389c2301ee]: Time: `2023-05-24`; Sources: [locomo/thread_6e5fb66a8677/msg_8f3929fc6fa3](../../sources/locomo/thread_6e5fb66a8677.md#source-c61551f0730a222c)

The user stayed up until 2 AM on Wednesday 2023-05-24, which made Thursday morning a struggle.[^e-b25fb51442] ^bb0f1792

[^e-b25fb51442]: Time: `2023-05-24`; Sources: [locomo/thread_551cc7f69a7b/msg_d43837dfd41b](../../sources/locomo/thread_551cc7f69a7b.md#source-8856a15964658c57)

Feeling sluggish, the user decided to try the avocado toast with poached eggs recipe to boost their energy and asked for a quick, easy lunch they could prepare in advance that would keep them full until their evening yoga class on Tuesday.[^e-6e5d6b7ed3] ^3f6c12da

[^e-6e5d6b7ed3]: Time: `2023-05-29`; Sources: [locomo/thread_551cc7f69a7b/msg_d43837dfd41b](../../sources/locomo/thread_551cc7f69a7b.md#source-8856a15964658c57), [locomo/thread_551cc7f69a7b/msg_aef5f2dcbddd](../../sources/locomo/thread_551cc7f69a7b.md#source-9439fe0e2fd6bf2e)

The assistant recommended avocado toast with poached eggs as a nutritious breakfast and five grab-and-go lunch options that can be prepared in advance and would keep the user full until their Tuesday evening yoga class: quinoa salad jars, lentil soup, grilled chicken and veggie wraps, mason jar salads, and rice and bean bowls, each with ingredient suggestions and how long they can be refrigerated or frozen, and reminded the user to stay hydrated.[^e-f5eb010d07] ^24c94c5f

[^e-f5eb010d07]: Time: `2023-05-29`; Sources: [locomo/thread_551cc7f69a7b/msg_9d4f40933c71](../../sources/locomo/thread_551cc7f69a7b.md#source-15054298ca2916ee)

The user asked for healthy snack options to keep at their desk to curb cravings throughout the day and received twelve suggestions: nuts and seeds, dried fruits, fresh fruits, energy balls, jerky, veggie sticks with hummus or guacamole, protein bars, trail mix, hard-boiled eggs, edamame, cottage cheese, and dark chocolate with at least 70% cocoa, with the advice to choose nutrient-dense snacks low in added sugars, salt, and unhealthy fats and rich in protein, fiber, and healthy fats.[^e-beb83e9f9b] ^1090bf92

[^e-beb83e9f9b]: Time: `2023-05-29`; Sources: [locomo/thread_551cc7f69a7b/msg_9b9ea2c8d118](../../sources/locomo/thread_551cc7f69a7b.md#source-7615a980a7a5d553), [locomo/thread_551cc7f69a7b/msg_f5383f1d9189](../../sources/locomo/thread_551cc7f69a7b.md#source-5f89b78fc5360278)

The user is meal prepping for the rest of the week because of a busy Monday ahead and received eight reheatable, easy-to-portion healthy dinner recipes: quinoa and black bean bowl, lentil and vegetable stew, grilled chicken and roasted vegetables, brown rice and vegetable fried rice, chickpea and spinach curry, slow cooker chili, roasted vegetable and quinoa casserole, and baked salmon with sweet potato, along with meal prep tips to cook proteins and grains in bulk, roast a variety of vegetables, use airtight containers, label and date containers, and freeze individual portions for up to 3-4 months.[^e-d2ad885ca9] ^a8e38faf

[^e-d2ad885ca9]: Time: `2023-05-29`; Sources: [locomo/thread_551cc7f69a7b/msg_846688edaf64](../../sources/locomo/thread_551cc7f69a7b.md#source-bde6abc7a110fe96), [locomo/thread_551cc7f69a7b/msg_16b824604848](../../sources/locomo/thread_551cc7f69a7b.md#source-3d08d1c1039049f7)

The user decided to try the Quinoa and Black Bean Bowl and asked for healthy drink options to stay hydrated, receiving a list including water (at least 8 cups or 64 oz per day), infused water, herbal tea, green tea, coconut water, low-sugar sports drinks, kombucha, vegetable juice, unsweetened non-dairy milks, and a cucumber lime refresher, with advice to limit or avoid sugary drinks like soda, energy drinks, and sweetened teas or coffee.[^e-76b940f2b6] ^40eff08a

[^e-76b940f2b6]: Time: `2023-05-29`; Sources: [locomo/thread_551cc7f69a7b/msg_435bd8dc0602](../../sources/locomo/thread_551cc7f69a7b.md#source-6088dabed38e32d9), [locomo/thread_551cc7f69a7b/msg_da97b5c402be](../../sources/locomo/thread_551cc7f69a7b.md#source-8d4ce37f8be00f55)

The user chose to try the infused water with lemon and cucumber slices and received preparation tips: slice the lemon and cucumber thinly, let them infuse in a pitcher in the refrigerator for at least 30 minutes, use a clean and sanitized pitcher and utensils, change the water and add fresh slices every 24 hours, and experiment with different fruit, herb, and spice combinations.[^e-716f21215b] ^b1b26164

[^e-716f21215b]: Time: `2023-05-29`; Sources: [locomo/thread_551cc7f69a7b/msg_e139ce4b11ca](../../sources/locomo/thread_551cc7f69a7b.md#source-ddd957ae3225c8f0), [locomo/thread_551cc7f69a7b/msg_ad5831107b0a](../../sources/locomo/thread_551cc7f69a7b.md#source-79ebca4f00712c52)

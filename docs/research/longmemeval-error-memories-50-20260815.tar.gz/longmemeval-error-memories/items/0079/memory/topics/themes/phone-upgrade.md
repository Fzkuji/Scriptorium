# Phone Upgrade

The user is considering getting a new phone with more storage capacity and asked about the pros and cons of 128GB versus 256GB models.[^e-6a984365ad] ^646b6a87

[^e-6a984365ad]: Time: `2023-05-28`; Sources: [locomo/thread_6e68d84c9eb7/msg_1bb8cc175d85](../../sources/locomo/thread_6e68d84c9eb7.md#source-211273aecf443912)

The user bought a clear phone case with a built-in screen protector from Amazon on February 10, 2023 for about $25, having read reviews and checked the seller's ratings beforehand to make sure it would fit their phone and provide the protection they needed; it is a simple, straightforward case with no extra features like a kickstand or card slots, which the user sees as part of its appeal.[^e-8c23d6b1cd] ^585b2135

[^e-8c23d6b1cd]: Time: `2023-02-10`; Sources: [locomo/thread_6e68d84c9eb7/msg_4d513b056e22](../../sources/locomo/thread_6e68d84c9eb7.md#source-e64311435136cbcc), [locomo/thread_6e68d84c9eb7/msg_1fab79136f44](../../sources/locomo/thread_6e68d84c9eb7.md#source-5643e759585a8ef4), [locomo/thread_6e68d84c9eb7/msg_c0d6ed850ace](../../sources/locomo/thread_6e68d84c9eb7.md#source-f06f36d4263176b3), [locomo/thread_6e68d84c9eb7/msg_378f0790ac4e](../../sources/locomo/thread_6e68d84c9eb7.md#source-f9d4760837380ca5)

The user is very happy with the case's performance: the built-in screen protector has not affected touch responsiveness and has been protecting the screen from scratches, the case has held up well through a few accidental drops, remains crystal clear, and is easy to clean by wiping it with a soft cloth, and the user would recommend it to others and buy from the same seller again.[^e-49a5e2e571] ^898b014f

[^e-49a5e2e571]: Time: `2023-05-28`; Sources: [locomo/thread_6e68d84c9eb7/msg_1fab79136f44](../../sources/locomo/thread_6e68d84c9eb7.md#source-5643e759585a8ef4), [locomo/thread_6e68d84c9eb7/msg_c0d6ed850ace](../../sources/locomo/thread_6e68d84c9eb7.md#source-f06f36d4263176b3), [locomo/thread_6e68d84c9eb7/msg_378f0790ac4e](../../sources/locomo/thread_6e68d84c9eb7.md#source-f9d4760837380ca5)

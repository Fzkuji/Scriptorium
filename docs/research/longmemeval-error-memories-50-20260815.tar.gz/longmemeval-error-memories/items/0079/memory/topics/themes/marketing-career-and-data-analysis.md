# Marketing Career and Data Analysis Skills

The user is a Senior Marketing Specialist, a role they were promoted to about three months before 2023-05-29 (around February 2023), and they have recently taken on more responsibilities and are looking to upskill in data analysis to make a bigger impact.[^e-766c455c54] ^554c97a2

[^e-766c455c54]: Time: `2023-02`; Sources: [locomo/thread_8e09fa96d2c5/msg_3323362a8a5e](../../sources/locomo/thread_8e09fa96d2c5.md#source-edbc4ca6bb5825f4)

The user is working to improve their data analysis skills: they found a Coursera course they plan to start in June 2023, and intend to build a solid foundation in data analysis principles and tool-specific skills such as Google Analytics before learning a programming language, choosing Python over R for its versatility and larger community.[^e-a7dd1894ec] ^cac932b0

[^e-a7dd1894ec]: Time: `2023-05-29`; Sources: [locomo/thread_8e09fa96d2c5/msg_006e4345eb8a](../../sources/locomo/thread_8e09fa96d2c5.md#source-f86b62f3a861ffd3), [locomo/thread_8e09fa96d2c5/msg_209429f755d5](../../sources/locomo/thread_8e09fa96d2c5.md#source-b901c33c76a87237), [locomo/thread_8e09fa96d2c5/msg_36357bc96c67](../../sources/locomo/thread_8e09fa96d2c5.md#source-d0271dac8a46d0c4)

For learning Python for data analysis, the user plans to focus on Pandas and NumPy first as the foundation, then Matplotlib and Seaborn for data visualization, and finally Scikit-learn for machine learning and data modeling, and plans to practice with real-world datasets and join online communities.[^e-96b9dd719d] ^0513399c

[^e-96b9dd719d]: Time: `2023-05-29`; Sources: [locomo/thread_8e09fa96d2c5/msg_ac4bd357006a](../../sources/locomo/thread_8e09fa96d2c5.md#source-3d2b130bd769ed39)

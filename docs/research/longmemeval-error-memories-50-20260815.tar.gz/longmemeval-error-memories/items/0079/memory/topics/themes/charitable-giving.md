# Charitable Giving

The user is tracking their charity contributions for 2023 and raised $250 at the "Walk for Cancer" event plus contributed $120 individually at the "Bake Sale for Education" event, where their team's total contribution was $1,500, which was $1,380 more than the user's individual contribution; the two events together totaled $370 raised.[^e-0b0b03bb71] ^45baaaad

[^e-0b0b03bb71]: Time: `2023-05-28`; Sources: [locomo/thread_e85fb7a5fdaa/msg_89e527969c06](../../sources/locomo/thread_e85fb7a5fdaa.md#source-e961634308cd8289), [locomo/thread_e85fb7a5fdaa/msg_52606b108e25](../../sources/locomo/thread_e85fb7a5fdaa.md#source-acadb2bb2e107b34)

The user also raised $300 in cash donations at the "Food Drive" and $500 in donations at the "Polar Bear Plunge", bringing the total amount they raised this year to $1,170.[^e-ad6c968f63] ^9ca2f221

[^e-ad6c968f63]: Time: `2023-05-28`; Sources: [locomo/thread_e85fb7a5fdaa/msg_aeb41ccca1d7](../../sources/locomo/thread_e85fb7a5fdaa.md#source-07df541c8aa32e38), [locomo/thread_e85fb7a5fdaa/msg_a7d2f44e508f](../../sources/locomo/thread_e85fb7a5fdaa.md#source-39d19dd273e95721)

At the "Gala for the Homeless" the user did not raise funds but personally spent $600, including $500 on a painting at the live auction and $100 for the ticket, which brought their total charitable giving for the year (raised funds plus personal spending) to $1,770.[^e-ce0a29661a] ^e66dc711

[^e-ce0a29661a]: Time: `2023-05-28`; Sources: [locomo/thread_e85fb7a5fdaa/msg_aeb41ccca1d7](../../sources/locomo/thread_e85fb7a5fdaa.md#source-07df541c8aa32e38), [locomo/thread_e85fb7a5fdaa/msg_82036e3667b3](../../sources/locomo/thread_e85fb7a5fdaa.md#source-baa2ea07b4716887)

The user volunteers regularly at the "Animal Shelter" without raising funds there; their charitable giving by cause breaks down as Education $120 ("Bake Sale for Education"), Healthcare $250 ("Walk for Cancer"), Homelessness $600 ("Gala for the Homeless"), Food Security $300 ("Food Drive"), and Animal Welfare $0 (volunteer time only), while the "Polar Bear Plunge" funds were not categorized because the benefiting cause is unknown.[^e-430c348084] ^4fa3084a

[^e-430c348084]: Time: `2023-05-28`; Sources: [locomo/thread_e85fb7a5fdaa/msg_4187f392cc94](../../sources/locomo/thread_e85fb7a5fdaa.md#source-d2a895a6e2e41d0e)

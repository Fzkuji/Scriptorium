# Brother

The user's brother borrowed their duffel bag for a camping trip in April 2023 and has not returned it; since the user needs the bag for their own upcoming trip, they plan to send him a polite reminder before considering buying a new one.[^e-4bed659cab][^e-ec6cabccfe] ^614f5753 ^a1703547

[^e-4bed659cab]: Time: `2023-04`; Sources: [locomo/thread_d5369eec43f1/msg_6b55410d165d](../../sources/locomo/thread_d5369eec43f1.md#source-176b1f755c5f652d), [locomo/thread_d5369eec43f1/msg_bb0e66cb5673](../../sources/locomo/thread_d5369eec43f1.md#source-3803be6d5b358b37)

[^e-ec6cabccfe]: Time: `2023-04`; Sources: [locomo/thread_d5369eec43f1/msg_6b55410d165d](../../sources/locomo/thread_d5369eec43f1.md#source-176b1f755c5f652d), [locomo/thread_d5369eec43f1/msg_bb0e66cb5673](../../sources/locomo/thread_d5369eec43f1.md#source-3803be6d5b358b37)

The user lost their scarf during a work trip to Chicago and still hopes to recover it, planning to ask their brother to check his gear in case it got mixed up with the duffel bag or other belongings he accidentally took.[^e-0acc121f7e][^e-df61d536b2] ^cc9efd7c ^acc12b01

[^e-0acc121f7e]: Time: `undated`; Sources: [locomo/thread_d5369eec43f1/msg_4f71a4f51c09](../../sources/locomo/thread_d5369eec43f1.md#source-7e0df69b2f157915), [locomo/thread_d5369eec43f1/msg_0e41db8b9c79](../../sources/locomo/thread_d5369eec43f1.md#source-9e2d9b1d6254e860)

[^e-df61d536b2]: Time: `undated`; Sources: [locomo/thread_d5369eec43f1/msg_4f71a4f51c09](../../sources/locomo/thread_d5369eec43f1.md#source-7e0df69b2f157915), [locomo/thread_d5369eec43f1/msg_0e41db8b9c79](../../sources/locomo/thread_d5369eec43f1.md#source-9e2d9b1d6254e860)

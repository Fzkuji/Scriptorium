# Pharmacokinetics

The user asked for 30 detailed and diverse questions related to pharmacokinetic experimental tests for drug candidates, specifying that they should be specific about experimental measures such as clearance, volume of distribution at steady state (Vss), bioavailability (F), and area under the concentration-time curve to infinity (AUCinf); the generated questions also covered half-life (t1/2), Cmax, apparent volume of distribution (Vd), fraction absorbed (Fa), mean residence time (MRT), rate of metabolism, the role of transporters, plasma protein binding (fu), total versus intrinsic clearance, and the hepatic extraction ratio (Eh).[^e-f0fe89af47] ^f466c143

[^e-f0fe89af47]: Time: `2023-05-25`; Sources: [locomo/thread_ae05743e8c30/msg_b2d0ad460ac7](../../sources/locomo/thread_ae05743e8c30.md#source-aee41b66d1562ee0)

# TradingView

The user is interested in TradingView and asked how to connect it to their website, receiving instructions to embed the TradingView Widget by signing up for a free account, customizing a chart, selecting "Embed Chart", and pasting the embed code into their site's HTML.[^e-cc8b36a531] ^d4e771d0

[^e-cc8b36a531]: Time: `2023-05-22`; Sources: [locomo/thread_2722126b02ae/msg_7f3100be9a74](../../sources/locomo/thread_2722126b02ae.md#source-da4ff7e4d1994078), [locomo/thread_2722126b02ae/msg_2cbfa9477bda](../../sources/locomo/thread_2722126b02ae.md#source-8183ec589e3a2d6c)

The user asked whether they can add a transaction from a TradingView chart to their database, and the assistant explained that they can use TradingView's API, providing an example that posts transaction data via JavaScript (sendTransactionToServer) to a PHP script (add_transaction.php) that inserts records into a transactions table.[^e-2ab65d09d9] ^a98c47d4

[^e-2ab65d09d9]: Time: `2023-05-22`; Sources: [locomo/thread_2722126b02ae/msg_cd7648ea9f34](../../sources/locomo/thread_2722126b02ae.md#source-229df720b23033c6), [locomo/thread_2722126b02ae/msg_26110e745b22](../../sources/locomo/thread_2722126b02ae.md#source-9b15d14eb641406d)

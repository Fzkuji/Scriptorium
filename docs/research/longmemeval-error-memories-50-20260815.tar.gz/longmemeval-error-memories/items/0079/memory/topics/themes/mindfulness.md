# Mindfulness

The user attended a lecture series downtown where the speaker, Dr. Khan, talked about the importance of mindfulness in daily life, which sparked their interest in mindfulness exercises to reduce stress.[^e-dba2d61918] ^76fb0278

[^e-dba2d61918]: Time: `2023-05-22`; Sources: [locomo/thread_749fa3152137/msg_a642c1a18f3f](../../sources/locomo/thread_749fa3152137.md#source-4163a2571ab0f5e7), [locomo/thread_749fa3152137/msg_0913bf8fc1b5](../../sources/locomo/thread_749fa3152137.md#source-c0d518f692b45fef)

The user is particularly interested in mindful breathing and body scan meditation, and received recommendations for apps and online resources including Headspace, Calm, Insight Timer, Buddhify, Pocket Mindfulness, Mindful.org, and the UCLA Mindful Awareness Research Center.[^e-9e4700c2bf] ^ad2108b6

[^e-9e4700c2bf]: Time: `2023-05-22`; Sources: [locomo/thread_749fa3152137/msg_c88501022bd8](../../sources/locomo/thread_749fa3152137.md#source-a1367db7ea2ffd30), [locomo/thread_749fa3152137/msg_23dffebd3e42](../../sources/locomo/thread_749fa3152137.md#source-9f660e8d06a8519f)

The user plans to practice mindfulness during their daily bus commute with deep breathing or body scan meditation and to set aside 10 minutes each morning before starting their day, with the goal of making mindfulness a habit and not getting discouraged if they miss a day.[^e-8898ee2562] ^98be2d1f

[^e-8898ee2562]: Time: `2023-05-22`; Sources: [locomo/thread_749fa3152137/msg_a4c530391d7b](../../sources/locomo/thread_749fa3152137.md#source-8b1d6903462f2310), [locomo/thread_749fa3152137/msg_389fd8353426](../../sources/locomo/thread_749fa3152137.md#source-a4be88521ed7e3fe)

To handle distractions during practice, the user plans to anchor on breath and body sensations, put their phone on silent mode, and is exploring how to apply mindfulness to daily interactions and decision-making.[^e-a19444046c] ^2f1b52d6

[^e-a19444046c]: Time: `2023-05-22`; Sources: [locomo/thread_749fa3152137/msg_a0fdefbb25d7](../../sources/locomo/thread_749fa3152137.md#source-9305f94c7e7b42b2)

The user received tips for mindful interactions (practicing active listening, being present in conversations, using non-judgmental language, and practicing empathy) and for mindful decision-making (taking a pause, considering multiple perspectives, listening to intuition, and reflecting on personal values), plus suggestions to practice mindfulness in daily activities, use mindfulness reminders, and seek mindfulness in nature; the user plans to apply mindfulness by practicing active listening in daily conversations, especially with family and friends because they tend to get caught up in their own thoughts and opinions, bringing mindfulness into decision-making by taking a pause and considering multiple perspectives since they often feel rushed to decide, practicing mindfulness in daily activities such as eating and walking rather than doing them on autopilot, and exploring mindfulness in nature because they love spending time outdoors.[^e-5e9f676aba][^e-6d42307a6b] ^f5a9a1f3 ^37e53b7f

[^e-5e9f676aba]: Time: `2023-05-22`; Sources: [locomo/thread_749fa3152137/msg_16db1c60e078](../../sources/locomo/thread_749fa3152137.md#source-3a296cc6891580d1)

[^e-6d42307a6b]: Time: `2023-05-22`; Sources: [locomo/thread_749fa3152137/msg_4d533b6188b6](../../sources/locomo/thread_749fa3152137.md#source-2261945359ac6c8b)

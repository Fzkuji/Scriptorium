# Anxiety and Cognitive Distortions

The user struggles with anxiety, reporting that cognitive distortions are frustrating because they feel like they take over their thoughts and make them worry about everything; they learned about ten cognitive distortions that contribute to anxiety: catastrophizing, all-or-nothing thinking, overgeneralizing, personalization, mind-reading, discounting the positive, emotional reasoning, filtering, should statements, and labeling and mislabeling.[^e-f477d557ea] ^4c0fb716

[^e-f477d557ea]: Time: `2023-05-27`; Sources: [locomo/thread_e75d517f7f0b/msg_73995c263c38](../../sources/locomo/thread_e75d517f7f0b.md#source-bcee965ff0e9b62f), [locomo/thread_e75d517f7f0b/msg_aff28aa33f74](../../sources/locomo/thread_e75d517f7f0b.md#source-2c5ce1b700b7181f), [locomo/thread_e75d517f7f0b/msg_41763b316ad9](../../sources/locomo/thread_e75d517f7f0b.md#source-533ea0adaaf36351)

To mitigate cognitive distortions and manage anxiety, the user received strategies including identifying and challenging cognitive distortions, practicing mindfulness, using positive self-talk, setting realistic expectations, seeking support from a trusted friend, family member, or mental health professional, practicing self-care, journaling, exercising, cognitive-behavioral therapy (CBT), and distraction techniques.[^e-b81f5cb321] ^e43f7faa

[^e-b81f5cb321]: Time: `2023-05-27`; Sources: [locomo/thread_e75d517f7f0b/msg_efd0b3353a1b](../../sources/locomo/thread_e75d517f7f0b.md#source-d236240bb6615423), [locomo/thread_e75d517f7f0b/msg_626a414f6b0e](../../sources/locomo/thread_e75d517f7f0b.md#source-df722706ceb2b8cf), [locomo/thread_e75d517f7f0b/msg_4744d368af05](../../sources/locomo/thread_e75d517f7f0b.md#source-3ae314f8ce9b42d4)

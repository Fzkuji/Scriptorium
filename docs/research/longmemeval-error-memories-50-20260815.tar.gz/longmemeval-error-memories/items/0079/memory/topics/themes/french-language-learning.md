# French Language Learning

The user is learning French and plans to use their weekday morning free time to do so, since they wake up at 6:30 am and have free time around 6:45 am after breakfast before their daily responsibilities; they chose to use Duolingo for its gamified French course, intend to set a daily goal and focus on understanding the material, and plan to supplement it with other resources.[^e-881a054018] ^6012c368

[^e-881a054018]: Time: `2023-05-22`; Sources: [locomo/thread_046276ceb02b/msg_20610c3cfbd0](../../sources/locomo/thread_046276ceb02b.md#source-bfb012a87e2319f9), [locomo/thread_046276ceb02b/msg_07f43e3f2ff4](../../sources/locomo/thread_046276ceb02b.md#source-35efa00fe81f235c), [locomo/thread_046276ceb02b/msg_817878b93de4](../../sources/locomo/thread_046276ceb02b.md#source-2d741f259a00a35d)

The user is taking a French language course at Sorbonne University to improve their language skills, which has been helpful for navigating everyday situations in [Paris](living-in-paris.md#^c0272a2e); they have started to understand some French TV shows and movies and have had funny moments such as accidentally using the wrong verb conjugation in a conversation and confusing their French friend.[^e-c31a7e7101] ^e00a1b58

[^e-c31a7e7101]: Time: `2023-05-22`; Sources: [locomo/thread_14f6bc69bb92/msg_ad9ff0d6af6b](../../sources/locomo/thread_14f6bc69bb92.md#source-dc9853581dd70d00), [locomo/thread_14f6bc69bb92/msg_ef96b87b06ca](../../sources/locomo/thread_14f6bc69bb92.md#source-61e9c221291303e7)

The user is thinking of starting a language exchange with a native French speaker and received tips on how to make the most of it, including defining goals, choosing a platform, setting a schedule, preparing topics, using video calls, recording conversations, and correcting each other.[^e-2114e2975e] ^b51f0aae

[^e-2114e2975e]: Time: `2023-05-22`; Sources: [locomo/thread_046276ceb02b/msg_7940ea7fea7c](../../sources/locomo/thread_046276ceb02b.md#source-aaceada76ff8beba), [locomo/thread_046276ceb02b/msg_7e9ce10ee2d8](../../sources/locomo/thread_046276ceb02b.md#source-a7b4f517fe8d8165)

The user received recommendations for beginner French resources including podcasts (French Pod 101, Coffee Break French, News in Slow French), YouTube channels (French with Lucy, French for Beginners, French with Alexa), apps and platforms (Duolingo, Babbel, Anki, Memrise, Quizlet, French.org), and language exchange sites (italki, Conversation Exchange, Tandem).[^e-c1f8399a10] ^74e9321e

[^e-c1f8399a10]: Time: `2023-05-22`; Sources: [locomo/thread_046276ceb02b/msg_b0cb1f83cf72](../../sources/locomo/thread_046276ceb02b.md#source-6da09263999e405b), [locomo/thread_046276ceb02b/msg_d1e1e628164b](../../sources/locomo/thread_046276ceb02b.md#source-8ab6bae49c1141ca)

# Footwear

The user is shopping for new hiking boots and received recommendations including Merrell Moab 2 Mid Waterproof, Keen Targhee II Mid WP, Salomon Quest 4D 3 GTX, The North Face Hedgehog Fastpack GTX, and Danner Mountain 600.[^e-50cdf54945] ^1cbb9063

[^e-50cdf54945]: Time: `2023-05-21`; Sources: [locomo/thread_f4407b5e69a3/msg_b7e48307cffc](../../sources/locomo/thread_f4407b5e69a3.md#source-feeae438fd5ea0c5), [locomo/thread_f4407b5e69a3/msg_2058bf23b233](../../sources/locomo/thread_f4407b5e69a3.md#source-088648957dfc986e)

Because the user had wet feet on their last hike, they wanted a waterproof boot and, after comparing Gore-Tex and eVent membranes, decided to go with a Gore-Tex boot.[^e-3e1ccce511] ^a6090392

[^e-3e1ccce511]: Time: `2023-05-21`; Sources: [locomo/thread_f4407b5e69a3/msg_4c55976ef78e](../../sources/locomo/thread_f4407b5e69a3.md#source-5c9eed9aa4fa74fa), [locomo/thread_f4407b5e69a3/msg_ded698426bc5](../../sources/locomo/thread_f4407b5e69a3.md#source-2c7699314ff45c3c), [locomo/thread_f4407b5e69a3/msg_255d528a32f4](../../sources/locomo/thread_f4407b5e69a3.md#source-32adf334dc723fa7)

The user spilled coffee on their brown loafers the previous week and received step-by-step advice for removing the stain from the leather, including blotting rather than wiping, applying a gentle leather cleaner or a mixture of equal parts water and white vinegar, letting it sit for 10-15 minutes, and conditioning the leather afterward.[^e-88f06a567d] ^9cd3947c

[^e-88f06a567d]: Time: `2023-05-21`; Sources: [locomo/thread_f4407b5e69a3/msg_b7e48307cffc](../../sources/locomo/thread_f4407b5e69a3.md#source-feeae438fd5ea0c5), [locomo/thread_f4407b5e69a3/msg_255d528a32f4](../../sources/locomo/thread_f4407b5e69a3.md#source-32adf334dc723fa7), [locomo/thread_f4407b5e69a3/msg_c0fc02ca5cef](../../sources/locomo/thread_f4407b5e69a3.md#source-7e2af5d7563f4b8e)

The user got rid of their old white sneakers that caused blisters and is in the market for new comfortable, supportive sneakers, considering options such as ASICS Gel-Kayano 27, New Balance 574, Brooks Ghost 13, Hoka One One Bondi 7, and Clarks Cloud Steppers.[^e-1c854e9132] ^36266a2e

[^e-1c854e9132]: Time: `2023-05-21`; Sources: [locomo/thread_f4407b5e69a3/msg_e1bb2f87354c](../../sources/locomo/thread_f4407b5e69a3.md#source-11958cf40bbc4e48), [locomo/thread_f4407b5e69a3/msg_174bc3f22d46](../../sources/locomo/thread_f4407b5e69a3.md#source-e5390bbc74e21171)

The user wants a shoe rack to organize shoes that are lying around their closet and, because their closet space is limited, decided on a simple, compact rack that holds around 6-8 pairs.[^e-6a807af7b5] ^6ec9ca05

[^e-6a807af7b5]: Time: `2023-05-21`; Sources: [locomo/thread_f4407b5e69a3/msg_98493d57f0de](../../sources/locomo/thread_f4407b5e69a3.md#source-30df1c1628335d2d), [locomo/thread_f4407b5e69a3/msg_af2ba6f017d5](../../sources/locomo/thread_f4407b5e69a3.md#source-f29da36a5425b668), [locomo/thread_f4407b5e69a3/msg_3c6f6cbb4613](../../sources/locomo/thread_f4407b5e69a3.md#source-f0f7d5b0d1420a9b), [locomo/thread_f4407b5e69a3/msg_09e2e3ff715f](../../sources/locomo/thread_f4407b5e69a3.md#source-c08f618f0eac3e4b)

# Agile Methodologies and Project Management

The user is learning about Agile methodologies and asked for recommendations on books and online resources to learn more about it.[^e-a3704b2d3d] ^b0205f5c

[^e-a3704b2d3d]: Time: `2023-05-23`; Sources: [locomo/thread_100ba0195b99/msg_ebd760f46e80](../../sources/locomo/thread_100ba0195b99.md#source-b010eae73e629d10)

The user recently attended a project management workshop that they found really helpful, and it was at this workshop that they met [Sophia](../people/sophia.md#^1b2dfb3d).[^e-a44508e030] ^a2a9e24a

[^e-a44508e030]: Time: `2023-05`; Sources: [locomo/thread_100ba0195b99/msg_ebd760f46e80](../../sources/locomo/thread_100ba0195b99.md#source-b010eae73e629d10), [locomo/thread_100ba0195b99/msg_8bc4719b42a4](../../sources/locomo/thread_100ba0195b99.md#source-d8856c22efaf2852)

The user received Agile resource recommendations including books (Agile Project Management with Scrum by Ken Schwaber, The Agile Manifesto, Lean Software Development by Mary and Tom Poppendieck, User Stories Applied by Mike Cohn, Agile Estimating and Planning by Mike Cohn) and online resources (Agile Alliance, Scrum.org, Atlassian's Agile methodology guide, Coursera, edX, The Agile Coach, Mountain Goat Software).[^e-1d68ffa42a] ^11eb750c

[^e-1d68ffa42a]: Time: `2023-05-23`; Sources: [locomo/thread_100ba0195b99/msg_02c5ba44b74d](../../sources/locomo/thread_100ba0195b99.md#source-c9c32833b3daf545)

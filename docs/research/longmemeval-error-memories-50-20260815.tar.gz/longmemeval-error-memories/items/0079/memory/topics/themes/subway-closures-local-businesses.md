# Subway Closures and Local Businesses

The user has noticed a lot of subway closures in their area lately, which has made getting around a real pain, and they feel bad for the local businesses affected.[^e-3b72adec97] ^c15b1f2a

[^e-3b72adec97]: Time: `2023-05-22`; Sources: [locomo/thread_3dfeec2de60c/msg_1ad73b6abe91](../../sources/locomo/thread_3dfeec2de60c.md#source-8b203e1d58e7608f)

The user learned that subway closures can significantly impact local businesses by reducing foot traffic and sales, increasing traffic and congestion on nearby streets, disrupting supply chains, and preventing employees from getting to work, with the impact varying depending on the length of the closure, the location of the business, and the availability of alternative transportation options.[^e-dca1c45ced] ^0d6736f4

[^e-dca1c45ced]: Time: `2023-05-22`; Sources: [locomo/thread_3dfeec2de60c/msg_8c4ecc50b41f](../../sources/locomo/thread_3dfeec2de60c.md#source-7de3472b38635a32), [locomo/thread_3dfeec2de60c/msg_8cbccfab2e7d](../../sources/locomo/thread_3dfeec2de60c.md#source-24c11bfebfd1e070)

The user wants to support local businesses that have been hit hard by the subway closures and was advised to look for information on local news websites, social media groups, or local business associations and chambers of commerce, or to reach out to favorite local businesses directly, many of which are adapting by offering alternative services such as delivery or curbside pickup.[^e-e29d755b6c] ^bb894a17

[^e-e29d755b6c]: Time: `2023-05-22`; Sources: [locomo/thread_3dfeec2de60c/msg_2ec661761e54](../../sources/locomo/thread_3dfeec2de60c.md#source-69f1c27a63f1799a), [locomo/thread_3dfeec2de60c/msg_0fe8f24c2d9a](../../sources/locomo/thread_3dfeec2de60c.md#source-043939b24c54e2b6)

During the subway closures, the user has been supporting local businesses by ordering takeout from their favorite restaurants and buying gifts from local shops, which they describe as doing their part to help out.[^e-b38cc32f5d] ^6c602ded

[^e-b38cc32f5d]: Time: `2023-05-22`; Sources: [locomo/thread_3dfeec2de60c/msg_700c3abe7a3c](../../sources/locomo/thread_3dfeec2de60c.md#source-6211eb4f9f499a3f)

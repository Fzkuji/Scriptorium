# Yoga Practice

The user attends an evening yoga class and planned a Tuesday schedule around it that fitted in work meetings, a report due by the end of the week, and making a grocery list and doing online shopping for the healthy ingredients in their new meal plan.[^e-2bac161d5b][^e-f1f023f69c] ^6ebebb24

[^e-2bac161d5b]: Time: `2023-05-24`; Sources: [locomo/thread_6e5fb66a8677/msg_88ea2a72357e](../../sources/locomo/thread_6e5fb66a8677.md#source-3ab9d49353290d8d)

[^e-f1f023f69c]: Time: `2023-05-24`; Sources: [locomo/thread_6e5fb66a8677/msg_32636dae5f43](../../sources/locomo/thread_6e5fb66a8677.md#source-e7566968c2f5e575)

The user asked about advanced yoga poses targeting the lower back and received a list including Dancer Pose (Natarajasana), Camel Pose (Ustrasana), Bow Pose (Dhanurasana), Upward-Facing Dog Pose, Feathered Peacock Pose (Pincha Mayurasana), Locust Pose (Salabhasana), Bridge Pose (Setu Bandha Sarvangasana), One-Legged King Pigeon Pose (Eka Pada Rajakapotasana), Wheel Pose (Urdhva Dhanurasana), and Half Moon Pose (Ardha Chandrasana), which should only be attempted under the guidance of a qualified yoga teacher; to prevent lower back pain they received tips to warm up, maintain proper alignment, use props like blocks, blankets or straps, engage the core, and listen to the body, and they plan to try them under a teacher's guidance while focusing on their breath to stay relaxed and in the right mindset.[^e-dddf02e6ae] ^892dfb0a

[^e-dddf02e6ae]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_0225eb431b77](../../sources/locomo/thread_023f8650f638.md#source-0e82838c5d4f1111), [locomo/thread_023f8650f638/msg_613063c05176](../../sources/locomo/thread_023f8650f638.md#source-8aa9ce3799ac6617), [locomo/thread_023f8650f638/msg_5cc39f69fb27](../../sources/locomo/thread_023f8650f638.md#source-065a44001a08aed1), [locomo/thread_023f8650f638/msg_3b70bbd36584](../../sources/locomo/thread_023f8650f638.md#source-dad9a5a3986522b1), [locomo/thread_023f8650f638/msg_5ba654acec46](../../sources/locomo/thread_023f8650f638.md#source-0865d6d678ff0fc8)

The user is incorporating pranayama breath exercises into their advanced yoga practice and received recommendations for Ujjayi Pranayama (Victorious Breath), Bhastrika Pranayama (Bellows Breath), Kapalbhati Pranayama (Skull-Shining Breath), and Anulom Vilom Pranayama (Alternate Nostril Breathing) to regulate the breath, keep focus, and maintain a sense of calm during practice.[^e-945a3d5798] ^f0b93a20

[^e-945a3d5798]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_a9671522ba60](../../sources/locomo/thread_023f8650f638.md#source-f33656c2882b1afc)

To strengthen and stretch the lower back, the user also received a list of poses including Child's Pose (Balasana), Cat-Cow (Marjaryasana-Bitilasana), Cobra Pose (Bhujangasana), Sphinx Pose (Salamba Bhujangasana), Extended Triangle Pose (Utthita Trikonasana), Standing Forward Bend (Uttanasana), Wide-Angle Seated Forward Bend (Upavistha Konasana), Plank Pose (Phalakasana), Boat Pose (Navasana), and Happy Baby Pose (Ananda Balasana), which also help build a strong core and flexible hamstrings and help prevent lower back pain in the long run.[^e-dfe3a2ffce] ^b8012739

[^e-dfe3a2ffce]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_9047da955f77](../../sources/locomo/thread_023f8650f638.md#source-9e2b4f93be89a747)

For cooling down after an intense yoga session, the user received recommendations including Seated Forward Bend (Paschimottanasana), Reclining Bound Angle Pose (Supta Baddha Konasana), Supported Shoulder Stand (Salamba Sarvangasana), Legs Up the Wall Pose (Viparita Karani), and Supine Spinal Twist (Supta Matsyendrasana), as well as restorative Yoga Nidra and cooling pranayama techniques like Brahmari and Shitali.[^e-b57fdb75af] ^708ee9f5

[^e-b57fdb75af]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_867cb72ce67f](../../sources/locomo/thread_023f8650f638.md#source-6f0374c5705f90aa)

The user received a sample yoga routine to use or modify: warm up with Cat-Cow, Child's Pose, and Sun Salutations; focus on strengthening the lower back with Plank, Boat, and Cobra Poses; incorporate advanced poses like Dancer, King Pigeon, or Wheel after warming up; cool down with Seated Forward Bend, Reclining Bound Angle, and Legs Up the Wall; and end with pranayama and meditation, with the assistant advising them to listen to their body, modify poses as needed, and not do every pose every time.[^e-2e8838a526] ^67643398

[^e-2e8838a526]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_b2bed7b0b88e](../../sources/locomo/thread_023f8650f638.md#source-8da43f2995b7895f)

# Faith and Devotions

The user is a Christian who attends a Bible study group and pursues daily devotions, and asked for Bible verses and prayers on perseverance and faith such as Romans 5:3-4, Hebrews 12:1-3, James 1:2-4, Philippians 4:13, and Isaiah 40:31.[^e-e68d627327] ^540792e1

[^e-e68d627327]: Time: `2023-05-20`; Sources: [locomo/thread_89990fbd2a44/msg_5cd5a2ad8e2b](../../sources/locomo/thread_89990fbd2a44.md#source-8afa5fca0ed4563c)

The user reported struggling with anxiety and requested Bible verses and prayers for coping and peace, such as Philippians 4:6-7, Psalm 23:4, Matthew 6:25-34, Isaiah 41:10, and 1 Peter 5:7.[^e-bd0678019f] ^fc7620d5

[^e-bd0678019f]: Time: `2023-05-20`; Sources: [locomo/thread_89990fbd2a44/msg_60d42eed8af3](../../sources/locomo/thread_89990fbd2a44.md#source-2f8e893742cda70b)

The user wants to establish a daily prayer routine and asked for devotional and prayer-guide recommendations, including Our Daily Bread, Jesus Calling, My Utmost for His Highest, The Upper Room, The Prayer of Jabez, The Power of Prayer, Prayer: Does It Make Any Difference?, The Valley of Vision, YouVersion, Pray As You Go, Lectio 365, and The Gospel Coalition.[^e-88a87447e9] ^69cb04d2

[^e-88a87447e9]: Time: `2023-05-20`; Sources: [locomo/thread_89990fbd2a44/msg_b3517ad19c5d](../../sources/locomo/thread_89990fbd2a44.md#source-da2e7c5bc0b1f7b8)

The user is interested in exploring the rosary and incorporating it into their daily prayer routine, and asked about the differences between the Dominican (five-decade) and Franciscan (seven-decade) rosaries as well as other types such as the Servite and Brigittine rosaries and the Chaplet of Divine Mercy.[^e-f76d3f2600] ^fe372ab8

[^e-f76d3f2600]: Time: `2023-05-20`; Sources: [locomo/thread_89990fbd2a44/msg_d90145e59a64](../../sources/locomo/thread_89990fbd2a44.md#source-699dfa7bcc1303bb), [locomo/thread_89990fbd2a44/msg_4f1e3c6d09ca](../../sources/locomo/thread_89990fbd2a44.md#source-8be5b16d73a5f30f)

# Greek-Mexican Fusion Food Truck

The user is planning to start a food truck serving elevated Greek cuisine with Mexican influences.[^e-2b21e8bff9] ^2c7f6359

[^e-2b21e8bff9]: Time: `2023-05-21`; Sources: [locomo/thread_cbcd98836154/msg_4efa0dd0ad5d](../../sources/locomo/thread_cbcd98836154.md#source-d36bc6e70ac12196)

The sample menu developed for the food truck includes Gyro Tacos, Greek Quesadilla, Falafel Burrito, Greek Street Corn, Lamb Souvlaki Wrap, Taco Pita, Greek Nachos, Mexican Greek Salad, Spanakopita Quesadilla, and Baklava Churros; the user requested the menu be formatted in reStructuredText with each item in its own section showing the price to charge and a table of ingredient costs, yielding sample prices and costs of Gyro Tacos $8/$2.50, Greek Quesadilla $9/$3.25, Falafel Burrito $10/$2.75, Greek Street Corn $5/$1.25, Lamb Souvlaki Wrap $8/$3.50, Taco Pita $9/$2.75, Greek Nachos $10/$2.75, Mexican Greek Salad $7/$2.25, Spanakopita Quesadilla $8/$2.75, and Baklava Churros $6/$1.50, which the assistant noted were examples to adjust; the user also asked for a fun, catchy name for each menu item, and the assistant assigned Greek on the Streets (Gyro Tacos), Feta-tilla (Greek Quesadilla), Falafelito (Falafel Burrito), Athena's Corn (Greek Street Corn), Zeus Wrap (Lamb Souvlaki Wrap), Tzatz-Taco (Taco Pita), Opa! Nachos (Greek Nachos), Med Mex Salad (Mexican Greek Salad), Spinachita Quesadilla (Spanakopita Quesadilla), and Baklavachurros (Baklava Churros).[^e-a191fcc143][^e-1568c3dc01][^e-e27115bec5] ^92453d7c ^12bc462c ^c294c113

[^e-a191fcc143]: Time: `2023-05-21`; Sources: [locomo/thread_cbcd98836154/msg_2d18edec6f57](../../sources/locomo/thread_cbcd98836154.md#source-b9dbd1b1a5991c86)

[^e-1568c3dc01]: Time: `2023-05-21`; Sources: [locomo/thread_cbcd98836154/msg_8efa0e8abaf5](../../sources/locomo/thread_cbcd98836154.md#source-ecffe79b3060cdbc), [locomo/thread_cbcd98836154/msg_29393081c7e7](../../sources/locomo/thread_cbcd98836154.md#source-7de7107bc71c3ebf)

[^e-e27115bec5]: Time: `2023-05-21`; Sources: [locomo/thread_cbcd98836154/msg_ff7fe86bebe6](../../sources/locomo/thread_cbcd98836154.md#source-cccac808cfb93f55), [locomo/thread_cbcd98836154/msg_bd76b0f85aac](../../sources/locomo/thread_cbcd98836154.md#source-19debe86690ff426)

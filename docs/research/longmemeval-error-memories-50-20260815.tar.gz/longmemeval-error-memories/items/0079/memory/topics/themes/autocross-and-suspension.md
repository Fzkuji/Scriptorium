# Autocross and Suspension

The user is an autocross enthusiast who attends auto racking events and drives a car that had a slight misfire during their daily commute; after replacing the spark plugs with new NGK ones, the engine became smoother and more responsive.[^e-ce1de3cff0] ^20c481c0

[^e-ce1de3cff0]: Time: `2023-05`; Sources: [locomo/thread_5c188c1c98ea/msg_c93b211f719c](../../sources/locomo/thread_5c188c1c98ea.md#source-ad7ffc82fccaa51c)

The user is fine-tuning their car's suspension for autocross and is evaluating coilover options, having heard good things about KW Suspension and Öhlins and expressing interest in JRZ coilovers for their smooth street ride and strong track handling.[^e-8a36a7ac88] ^0af74201

[^e-8a36a7ac88]: Time: `2023-05-20`; Sources: [locomo/thread_5c188c1c98ea/msg_e472f07af1c8](../../sources/locomo/thread_5c188c1c98ea.md#source-bba1eb4010ba78ae), [locomo/thread_5c188c1c98ea/msg_7e381a129fb8](../../sources/locomo/thread_5c188c1c98ea.md#source-b7c2e043c35761cf), [locomo/thread_5c188c1c98ea/msg_2857d8f8371a](../../sources/locomo/thread_5c188c1c98ea.md#source-869e410aa1a04c70)

The user reported that their car's handling can be unpredictable during high-speed turns at autocross events and sought JRZ technologies to improve stability and handling, discussing digressive damping, rebound control, dual-speed compression, the Stabilization System (SAS), custom spring rates, and custom valving.[^e-5bb80681d4] ^b1fefffc

[^e-5bb80681d4]: Time: `2023-05-20`; Sources: [locomo/thread_5c188c1c98ea/msg_f1a20a57751d](../../sources/locomo/thread_5c188c1c98ea.md#source-5b89f5c0f4cf64e8), [locomo/thread_5c188c1c98ea/msg_936750b91ac8](../../sources/locomo/thread_5c188c1c98ea.md#source-15a56a29778d86d3), [locomo/thread_5c188c1c98ea/msg_13b976815fc9](../../sources/locomo/thread_5c188c1c98ea.md#source-92d4ba3b7e9fef20), [locomo/thread_5c188c1c98ea/msg_29d274d997d0](../../sources/locomo/thread_5c188c1c98ea.md#source-0bfef0fc57c608ad)

JRZ offers coilover lines such as the RS, RS Pro, and 2-way, which are highly adjustable, built to order with lead times of several weeks or months, and tailored through custom spring rates and valving.[^e-21ee97ffe8] ^34c0af24

[^e-21ee97ffe8]: Time: `2023-05-20`; Sources: [locomo/thread_5c188c1c98ea/msg_345c325e19c4](../../sources/locomo/thread_5c188c1c98ea.md#source-fee814e703d95b15), [locomo/thread_5c188c1c98ea/msg_936750b91ac8](../../sources/locomo/thread_5c188c1c98ea.md#source-15a56a29778d86d3)

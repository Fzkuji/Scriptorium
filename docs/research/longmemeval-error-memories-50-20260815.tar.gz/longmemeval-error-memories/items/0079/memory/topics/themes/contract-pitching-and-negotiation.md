# Contract Work Pitching and Negotiation

The user asked about common mistakes contract workers make when pitching themselves to potential clients and received advice to avoid five pitfalls: lack of preparation (research the client's needs and tailor the pitch), focusing too much on yourself (center the pitch on the client's needs with concrete examples and success stories), lack of clarity and specificity, over-promising and under-delivering, and failing to follow up after a pitch.[^e-8cc72e2ad8] ^84ba86b7

[^e-8cc72e2ad8]: Time: `2023-05-29`; Sources: [locomo/thread_3521d895e8f1/msg_1e432e7b3717](../../sources/locomo/thread_3521d895e8f1.md#source-824441a91d87faf5), [locomo/thread_3521d895e8f1/msg_2468bcfaa96e](../../sources/locomo/thread_3521d895e8f1.md#source-89a9126efd6e19bd)

The user received tips to make their pitch stand out from the competition: open with a compelling hook, personalize the pitch to the client's specific needs and goals, show their unique value proposition, use storytelling with concrete examples and success stories, be confident but humble and a good listener, and finish with a clear call-to-action.[^e-20cf54e5e0] ^13a693eb

[^e-20cf54e5e0]: Time: `2023-05-29`; Sources: [locomo/thread_3521d895e8f1/msg_62b1787f9bf5](../../sources/locomo/thread_3521d895e8f1.md#source-df080d74e0cb38db), [locomo/thread_3521d895e8f1/msg_7e58c436d4aa](../../sources/locomo/thread_3521d895e8f1.md#source-f8cb99d5475f1270)

The user gets anxious during pitches and it affects their performance, so they received tips for managing nervousness: practice the pitch in front of a mirror or with friends, get comfortable with the surroundings by arriving early, breathe and center yourself, be well prepared, focus on the client and their needs rather than yourself, make eye contact, and use positive self-talk.[^e-454ce02f0b] ^65dfbe32

[^e-454ce02f0b]: Time: `2023-05-29`; Sources: [locomo/thread_3521d895e8f1/msg_4858343ec15f](../../sources/locomo/thread_3521d895e8f1.md#source-de08df2cc5b1d139), [locomo/thread_3521d895e8f1/msg_bf9a804977e3](../../sources/locomo/thread_3521d895e8f1.md#source-a60137857be27839)

The user worried about appearing incompetent if a client asks a question they do not know the answer to, and received advice to stay calm, take time to understand the question, be honest, show expertise by explaining how they would go about finding the answer, and commit to researching and following up with the client.[^e-396b3199a1] ^fce2162e

[^e-396b3199a1]: Time: `2023-05-29`; Sources: [locomo/thread_3521d895e8f1/msg_9c13ba260a15](../../sources/locomo/thread_3521d895e8f1.md#source-3d970793af66ce47), [locomo/thread_3521d895e8f1/msg_09274b6cbe42](../../sources/locomo/thread_3521d895e8f1.md#source-44d7c740a7aec865)

The user asked how to negotiate rates with potential clients without coming across as too pushy or desperate and received advice to research industry rates, understand the client's needs and financial situation, start with a higher rate, be flexible with alternatives like a lower rate for a longer timeframe or bundling services, highlight the value they bring, stay professional, and be willing to walk away rather than accept a rate too low for their services.[^e-282125b580] ^3317460c

[^e-282125b580]: Time: `2023-05-29`; Sources: [locomo/thread_3521d895e8f1/msg_880ed7581f47](../../sources/locomo/thread_3521d895e8f1.md#source-5f335901447f8e6d), [locomo/thread_3521d895e8f1/msg_ee0a4f8bf53b](../../sources/locomo/thread_3521d895e8f1.md#source-013a6aa6d7f71201)

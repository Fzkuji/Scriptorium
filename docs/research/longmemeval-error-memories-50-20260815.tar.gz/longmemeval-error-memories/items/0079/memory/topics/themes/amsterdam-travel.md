# Amsterdam Trip

The user is planning a trip to Amsterdam next weekend, choosing to travel by Thalys train from [Paris](living-in-paris.md#^c0272a2e) Gare du Nord to Amsterdam Centraal.[^e-1dc0db4c1f] ^03b06c14

[^e-1dc0db4c1f]: Time: `2023-05-22`; Sources: [locomo/thread_14f6bc69bb92/msg_85e2fa90cef9](../../sources/locomo/thread_14f6bc69bb92.md#source-907542218edfbb75), [locomo/thread_14f6bc69bb92/msg_de76b3f4fb6e](../../sources/locomo/thread_14f6bc69bb92.md#source-95cfdf1a5cf12c25)

For their Amsterdam trip, the user chose the Flying Pig Downtown Hostel as budget-friendly accommodation and is interested in visiting the Jordaan neighborhood, the Van Gogh Museum, the Anne Frank House, and the Rijksmuseum, and in trying stamppot; they also intend to learn some basic Dutch phrases before the trip.[^e-059655dbff] ^1cbea338

[^e-059655dbff]: Time: `2023-05-22`; Sources: [locomo/thread_14f6bc69bb92/msg_ad9ff0d6af6b](../../sources/locomo/thread_14f6bc69bb92.md#source-dc9853581dd70d00), [locomo/thread_14f6bc69bb92/msg_ef96b87b06ca](../../sources/locomo/thread_14f6bc69bb92.md#source-61e9c221291303e7), [locomo/thread_14f6bc69bb92/msg_40249297a064](../../sources/locomo/thread_14f6bc69bb92.md#source-1001eb0c5d07d83e)

The user received recommendations for their Amsterdam itinerary including must-see attractions (Anne Frank House, Rijksmuseum, Van Gogh Museum) and hidden gems such as the Jordaan neighborhood, Vondelpark, Foodhallen, Noordermarkt, Prinsengracht, and Brouwerij 't IJ, plus tips to buy an Amsterdam Canal Ring ticket, rent a bike, and try stamppot.[^e-008fafdbfb] ^be64ec7e

[^e-008fafdbfb]: Time: `2023-05-22`; Sources: [locomo/thread_14f6bc69bb92/msg_c25e169a6400](../../sources/locomo/thread_14f6bc69bb92.md#source-b29bbea4935ba2ef)

For cooking on a budget in Amsterdam, the user asked for affordable Dutch recipes to make in a hostel kitchen and received suggestions including erwtensoep (Dutch pea soup), poffertjes (mini pancakes), hutspot (mashed potatoes with vegetables and sausage), and oliebollen (deep-fried dough balls), plus a simple erwtensoep recipe.[^e-5a5c3dd75f] ^33ad80e2

[^e-5a5c3dd75f]: Time: `2023-05-22`; Sources: [locomo/thread_14f6bc69bb92/msg_40249297a064](../../sources/locomo/thread_14f6bc69bb92.md#source-1001eb0c5d07d83e), [locomo/thread_14f6bc69bb92/msg_fd64403b158e](../../sources/locomo/thread_14f6bc69bb92.md#source-795653ee13b5d88e)

The user has no dietary restrictions and is a big fan of trying new foods and drinks, preferring the more authentic and traditional the better, which applies to their plans to make Dutch recipes like erwtensoep or poffertjes while in Amsterdam.[^e-dd4684f17f] ^3a789a33

[^e-dd4684f17f]: Time: `2023-05-22`; Sources: [locomo/thread_14f6bc69bb92/msg_5a0b4cc9e66e](../../sources/locomo/thread_14f6bc69bb92.md#source-4a29a65ca2f337dd)

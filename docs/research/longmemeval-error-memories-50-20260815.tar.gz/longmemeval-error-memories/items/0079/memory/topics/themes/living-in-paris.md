# Living in Paris

The user has been living in Paris for three months and is still getting used to the city.[^e-36dd6691fc] ^c0272a2e

[^e-36dd6691fc]: Time: `2023-05-22`; Sources: [locomo/thread_14f6bc69bb92/msg_85e2fa90cef9](../../sources/locomo/thread_14f6bc69bb92.md#source-907542218edfbb75)

To save money and eat healthy while living in Paris on a student budget, the user has been cooking their own meals.[^e-cd3d58bc2f][^e-e6a705fea2] ^e7116e5a ^2a2217c8

[^e-cd3d58bc2f]: Time: `2023-05-22`; Sources: [locomo/thread_14f6bc69bb92/msg_40249297a064](../../sources/locomo/thread_14f6bc69bb92.md#source-1001eb0c5d07d83e)

[^e-e6a705fea2]: Time: `2023-05-22`; Sources: [locomo/thread_14f6bc69bb92/msg_de76b3f4fb6e](../../sources/locomo/thread_14f6bc69bb92.md#source-95cfdf1a5cf12c25)

The user has been trying to try more French cuisine since arriving in Paris and recently tried escargots for the first time, being surprised by how much they enjoyed them.[^e-f43457bcea][^e-13b5dc48b8] ^0c7dc0e4 ^3eb9977a

[^e-f43457bcea]: Time: `2023-05-22`; Sources: [locomo/thread_14f6bc69bb92/msg_5a0b4cc9e66e](../../sources/locomo/thread_14f6bc69bb92.md#source-4a29a65ca2f337dd)

[^e-13b5dc48b8]: Time: `2023-05`; Sources: [locomo/thread_14f6bc69bb92/msg_5a0b4cc9e66e](../../sources/locomo/thread_14f6bc69bb92.md#source-4a29a65ca2f337dd)

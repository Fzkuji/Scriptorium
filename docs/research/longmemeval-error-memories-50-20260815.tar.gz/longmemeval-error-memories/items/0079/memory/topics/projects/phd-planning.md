# PhD Planning

The user completed their master's program in six months, from November 2022 to May 2023, and passed their comprehensive exam on February 20th, 2023; they attended a study group that started in December 2022 and continued until January 2023 to prepare for the exam.[^e-77e49f144c] ^f6b708d2

[^e-77e49f144c]: Time: `2023-05`; Sources: [locomo/thread_7ad370356362/msg_d62ca4bce275](../../sources/locomo/thread_7ad370356362.md#source-65bea40fc9fd04f4), [locomo/thread_7ad370356362/msg_a05209325496](../../sources/locomo/thread_7ad370356362.md#source-534dcb8fa35e2788)

The user is planning to pursue a PhD in Computer Science at Stanford University and wants to organize their research papers and notes from their master's program as resources for their future research.[^e-418c2edfcd] ^b67cc25e

[^e-418c2edfcd]: Time: `2023-05-28`; Sources: [locomo/thread_7ad370356362/msg_37a8ed176ced](../../sources/locomo/thread_7ad370356362.md#source-fcb254a2d25d6a29), [locomo/thread_7ad370356362/msg_ea7646ca78b8](../../sources/locomo/thread_7ad370356362.md#source-85dbb7853648edf3)

The user is creating a dedicated folder for their research paper "A Study on Deep Learning Techniques for Image Classification", and the assistant suggested subfolders for Paper Drafts, Research Notes, Code and Data, References, Figures and Images, Meeting Notes, and Related Resources, plus files such as Paperproposal.pdf, LiteratureReview.docx, Methodology.md, Results.xlsx, and Conclusion.tex.[^e-a017ff05ed] ^400a8c76

[^e-a017ff05ed]: Time: `2023-05-28`; Sources: [locomo/thread_7ad370356362/msg_fa994f441834](../../sources/locomo/thread_7ad370356362.md#source-083ef022c95c5910), [locomo/thread_7ad370356362/msg_2b7efd389e24](../../sources/locomo/thread_7ad370356362.md#source-8ba640741ca71e59)

The user is setting up similar folder structures for their Coursera courses "Python for Data Science" and "Introduction to Machine Learning", each with subfolders for course materials, assignments, notes, resources, and projects.[^e-aad97387ff] ^636ae4d9

[^e-aad97387ff]: Time: `2023-05-28`; Sources: [locomo/thread_7ad370356362/msg_4690d0ff07cd](../../sources/locomo/thread_7ad370356362.md#source-72dda7e8710e58c9), [locomo/thread_7ad370356362/msg_31c3e388359e](../../sources/locomo/thread_7ad370356362.md#source-1e87f0fe4b43586c)

The user is also creating a folder structure for their study group materials from November to January, with subfolders for meetings (by month), notes, resources, assignments and projects, and miscellaneous items.[^e-0614e65de8] ^2e06ccc8

[^e-0614e65de8]: Time: `2023-05-28`; Sources: [locomo/thread_7ad370356362/msg_48aacfc7cd5d](../../sources/locomo/thread_7ad370356362.md#source-47d2f82c5726925b), [locomo/thread_7ad370356362/msg_259f09de3bbe](../../sources/locomo/thread_7ad370356362.md#source-bedd177eca667cfc)

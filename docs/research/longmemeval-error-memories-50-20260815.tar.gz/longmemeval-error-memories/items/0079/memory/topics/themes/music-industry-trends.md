# Music Industry Trends

The user discussed albums that performed well on the Billboard 200 chart, citing Taylor Swift's "Lover" and Billie Eilish's "When We All Fall Asleep, Where Do We Go?" and the factors behind their success, such as dedicated fanbases, promotion and marketing, release timing, critical acclaim, and distinctive sound.[^e-c93bae737f] ^024384ea

[^e-c93bae737f]: Time: `2023-05-20`; Sources: [locomo/thread_6bc2090ac4de/msg_5d9d72415cf3](../../sources/locomo/thread_6bc2090ac4de.md#source-85f977f54f9b9a51), [locomo/thread_6bc2090ac4de/msg_42165ae9055a](../../sources/locomo/thread_6bc2090ac4de.md#source-3eb33e86e5d31093)

The user is a fan of Taylor Swift, describing her as one of the most talented musicians, and agreed that her feud with her former record label generated buzz that helped promote "Lover" while still valuing the quality of the music.[^e-1370a42e0a] ^50acd756

[^e-1370a42e0a]: Time: `2023-05-20`; Sources: [locomo/thread_6bc2090ac4de/msg_43baac8711b5](../../sources/locomo/thread_6bc2090ac4de.md#source-51c0b10960aaec6f)

The user believes social media is changing the music industry by letting artists build and engage fanbases directly and by helping independent artists gain exposure without traditional gatekeepers, and expressed interest in up-and-coming musicians including Clairo, Dominic Fike, Arlo Parks, Remi Wolf, girl in red, beabadoobee, Celeste, Omar Apollo, Baby Keem, and Omar Velasco.[^e-3eb8894b32] ^ee231cf3

[^e-3eb8894b32]: Time: `2023-05-20`; Sources: [locomo/thread_6bc2090ac4de/msg_10b483cad7ba](../../sources/locomo/thread_6bc2090ac4de.md#source-45fb741a5b723a61), [locomo/thread_6bc2090ac4de/msg_8b5a61df7f15](../../sources/locomo/thread_6bc2090ac4de.md#source-3955dc17fa09c679)

The user likes the trend of artists fusing different genres and styles, and is interested in the music industry trends of authentic and vulnerable songwriting and a resurgence of throwback sounds from the 70s, 80s, and 90s.[^e-462140a695] ^c21006da

[^e-462140a695]: Time: `2023-05-20`; Sources: [locomo/thread_6bc2090ac4de/msg_077b9fd33521](../../sources/locomo/thread_6bc2090ac4de.md#source-38b226a6cc202564)

# Deep-Sea Fishing

Deep-sea fishing boats cope with waves and rough seas through their design and equipment, being larger, heavier, and built of durable materials, and by using ballast systems to adjust weight for stability, specialized fishing gear such as stronger lines and nets, radar and GPS navigation, reliable communication systems, and an experienced crew.[^e-e3eb7d0276] ^2bd3c0f5

[^e-e3eb7d0276]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_c7261b05d950](../../sources/locomo/thread_37d993f7a9d6.md#source-b584adf4e7838ec0)

Fishing boats deal with crew motion sickness during rough seas through medications such as Dramamine and Scopolamine, natural remedies like ginger, fresh sea air on deck, hydration, light plain and easily digestible food, rest and sleep, and acupressure bands.[^e-3e4ef27e05] ^9e8a297c

[^e-3e4ef27e05]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_04860fb00bc9](../../sources/locomo/thread_37d993f7a9d6.md#source-9d8894722f733153)

Fishing boats usually do not have medical professionals on board, carrying only first aid kits and emergency medical supplies; for a severely seasick crew member the boat may return to shore immediately or the captain may contact the coast guard or other emergency medical services.[^e-624a68be84] ^064d666c

[^e-624a68be84]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_39cc9570c29e](../../sources/locomo/thread_37d993f7a9d6.md#source-9ac62023bc062ace)

# Mountain Trip

The user is planning a trip to the mountains and received packing tips covering layered clothing, waterproof hiking boots with good traction, toiletries, a first aid kit, portable chargers, a refillable water bottle, non-perishable snacks, and navigation gear such as a map, compass, or GPS.[^e-c125ab8781] ^f2d6a89a

[^e-c125ab8781]: Time: `2023-05-28`; Sources: [locomo/thread_d5369eec43f1/msg_f4c416079023](../../sources/locomo/thread_d5369eec43f1.md#source-ee51e609c80a9198), [locomo/thread_d5369eec43f1/msg_9b235d09782a](../../sources/locomo/thread_d5369eec43f1.md#source-7574c336946278e9)

The user bought a new dark grey backpack with multiple compartments and a dedicated laptop compartment on January 15th, 2023, specifically for the mountain trip, and has since been using it for their daily commute to carry their laptop, water bottle, and other essentials.[^e-de783e0b72] ^170920b0

[^e-de783e0b72]: Time: `2023-01-15`; Sources: [locomo/thread_d5369eec43f1/msg_f4c416079023](../../sources/locomo/thread_d5369eec43f1.md#source-ee51e609c80a9198), [locomo/thread_d5369eec43f1/msg_f494b6626eb1](../../sources/locomo/thread_d5369eec43f1.md#source-2ee7d0024a6a5b56), [locomo/thread_d5369eec43f1/msg_df6584837c48](../../sources/locomo/thread_d5369eec43f1.md#source-30508f9f81cde9ff)

The user is considering getting a hydration pack like their friend [Rachel](../people/rachel.md#^45b7b2e0)'s for an upcoming outdoor adventure and received recommendations including CamelBak, Osprey, Hydrapak, Salomon, and Platypus, with factors to weigh such as capacity, comfort, durability, features, and budget.[^e-5a8ad2f39f] ^b93461ce

[^e-5a8ad2f39f]: Time: `2023-05-28`; Sources: [locomo/thread_d5369eec43f1/msg_f494b6626eb1](../../sources/locomo/thread_d5369eec43f1.md#source-2ee7d0024a6a5b56), [locomo/thread_d5369eec43f1/msg_de327104af40](../../sources/locomo/thread_d5369eec43f1.md#source-dac99eed0b2fe6be)

The user is looking for a new tote bag to replace their old worn-out one for their daily commute and received recommendations including the Patagonia Atom Sling Bag, Fjallraven Kanken Laptop Bag, Tortuga Setout Laptop Tote, Cotopaxi Allpa Tote, and L.L.Bean Boat and Tote, with considerations around durable materials, a laptop compartment, pockets, style, and size.[^e-dad31e61c0] ^8f5406e5

[^e-dad31e61c0]: Time: `2023-05-28`; Sources: [locomo/thread_d5369eec43f1/msg_0c02aad8863e](../../sources/locomo/thread_d5369eec43f1.md#source-14684dae2d2281d3), [locomo/thread_d5369eec43f1/msg_5f2be11711cc](../../sources/locomo/thread_d5369eec43f1.md#source-97af2871c8f557d2)

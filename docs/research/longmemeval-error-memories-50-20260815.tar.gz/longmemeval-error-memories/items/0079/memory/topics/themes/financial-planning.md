# Financial Planning

The user turned 32 in April 2023 and is considering whether to pursue a master's degree, weighing the time and money investment against career advancement, increased earning potential, networking opportunities, personal growth, and specialization.[^e-894939c379] ^1d33c342

[^e-894939c379]: Time: `2023-05-28`; Sources: [locomo/thread_11649ff00661/msg_fa33c423b85d](../../sources/locomo/thread_11649ff00661.md#source-adf8258a99573ce4), [locomo/thread_11649ff00661/msg_5862312763d0](../../sources/locomo/thread_11649ff00661.md#source-485bdeb2bb00b4f6)

To finance a graduate degree, the user received an overview of options including federal direct loans (up to $20,500 per year), Grad PLUS loans, private student loans, scholarships and grants, employer tuition reimbursement, assistantships, and fellowships, along with tips for searching scholarships and completing the FAFSA.[^e-2f855086f7] ^b5021cad

[^e-2f855086f7]: Time: `2023-05-28`; Sources: [locomo/thread_11649ff00661/msg_db552290c7f9](../../sources/locomo/thread_11649ff00661.md#source-9a133750826267d0)

Buying a house is one of the user's long-term goals, and they received guidance on saving for a down payment (starting early, setting a goal, creating a dedicated savings plan, exploring tax-advantaged accounts, cutting back on expenses, and considering first-time homebuyer programs) along with the pros and cons of waiting until they are older.[^e-b519d52b2c] ^4076061a

[^e-b519d52b2c]: Time: `2023-05-28`; Sources: [locomo/thread_11649ff00661/msg_4fc77f4b56bc](../../sources/locomo/thread_11649ff00661.md#source-d391df4212af767f), [locomo/thread_11649ff00661/msg_ff50a674b4de](../../sources/locomo/thread_11649ff00661.md#source-ff40301adde6234d)

After weighing the role of age and their priorities, the user decided to start saving for a down payment now to build equity and take advantage of compound interest, while reviewing their budget and adjusting their savings rate so as not to overcommit or sacrifice their current lifestyle too much.[^e-3502835ab2] ^6e72e793

[^e-3502835ab2]: Time: `2023-05-28`; Sources: [locomo/thread_11649ff00661/msg_335c43a6c926](../../sources/locomo/thread_11649ff00661.md#source-fd000c7d01aa6e45), [locomo/thread_11649ff00661/msg_b296404aeb59](../../sources/locomo/thread_11649ff00661.md#source-0818782eaa612b63)

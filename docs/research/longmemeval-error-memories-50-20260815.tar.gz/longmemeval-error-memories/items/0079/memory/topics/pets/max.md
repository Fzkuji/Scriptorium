# Max

The user has a dog named Max, for whom they ordered a new flea and tick prevention medication a few weeks ago; the medication is working well, and the user has been taking Max on longer walks.[^e-aad278a463] ^ea7fa509

[^e-aad278a463]: Time: `2023-05-22`; Sources: [locomo/thread_782f9c17d73c/msg_b64a37705e35](../../sources/locomo/thread_782f9c17d73c.md#source-9a835dadfbf53491), [locomo/thread_782f9c17d73c/msg_c12d70257935](../../sources/locomo/thread_782f9c17d73c.md#source-5e8321495a35e8c0)

Max loves the longer walks and has become more energetic and playful, but he pulls on the leash, so the user is training him to walk by their side with consistent practice, and Max is slowly getting better.[^e-aaef6275da] ^80ebc213

[^e-aaef6275da]: Time: `2023-05-22`; Sources: [locomo/thread_782f9c17d73c/msg_a6b059ce2b87](../../sources/locomo/thread_782f9c17d73c.md#source-787a4f9d4f6b08ac), [locomo/thread_782f9c17d73c/msg_0bf7a1000f32](../../sources/locomo/thread_782f9c17d73c.md#source-a54ce35ac3e2c0e0)

The user recently got Max an interactive feeder toy to slow down his eating; it has been a game-changer because it reduced his gobbling, he now figures out the treats as a pro and spins in circles when excited, and he has become more patient and calm during mealtime.[^e-bc26d141c5] ^8ec49c95

[^e-bc26d141c5]: Time: `2023-05-22`; Sources: [locomo/thread_782f9c17d73c/msg_0bf7a1000f32](../../sources/locomo/thread_782f9c17d73c.md#source-a54ce35ac3e2c0e0), [locomo/thread_782f9c17d73c/msg_44649b04c9bb](../../sources/locomo/thread_782f9c17d73c.md#source-3dacea34f86da7ae)

The user uses eco-friendly grooming wipes on Max that are gentle on his skin and leave him smelling wonderful, and they are thinking of ordering more soon.[^e-6f1a361e85] ^1afda8fa

[^e-6f1a361e85]: Time: `2023-05-22`; Sources: [locomo/thread_782f9c17d73c/msg_44649b04c9bb](../../sources/locomo/thread_782f9c17d73c.md#source-3dacea34f86da7ae)

The user received recommendations for yard treatments to kill fleas and ticks, including pyrethrin-based and neem oil-based insecticides, insect growth regulators such as pyriproxyfen, beneficial nematodes, diatomaceous earth, and cedar oil-based products, from brands including Spectracide, Ortho, Bonide, Natural Chemistry, and Wondercide.[^e-238ba86af1] ^8053c114

[^e-238ba86af1]: Time: `2023-05-22`; Sources: [locomo/thread_782f9c17d73c/msg_0e1990088149](../../sources/locomo/thread_782f9c17d73c.md#source-4c6e9b979aae1078)

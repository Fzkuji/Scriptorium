# Sophia

Sophia is a woman the user met at a project management workshop, and the user is planning to meet her for coffee soon in Silicon Valley to discuss design thinking and her startup, and to ask about her experience with [Agile methodologies](../themes/agile-and-project-management.md#^b0205f5c).[^e-bd85e87892] ^1b2dfb3d

[^e-bd85e87892]: Time: `2023-05-23`; Sources: [locomo/thread_100ba0195b99/msg_8bc4719b42a4](../../sources/locomo/thread_100ba0195b99.md#source-d8856c22efaf2852), [locomo/thread_100ba0195b99/msg_4e2302660f07](../../sources/locomo/thread_100ba0195b99.md#source-7c4c020011415634), [locomo/thread_100ba0195b99/msg_2d726ca3f2c5](../../sources/locomo/thread_100ba0195b99.md#source-45d9f4ca533e3a50), [locomo/thread_100ba0195b99/msg_292dab1a066d](../../sources/locomo/thread_100ba0195b99.md#source-b4e6daa454973464)

The user is planning to meet Sophia, a woman they met at the project management workshop, for coffee soon, and asked for coffee shop recommendations in Silicon Valley, receiving suggestions including Coupa Cafe, Red Rock Coffee, The Coffee Bar, Blue Bottle Coffee, Philz Coffee, Verve Coffee Roasters, and The Creamery.[^e-b51de40250] ^f5a0855e

[^e-b51de40250]: Time: `2023-05-23`; Sources: [locomo/thread_100ba0195b99/msg_8bc4719b42a4](../../sources/locomo/thread_100ba0195b99.md#source-d8856c22efaf2852), [locomo/thread_100ba0195b99/msg_7539b8e04787](../../sources/locomo/thread_100ba0195b99.md#source-be24f55d96db4f2f)

The user plans to discuss design thinking with Sophia, as they recently attended a design thinking workshop at the Stanford d.school, and received coffee shop recommendations near the Stanford campus suitable for the discussion, including Coupa Cafe (Stanford), The HanaHaus, The Patio, and Verve Coffee Roasters (Palo Alto).[^e-8989ed5b92] ^220e7a31

[^e-8989ed5b92]: Time: `2023-05-23`; Sources: [locomo/thread_100ba0195b99/msg_4e2302660f07](../../sources/locomo/thread_100ba0195b99.md#source-7c4c020011415634), [locomo/thread_100ba0195b99/msg_7c72bda5a8ce](../../sources/locomo/thread_100ba0195b99.md#source-1c82152d7010295f)

The user plans to ask Sophia about her startup and how she applies design thinking principles in her work, and received design thinking book recommendations (Design Thinking by Nigel Cross, Creative Confidence by David and Tom Kelley, Design Thinking for Entrepreneurs and Small Businesses by Natasha Walter and Patrick Llewellyn, This Is Service Design Thinking by Marc Stickdorn and Jakob Schneider, Sprint by Jake Knapp, John Zeratsky, and Braden Kowitz) and online resources (Stanford d.school's design thinking resources, IDEO, Design Thinking Academy, The Design Thinking Podcast, and the Design Thinking subreddit) to share with her.[^e-64bd0ae775] ^a0723874

[^e-64bd0ae775]: Time: `2023-05-23`; Sources: [locomo/thread_100ba0195b99/msg_2d726ca3f2c5](../../sources/locomo/thread_100ba0195b99.md#source-45d9f4ca533e3a50), [locomo/thread_100ba0195b99/msg_7b8eb7f117cf](../../sources/locomo/thread_100ba0195b99.md#source-fc6a5bae0620dde3)

The user received tips for communicating their design thinking experience with Sophia, including sharing a personal story, using the "What, So What, Now What" framework, focusing on the process rather than just the outcome, using visual aids, practicing active listening, avoiding jargon, and being humble and open.[^e-24060bdbfc] ^d3695c60

[^e-24060bdbfc]: Time: `2023-05-23`; Sources: [locomo/thread_100ba0195b99/msg_134d798c49b3](../../sources/locomo/thread_100ba0195b99.md#source-ec3a2b2a70281943), [locomo/thread_100ba0195b99/msg_620e79f5c784](../../sources/locomo/thread_100ba0195b99.md#source-5c3815bdf93e6c5f)

The user is also planning to ask Sophia about her experience with Agile methodologies, and received advice to start by asking about her company's approach to Agile and then dive deeper into her personal experience and her thoughts on Agile's benefits and challenges.[^e-90ddaf6d06] ^d0b64120

[^e-90ddaf6d06]: Time: `2023-05-23`; Sources: [locomo/thread_100ba0195b99/msg_292dab1a066d](../../sources/locomo/thread_100ba0195b99.md#source-b4e6daa454973464), [locomo/thread_100ba0195b99/msg_2aa5e9b82bd5](../../sources/locomo/thread_100ba0195b99.md#source-239b73750d373fe3)

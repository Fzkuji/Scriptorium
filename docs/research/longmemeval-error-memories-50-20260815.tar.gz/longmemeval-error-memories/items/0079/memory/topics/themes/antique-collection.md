# Antique Collection

The user collects antiques and, two days before 2023-05-25, organized their new apartment and dedicated a whole shelf to the collection; they are creating a digital catalog in a spreadsheet using a template that covers item ID, description, provenance, date, maker/artist, materials, condition, dimensions, acquisition date, acquisition price, estimated value, images, and notes.[^e-ba767ba577][^e-66174eddcb] ^49689bb5

[^e-ba767ba577]: Time: `2023-05-23`; Sources: [locomo/thread_cb51e23a7220/msg_ca1a1221cb88](../../sources/locomo/thread_cb51e23a7220.md#source-be0d5789cc715f43)

[^e-66174eddcb]: Time: `2023-05-25`; Sources: [locomo/thread_cb51e23a7220/msg_a4c71d0b2715](../../sources/locomo/thread_cb51e23a7220.md#source-60b9d46a7808069c)

The first entry in the antique catalog is a music box (Item ID MB001): an intricately carved wooden piece with a soft golden tone, about 6 inches wide and 4 inches tall, inherited from the user's grandmother and originally belonging to their great-grandmother, antique (over 100 years old, exact date unknown) but in good condition and still playing a melody when wound up.[^e-1bed32ab39][^e-e5d9e5a189] ^cbe9ee08

[^e-1bed32ab39]: Time: `2023-05-25`; Sources: [locomo/thread_cb51e23a7220/msg_527717f48654](../../sources/locomo/thread_cb51e23a7220.md#source-0d1840013b057532)

[^e-e5d9e5a189]: Time: `2023-05-25`; Sources: [locomo/thread_cb51e23a7220/msg_076547da6156](../../sources/locomo/thread_cb51e23a7220.md#source-631de7cd30430e75)

The user is adding a second entry to the antique catalog for an antique brooch (Item ID AB001) they purchased from the antique store in town: a silver brooch with a large blue gemstone in the center that the shop owner said is from the 1920s, in excellent condition and worn daily to work, for which the user paid $200 and which has no estimated value although the shop owner believed it to be quite valuable; to fill in the entry they received a template of questions covering the brooch's description, provenance, date, maker, materials, condition, dimensions, acquisition date and price, estimated value, images, and notes.[^e-57676f4b16][^e-e5d7b989d6] ^46c6baa8 ^3912ef7c

[^e-57676f4b16]: Time: `2023-05-25`; Sources: [locomo/thread_cb51e23a7220/msg_6303874eeb15](../../sources/locomo/thread_cb51e23a7220.md#source-31035d170ccbcdf0), [locomo/thread_cb51e23a7220/msg_af6299ee776b](../../sources/locomo/thread_cb51e23a7220.md#source-ee0ee376ec862061)

[^e-e5d7b989d6]: Time: `2023-05-25`; Sources: [locomo/thread_cb51e23a7220/msg_7729f1449409](../../sources/locomo/thread_cb51e23a7220.md#source-7e058e76b0b49551), [locomo/thread_cb51e23a7220/msg_364a88e3289e](../../sources/locomo/thread_cb51e23a7220.md#source-db210dccf7a5a028)

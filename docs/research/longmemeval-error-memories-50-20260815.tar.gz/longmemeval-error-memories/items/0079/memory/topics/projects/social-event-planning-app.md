# Social Event Planning App

The user is building a social networking app specifically for organizing private parties and events, which lets users create and manage events, invite guests, track RSVPs, and swipe to connect with potential party attendees, filling what they see as a gap in the social networking market.[^e-95364d3122] ^7daf1cd9

[^e-95364d3122]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_cef6e3a88f68](../../sources/locomo/thread_7a2d72a9009a.md#source-52c4794a71fd2442), [locomo/thread_7a2d72a9009a/msg_db5b60cf8fd1](../../sources/locomo/thread_7a2d72a9009a.md#source-09eb5fd0b8dae9a0)

The app targets young professionals and families, and its revenue model is based on a commission for event services such as catering, entertainment, and decor, plus advertising revenue.[^e-9f6c2f3d97] ^7b087f51

[^e-9f6c2f3d97]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_db5b60cf8fd1](../../sources/locomo/thread_7a2d72a9009a.md#source-09eb5fd0b8dae9a0)

The user compared their app with Meetup, noting that their app focuses on private parties and events, lets users both find and host events, is designed for more intimate gatherings, facilitates social interaction among friends and acquaintances, and allows hosts to fully customize events including location, guest list, and activities, whereas Meetup is broader, interest-based, often larger, and more standardized.[^e-a9ea79abe9] ^7927fcd4

[^e-a9ea79abe9]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_e26d251543f7](../../sources/locomo/thread_7a2d72a9009a.md#source-7522adc57a74b183)

The user believes the app solves the problem of organizing and attending private parties, especially for people who struggle to find suitable venues or groups of people with similar interests.[^e-2ff77251da] ^a150e0b2

[^e-2ff77251da]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_50d2b704a4c6](../../sources/locomo/thread_7a2d72a9009a.md#source-8fc22c399e2eb2b7)

The user researched business plan examples and templates for the mobile app, referencing Bplans, LivePlan, SCORE.org, the Small Business Administration, and Entrepreneur.com, and later used a Bplans mobile-app business plan template after an earlier linked template did not work.[^e-ee4211cffd] ^e9c9c432

[^e-ee4211cffd]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_733c22d0826c](../../sources/locomo/thread_7a2d72a9009a.md#source-80f4b4db0c7b2c23), [locomo/thread_7a2d72a9009a/msg_63f91f0db0f3](../../sources/locomo/thread_7a2d72a9009a.md#source-a7ffeb84c1685f63), [locomo/thread_7a2d72a9009a/msg_57d29f90b1ff](../../sources/locomo/thread_7a2d72a9009a.md#source-a2ea9aed1a127425)

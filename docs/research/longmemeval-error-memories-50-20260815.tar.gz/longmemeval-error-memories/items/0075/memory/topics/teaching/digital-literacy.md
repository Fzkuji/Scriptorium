# Digital Literacy Curriculum

The user is preparing a lesson plan for the 10th session of a digital literacy course for 6th-grade elementary school students.[^e-2ffb4c7b10] ^47ed6bec

[^e-2ffb4c7b10]: Time: `2023-05-21`; Sources: [locomo/thread_5c188c1c98ea/msg_c93b211f719c](../../sources/locomo/thread_5c188c1c98ea.md#source-ad7ffc82fccaa51c)

The 10th digital literacy session, titled "Evaluating Online Information", teaches students to evaluate the credibility and reliability of online sources using the CRAAP Test (Currency, Relevance, Authority, Accuracy, Purpose).[^e-f301c90e2a] ^19e250b5

[^e-f301c90e2a]: Time: `2023-05-21`; Sources: [locomo/thread_5c188c1c98ea/msg_7e381a129fb8](../../sources/locomo/thread_5c188c1c98ea.md#source-b7c2e043c35761cf)

The user sought effective methods and edtech programs for the course's reflection and discussion time; recommendations included active-listening and questioning techniques and the tools Padlet, Nearpod, Flipgrid, and Google Jamboard.[^e-ab950dece9] ^fe3fb3d2

[^e-ab950dece9]: Time: `2023-05-21`; Sources: [locomo/thread_5c188c1c98ea/msg_2857d8f8371a](../../sources/locomo/thread_5c188c1c98ea.md#source-869e410aa1a04c70), [locomo/thread_5c188c1c98ea/msg_345c325e19c4](../../sources/locomo/thread_5c188c1c98ea.md#source-fee814e703d95b15)

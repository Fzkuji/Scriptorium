# Football

The user follows football (soccer) and was interested in tweets about the 2022 FIFA World Cup final between Argentina and France, in which Argentina scored a team goal widely praised as the best of the tournament, led 2-0, and had Messi and Di Maria playing well while France had no attempts on goal after 35 minutes.[^e-15b8547c60] ^d8719484

[^e-15b8547c60]: Time: `2022-12-18`; Sources: [locomo/thread_7c96790ff4be/msg_78118bc0cf54](../../sources/locomo/thread_7c96790ff4be.md#source-0f9d10005397692e)

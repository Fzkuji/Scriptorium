# Technology Career

The user researched what an Escalation Engineer II at Amazon Web Services does, learning that the role resolves complex escalated customer issues and provides technical guidance.[^e-3daa7e130d] ^3a39d88b

[^e-3daa7e130d]: Time: `2023-05-21`; Sources: [locomo/thread_89990fbd2a44/msg_e94e6e841d8e](../../sources/locomo/thread_89990fbd2a44.md#source-72a40ff0043bd59d)

The user asked how an Escalation Engineer II at Amazon's work experience would qualify for a Computer Network and Systems Engineer role that plans, develops, deploys, tests, and optimises network and system services, including configuration management and troubleshooting network problems.[^e-7c8305c036] ^834cbc82

[^e-7c8305c036]: Time: `2023-05-21`; Sources: [locomo/thread_89990fbd2a44/msg_159ca96fc9cf](../../sources/locomo/thread_89990fbd2a44.md#source-dbb89dc4c282dd9b)

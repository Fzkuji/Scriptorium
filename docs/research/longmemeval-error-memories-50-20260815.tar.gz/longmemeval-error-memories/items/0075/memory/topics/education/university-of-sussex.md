# University of Sussex Applications

The user is applying to academic programs at the University of Sussex and asked about the application process, which involves researching and choosing a program, checking entry requirements, completing an online application form, paying a non-refundable application fee, submitting supporting documents, waiting for a decision, and accepting an offer.[^e-1b767b73cb] ^9fbf244e

[^e-1b767b73cb]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_0225eb431b77](../../sources/locomo/thread_023f8650f638.md#source-0e82838c5d4f1111), [locomo/thread_023f8650f638/msg_613063c05176](../../sources/locomo/thread_023f8650f638.md#source-8aa9ce3799ac6617)

The user researched scholarship opportunities at the University of Sussex, including the Chancellor's International Scholarships for full-time PhD research, Sussex Graduate Scholarships, Sussex Excellence Scholarship, Sussex India Scholarship, and the Commonwealth Shared Scholarship Scheme.[^e-e13cfa6dac] ^2e861597

[^e-e13cfa6dac]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_5ba654acec46](../../sources/locomo/thread_023f8650f638.md#source-0865d6d678ff0fc8), [locomo/thread_023f8650f638/msg_a9671522ba60](../../sources/locomo/thread_023f8650f638.md#source-f33656c2882b1afc)

The user sought advice on making their application stand out and on increasing their chances of receiving a scholarship.[^e-023260578e] ^92e73c1b

[^e-023260578e]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_5cc39f69fb27](../../sources/locomo/thread_023f8650f638.md#source-065a44001a08aed1), [locomo/thread_023f8650f638/msg_73b99f46c32b](../../sources/locomo/thread_023f8650f638.md#source-727d7a6d83be22ec)

The user asked about campus life at the University of Sussex and learned about its sports clubs and facilities, arts and performance groups, over 100 student societies, volunteering opportunities, and the student union.[^e-96c244c4e0] ^7a08f12d

[^e-96c244c4e0]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_267560f5af42](../../sources/locomo/thread_023f8650f638.md#source-af3d6d0787d62c08), [locomo/thread_023f8650f638/msg_ddb8e14bcb4d](../../sources/locomo/thread_023f8650f638.md#source-1745549ded17252d)

# Graduate Studies

The user completed a master's program in six months, running from November 2022 to May 2023.[^e-2188da7790] ^f028f5e7

[^e-2188da7790]: Time: `2023-05`; Sources: [locomo/thread_85a4c6cb88e4/msg_7d4597b48c1f](../../sources/locomo/thread_85a4c6cb88e4.md#source-3e1244b164ec31b8)

The user passed their comprehensive exam on February 20th, 2023.[^e-33b358314e] ^2d20b57e

[^e-33b358314e]: Time: `2023-02-20`; Sources: [locomo/thread_85a4c6cb88e4/msg_7d4597b48c1f](../../sources/locomo/thread_85a4c6cb88e4.md#source-3e1244b164ec31b8)

The user joined a study group in December to prepare for the comprehensive exam and continued attending its meetings until January.[^e-29b86fb486] ^dc0d6f71

[^e-29b86fb486]: Time: `2022-12`; Sources: [locomo/thread_85a4c6cb88e4/msg_7d4597b48c1f](../../sources/locomo/thread_85a4c6cb88e4.md#source-3e1244b164ec31b8)

The user is planning to pursue a PhD in Computer Science at Stanford University.[^e-439fbf7f6c] ^fafd7c34

[^e-439fbf7f6c]: Time: `2023-05-27`; Sources: [locomo/thread_85a4c6cb88e4/msg_306129b77529](../../sources/locomo/thread_85a4c6cb88e4.md#source-aa4b8849c9b101b3)

The user wrote a research paper titled "A Study on Deep Learning Techniques for Image Classification" during their master's program and planned a separate folder structure for it with subfolders for paper drafts, research notes, code and data, references, figures and images, meeting notes, and related resources.[^e-dcafdc549b] ^31b81d73

[^e-dcafdc549b]: Time: `2023-05`; Sources: [locomo/thread_85a4c6cb88e4/msg_5137ed1d4de5](../../sources/locomo/thread_85a4c6cb88e4.md#source-6f6ff93e083c6fa8), [locomo/thread_85a4c6cb88e4/msg_7ce0b7721688](../../sources/locomo/thread_85a4c6cb88e4.md#source-813f63f4d98b916c)

The user is taking the Coursera courses "Python for Data Science" and "Introduction to Machine Learning" and planned folder structures for each to organize course materials, assignments, notes, resources, and projects.[^e-7cd6b6b4fa] ^d5ba1be9

[^e-7cd6b6b4fa]: Time: `2023-05-27`; Sources: [locomo/thread_85a4c6cb88e4/msg_e92371480974](../../sources/locomo/thread_85a4c6cb88e4.md#source-c487346a7806b798), [locomo/thread_85a4c6cb88e4/msg_17e408ca2f35](../../sources/locomo/thread_85a4c6cb88e4.md#source-14950ade077300af)

The user studied the t distribution, which is used to make inferences about the population mean when the sample size is small and/or the population standard deviation is unknown, and learned how it applies to hypothesis testing and confidence interval estimation, referencing a table of critical values.[^e-8f9721e787] ^5566c561

[^e-8f9721e787]: Time: `2023-05-27`; Sources: [locomo/thread_4c22fc1ada7e/msg_f204f7793441](../../sources/locomo/thread_4c22fc1ada7e.md#source-8cb8a421e0b22842), [locomo/thread_4c22fc1ada7e/msg_ac68968e2f28](../../sources/locomo/thread_4c22fc1ada7e.md#source-592e59f740a6afbd)

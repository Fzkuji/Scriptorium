# Cooking

The user's first kimchi attempt, around 2023-05-14, was too spicy and too salty.[^e-a374f5f552] ^15703818

[^e-a374f5f552]: Time: `2023-05-14`; Sources: [locomo/thread_6bc2090ac4de/msg_a24e4dfe6c20](../../sources/locomo/thread_6bc2090ac4de.md#source-a32718f8a803603d)

To fix the kimchi, the user planned to rinse it under cold running water and re-season with gochugaru (Korean chili flakes), garlic, and ginger to balance the flavors.[^e-c7c5bc522f] ^f29582ea

[^e-c7c5bc522f]: Time: `2023-05-21`; Sources: [locomo/thread_6bc2090ac4de/msg_9ba747ecd95c](../../sources/locomo/thread_6bc2090ac4de.md#source-274c1177e1bea022), [locomo/thread_6bc2090ac4de/msg_2719e25a26a0](../../sources/locomo/thread_6bc2090ac4de.md#source-3dd95118165ede9d)

The user has been making Chicken Fajitas every Wednesday for the past two weeks as part of their meal prep routine and cooks dinner at home at least 4-5 times a week, sometimes lunch from leftovers.[^e-27e8dbd09a] ^616261e0

[^e-27e8dbd09a]: Time: `2023-05-26`; Sources: [locomo/thread_4b21292cb720/msg_b9c42ec2818a](../../sources/locomo/thread_4b21292cb720.md#source-f688fc29bf3ef51b), [locomo/thread_4b21292cb720/msg_585af530996e](../../sources/locomo/thread_4b21292cb720.md#source-140b6c7130febcf4), [locomo/thread_4b21292cb720/msg_d8a272cf1565](../../sources/locomo/thread_4b21292cb720.md#source-81e31b5dfe2e7fe2)

The user stocked up on cumin, smoked paprika, and garam masala and has been making an Indian-inspired lentil curry that has become a staple in their meal rotation, served with quinoa and roasted vegetables such as broccoli, carrots, Brussels sprouts, and sweet potatoes, and wants to try making homemade naan bread to serve alongside it, while also looking for new easy and healthy lunch ideas and liking the sound of Quinoa Salad Jars and Lentil Soup.[^e-179000856b] ^f1bcf4bb

[^e-179000856b]: Time: `2023-05-26`; Sources: [locomo/thread_4b21292cb720/msg_6717c54de530](../../sources/locomo/thread_4b21292cb720.md#source-e43cbdbd9cc27615), [locomo/thread_4b21292cb720/msg_b98e03f7e622](../../sources/locomo/thread_4b21292cb720.md#source-74be01f6ec33464a), [locomo/thread_4b21292cb720/msg_eac0bf1078a0](../../sources/locomo/thread_4b21292cb720.md#source-08e47c098c9c092e)

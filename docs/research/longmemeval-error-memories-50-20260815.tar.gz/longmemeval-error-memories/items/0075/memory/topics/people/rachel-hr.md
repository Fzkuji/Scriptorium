# Rachel (HR)

The user got to know their coworker Rachel from HR better during a charity walk on 2022-10-15 and found that she is a great conversationalist.[^e-065b638144] ^9c343cfa

[^e-065b638144]: Time: `2022-10-15`; Sources: [locomo/thread_8e09fa96d2c5/msg_4d38dab909a4](../../sources/locomo/thread_8e09fa96d2c5.md#source-ba535e061d734b7b)

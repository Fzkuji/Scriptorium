# Plants

The user acquired a peace lily and a succulent from a nursery around 2023-05-06; the peace lily was losing some leaves, which is normal as the plant adjusts to a new environment.[^e-de872833e1] ^4b8f1004

[^e-de872833e1]: Time: `2023-05-06`; Sources: [locomo/thread_7a2d72a9009a/msg_cef6e3a88f68](../../sources/locomo/thread_7a2d72a9009a.md#source-52c4794a71fd2442)

The user waters their plants with a mixture of water and fertilizer obtained from the nursery where they bought the peace lily and succulent.[^e-be8f3f4598] ^ea01e957

[^e-be8f3f4598]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_b2abf303cfe7](../../sources/locomo/thread_7a2d72a9009a.md#source-73f5889a2d354328)

The user uses a plant tracking app to manage their watering schedule and fertilization reminders.[^e-9f6c2f3d97] ^10bc654c

[^e-9f6c2f3d97]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_db5b60cf8fd1](../../sources/locomo/thread_7a2d72a9009a.md#source-09eb5fd0b8dae9a0)

The user mists a fern every other day.[^e-9ca48a330d] ^26c3159b

[^e-9ca48a330d]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_733c22d0826c](../../sources/locomo/thread_7a2d72a9009a.md#source-80f4b4db0c7b2c23)

The user keeps their peace lily in a spot with a consistent temperature between 65°F and 70°F (18°C to 21°C).[^e-0eb8e0753e] ^2716f734

[^e-0eb8e0753e]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_4bd0847b5056](../../sources/locomo/thread_7a2d72a9009a.md#source-5d4e66e508c196bc)

The user pruned their rose bush around 2023-04-20.[^e-f9a847e833] ^5b43bbb6

[^e-f9a847e833]: Time: `2023-04-20`; Sources: [locomo/thread_7a2d72a9009a/msg_c342a31cfa2b](../../sources/locomo/thread_7a2d72a9009a.md#source-193445d40b165945)

The user's rose bush was already producing new buds after being pruned.[^e-45f7d4a996] ^2e8411b4

[^e-45f7d4a996]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_c342a31cfa2b](../../sources/locomo/thread_7a2d72a9009a.md#source-193445d40b165945)

The user has a snake plant and succulents and asked for fertilizer recommendations specific to each, having been using a general-purpose fertilizer; they also have an orchid and were considering getting a fertilizer suited to it.[^e-9047f5e36e] ^fea92e03

[^e-9047f5e36e]: Time: `2023-05-24`; Sources: [locomo/thread_046276ceb02b/msg_20610c3cfbd0](../../sources/locomo/thread_046276ceb02b.md#source-bfb012a87e2319f9), [locomo/thread_046276ceb02b/msg_a857f58c3571](../../sources/locomo/thread_046276ceb02b.md#source-8ef15830982270cc)

The user was considering getting a humidifier for their indoor plants, especially the fern and their African violets, which get crispy leaves when the air is too dry.[^e-38a5afa2be] ^6d609fd7

[^e-38a5afa2be]: Time: `2023-05-24`; Sources: [locomo/thread_046276ceb02b/msg_07f43e3f2ff4](../../sources/locomo/thread_046276ceb02b.md#source-35efa00fe81f235c), [locomo/thread_046276ceb02b/msg_817878b93de4](../../sources/locomo/thread_046276ceb02b.md#source-2d741f259a00a35d)

The user has a spider plant and was considering repotting it because the potting mix is getting old.[^e-14dadb10ea] ^5b9015db

[^e-14dadb10ea]: Time: `2023-05-24`; Sources: [locomo/thread_046276ceb02b/msg_7940ea7fea7c](../../sources/locomo/thread_046276ceb02b.md#source-aaceada76ff8beba)

The user has a basil plant on their balcony that was struggling from too much direct sunlight, and sought advice on caring for it in a shadier spot and on ideal soil conditions.[^e-7b81ef5c18] ^ac392123

[^e-7b81ef5c18]: Time: `2023-05-25`; Sources: [locomo/thread_3dfeec2de60c/msg_8c4ecc50b41f](../../sources/locomo/thread_3dfeec2de60c.md#source-7de3472b38635a32), [locomo/thread_3dfeec2de60c/msg_1ad73b6abe91](../../sources/locomo/thread_3dfeec2de60c.md#source-8b203e1d58e7608f)

The user's snake plant, received from their sister about a month earlier, has been doing well with their current watering and fertilizer routine.[^e-6588cf4271] ^f20fe431

[^e-6588cf4271]: Time: `2023-05-25`; Sources: [locomo/thread_3dfeec2de60c/msg_8c4ecc50b41f](../../sources/locomo/thread_3dfeec2de60c.md#source-7de3472b38635a32), [locomo/thread_3dfeec2de60c/msg_2ec661761e54](../../sources/locomo/thread_3dfeec2de60c.md#source-69f1c27a63f1799a)

The user asked whether repotting their snake plant would be beneficial, and decided to wait a bit before repotting it, wanting to make sure it really needs it.[^e-2c090596d8] ^5571c7f2

[^e-2c090596d8]: Time: `2023-05-25`; Sources: [locomo/thread_3dfeec2de60c/msg_700c3abe7a3c](../../sources/locomo/thread_3dfeec2de60c.md#source-6211eb4f9f499a3f)

The user noticed tiny, moving dot pests crawling on their fern's leaves and stems, which were suspected to be spider mites or springtails, and decided to try neem oil to control them.[^e-707c163295] ^4bc8946d

[^e-707c163295]: Time: `2023-05-25`; Sources: [locomo/thread_3dfeec2de60c/msg_700c3abe7a3c](../../sources/locomo/thread_3dfeec2de60c.md#source-6211eb4f9f499a3f), [locomo/thread_3dfeec2de60c/msg_c6071a918886](../../sources/locomo/thread_3dfeec2de60c.md#source-7e4f1cf580fca35a), [locomo/thread_3dfeec2de60c/msg_15403e71b18b](../../sources/locomo/thread_3dfeec2de60c.md#source-51b98738bb8df878), [locomo/thread_3dfeec2de60c/msg_ed8d42c71ee2](../../sources/locomo/thread_3dfeec2de60c.md#source-d6ca97ca2d66cdc4)

The user asked about misting their fern more frequently to help prevent the pests from returning and was advised to mist it 2-3 times a week in the morning with a fine mist of distilled or filtered water, misting the undersides of the leaves while avoiding the crown.[^e-88870500f8] ^15f63891

[^e-88870500f8]: Time: `2023-05-25`; Sources: [locomo/thread_3dfeec2de60c/msg_ed8d42c71ee2](../../sources/locomo/thread_3dfeec2de60c.md#source-d6ca97ca2d66cdc4), [locomo/thread_3dfeec2de60c/msg_bf8e68e25eab](../../sources/locomo/thread_3dfeec2de60c.md#source-18f3099c20dc8289)

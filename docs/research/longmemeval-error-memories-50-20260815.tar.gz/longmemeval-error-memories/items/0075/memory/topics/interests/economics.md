# Economics & History

The user asked about the U.S. government's gold confiscation during the 1930s Great Depression and learned that Executive Order 6102 of April 5, 1933 prohibited the hoarding of gold, required citizens to deliver gold to the Federal Reserve at $20.67 per ounce, and that the Gold Reserve Act of 1934 raised the official price to $35 per ounce as part of the New Deal.[^e-24857baf18] ^2bd2bff6

[^e-24857baf18]: Time: `2023-05-23`; Sources: [locomo/thread_749fa3152137/msg_a642c1a18f3f](../../sources/locomo/thread_749fa3152137.md#source-4163a2571ab0f5e7), [locomo/thread_749fa3152137/msg_6122171936cb](../../sources/locomo/thread_749fa3152137.md#source-0d783ebded5190c7)

The user is interested in how a future economic catastrophe might differ from the 1930s, describing the current environment as having a huge debt burden of around $32 trillion, heavy quantitative easing, a Federal Reserve balance sheet that ballooned to over $10 trillion from about $1 trillion a decade earlier, widespread inflation, high interest rates, and no gold standard.[^e-6135e963a3] ^7106e34d

[^e-6135e963a3]: Time: `2023-05-23`; Sources: [locomo/thread_749fa3152137/msg_0913bf8fc1b5](../../sources/locomo/thread_749fa3152137.md#source-c0d518f692b45fef)

The user continued exploring a worst-case scenario for an uncontrollable debt burden, in which a loss of confidence in the government and central bank could lead to currency depreciation, hyperinflation from money printing, a deep recession or depression, systemic financial collapse with bank runs, social unrest and political instability, and international contagion through trade and financial linkages.[^e-77d44cc56c] ^66e0abd9

[^e-77d44cc56c]: Time: `2023-05-23`; Sources: [locomo/thread_749fa3152137/msg_4d533b6188b6](../../sources/locomo/thread_749fa3152137.md#source-2261945359ac6c8b), [locomo/thread_749fa3152137/msg_5874bcc16857](../../sources/locomo/thread_749fa3152137.md#source-d341808becf35c40)

The user explored how the location of the Port of Vancouver on Canada's West Coast makes it the closest major North American port to Asia, reducing shipping times and costs and providing easy access to markets in China, Japan, and South Korea, and expressed interest in visiting the port and learning about the goods shipped through it.[^e-abb99df48a] ^d7ba062f

[^e-abb99df48a]: Time: `2023-05-27`; Sources: [locomo/thread_e85fb7a5fdaa/msg_89e527969c06](../../sources/locomo/thread_e85fb7a5fdaa.md#source-e961634308cd8289), [locomo/thread_e85fb7a5fdaa/msg_fd4953c05338](../../sources/locomo/thread_e85fb7a5fdaa.md#source-6ae9fafd63cff716), [locomo/thread_e85fb7a5fdaa/msg_4db1ca81c322](../../sources/locomo/thread_e85fb7a5fdaa.md#source-f4bcfd718bec2398)

The user learned about the diverse range of cargo shipped through the Port of Vancouver, including containerized goods, dry bulk such as grains, coal, iron ore, and wood pellets, liquid bulk such as petroleum products, chemicals, and liquefied natural gas, automobiles and automobile parts, forest products such as lumber, pulp, and paper, and food products including fresh fruits, vegetables, and seafood.[^e-b5692144e1] ^067eabba

[^e-b5692144e1]: Time: `2023-05-27`; Sources: [locomo/thread_e85fb7a5fdaa/msg_82036e3667b3](../../sources/locomo/thread_e85fb7a5fdaa.md#source-baa2ea07b4716887)

The Port of Vancouver is one of the busiest ports in North America, handling over $200 billion worth of goods every year with around-the-clock activity across trucks, trains, and ships as a gateway to Asia. The user was impressed by the port's eco-friendly efforts and learned about its sustainability initiatives, including investing in energy-efficient infrastructure, promoting sustainable shipping practices such as reducing ship emissions and adopting shore power, encouraging low-carbon and electric vehicles in port operations, adopting waste reduction and recycling practices, and developing green spaces and footpaths along the waterfront.[^e-59cada9d3a][^e-1841d26926][^e-43c9a84da0] ^a9847b97

[^e-59cada9d3a]: Time: `2023-05-27`; Sources: [locomo/thread_e85fb7a5fdaa/msg_4187f392cc94](../../sources/locomo/thread_e85fb7a5fdaa.md#source-d2a895a6e2e41d0e)

[^e-1841d26926]: Time: `2023-05-27`; Sources: [locomo/thread_e85fb7a5fdaa/msg_6d15d8137717](../../sources/locomo/thread_e85fb7a5fdaa.md#source-6717ebcca373ae31)

[^e-43c9a84da0]: Time: `2023-05-27`; Sources: [locomo/thread_e85fb7a5fdaa/msg_1f097b02c36d](../../sources/locomo/thread_e85fb7a5fdaa.md#source-9e14b1f9fc56c0f4)

# Emily

The user is trying to reconnect with their old college friend Emily, whose number they lost after exchanging contact information with her at their alma mater's homecoming event in October 2022; they are considering searching social media, the alumni association directory, mutual classmates, future alumni events, people-search websites, and mutual friends.[^e-9ff1fe645c] ^6221c45d

[^e-9ff1fe645c]: Time: `2023-05-29`; Sources: [locomo/thread_6e68d84c9eb7/msg_1bb8cc175d85](../../sources/locomo/thread_6e68d84c9eb7.md#source-211273aecf443912)

# Design for Social Impact

The user explored graphic design project ideas that are useful for people in underdeveloped regions, such as educational materials, health awareness campaigns, agricultural guides, water and sanitation resources, and community mapping, and then sought guidance on designing maps and other visual resources including infographics, illustrations, diagrams, charts, and photos to help people navigate and understand their surroundings.[^e-778df67998] ^d8c0411d

[^e-778df67998]: Time: `2023-05-26`; Sources: [locomo/thread_6e5fb66a8677/msg_23f06e476787](../../sources/locomo/thread_6e5fb66a8677.md#source-3bbdd5ff7d83bb85), [locomo/thread_6e5fb66a8677/msg_b0dd037710f8](../../sources/locomo/thread_6e5fb66a8677.md#source-898b3cbeb4c7aa05), [locomo/thread_6e5fb66a8677/msg_a3dff09a9f15](../../sources/locomo/thread_6e5fb66a8677.md#source-15e665898f5596e7)

# Rachel

The user has a friend named Rachel, whose debut novel "The Whispering Walls" had its book launch event on 2023-05-24; the user attended the event to celebrate and support her.[^e-b40fdeca81] ^83d217b3

[^e-b40fdeca81]: Time: `2023-05-24`; Sources: [locomo/thread_2722126b02ae/msg_89c8fca8566c](../../sources/locomo/thread_2722126b02ae.md#source-ad3343c88e9e397f), [locomo/thread_2722126b02ae/msg_cd7648ea9f34](../../sources/locomo/thread_2722126b02ae.md#source-229df720b23033c6), [locomo/thread_2722126b02ae/msg_6ce52dc5c319](../../sources/locomo/thread_2722126b02ae.md#source-b1148d2c90a1c5e4)

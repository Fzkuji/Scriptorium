# Max (Dog)

The user has a dog named Max, who loves playing fetch in the pond at a nearby park.[^e-f8c1d33794] ^83d1370e

[^e-f8c1d33794]: Time: `2023-05-23`; Sources: [locomo/thread_bb376441501c/msg_ff4264064f14](../../sources/locomo/thread_bb376441501c.md#source-7e33fd17b92c937a), [locomo/thread_bb376441501c/msg_264e6fe14057](../../sources/locomo/thread_bb376441501c.md#source-62941d18cdbf33e6)

The user recently bought a batch of 200 poop bags from Amazon for around $10, which has been convenient for walks.[^e-5247029751] ^1ecf2072

[^e-5247029751]: Time: `2023-05`; Sources: [locomo/thread_bb376441501c/msg_ff4264064f14](../../sources/locomo/thread_bb376441501c.md#source-7e33fd17b92c937a)

The user is planning to try a new dog walking route through a nearby park that has a lot of shade and a small pond where Max can get a drink.[^e-8f164d5a0b] ^c50d3009

[^e-8f164d5a0b]: Time: `2023-05-23`; Sources: [locomo/thread_bb376441501c/msg_114b947f2803](../../sources/locomo/thread_bb376441501c.md#source-7c3e92b5894d1328)

The user is considering buying Max durable toys, including a rubber toy that floats in water for fetch in the pond and an interactive treat-dispensing toy that can be filled with treats or peanut butter.[^e-0e09e46266] ^ca4833f1

[^e-0e09e46266]: Time: `2023-05-23`; Sources: [locomo/thread_bb376441501c/msg_b336ce7c40ad](../../sources/locomo/thread_bb376441501c.md#source-520911356138312f), [locomo/thread_bb376441501c/msg_264e6fe14057](../../sources/locomo/thread_bb376441501c.md#source-62941d18cdbf33e6), [locomo/thread_bb376441501c/msg_00f465059b48](../../sources/locomo/thread_bb376441501c.md#source-f321809c2ad2a8d1)

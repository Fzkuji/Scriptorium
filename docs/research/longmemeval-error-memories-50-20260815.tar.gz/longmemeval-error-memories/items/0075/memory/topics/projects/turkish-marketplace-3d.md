# Turkish Marketplace 3D

The user is building a 3D Turkish marketplace and planned its environment assets, including traditional buildings such as mosques and bazaars, market stalls, furniture and decorations, vehicles, people, Turkish food and drink, animals, and landscaping, organized into a JSON asset list.[^e-94b3a9c783] ^419e965f

[^e-94b3a9c783]: Time: `2023-05-26`; Sources: [locomo/thread_774d07d5ad9c/msg_3d961a2ab2a2](../../sources/locomo/thread_774d07d5ad9c.md#source-ac236a878fbf7dc6), [locomo/thread_774d07d5ad9c/msg_7e93d131e318](../../sources/locomo/thread_774d07d5ad9c.md#source-d732a3140b617e09), [locomo/thread_774d07d5ad9c/msg_37f6d8fe146a](../../sources/locomo/thread_774d07d5ad9c.md#source-88b10b91ec04dc53)

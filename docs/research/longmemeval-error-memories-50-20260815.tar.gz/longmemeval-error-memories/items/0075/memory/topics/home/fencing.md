# Fencing

The user is planning new fencing for their rural property and was leaning towards an electric fencing system.[^e-41eef8f2ff] ^8a996d01

[^e-41eef8f2ff]: Time: `2023-05-25`; Sources: [locomo/thread_100ba0195b99/msg_ebd760f46e80](../../sources/locomo/thread_100ba0195b99.md#source-b010eae73e629d10), [locomo/thread_100ba0195b99/msg_8bc4719b42a4](../../sources/locomo/thread_100ba0195b99.md#source-d8856c22efaf2852)

Having a large area to cover, the user considered a solar-powered energizer and planned to use a higher-capacity battery to account for reduced winter sunlight.[^e-2e279a8ef5] ^aee2c29a

[^e-2e279a8ef5]: Time: `2023-05-25`; Sources: [locomo/thread_100ba0195b99/msg_2d726ca3f2c5](../../sources/locomo/thread_100ba0195b99.md#source-45d9f4ca533e3a50), [locomo/thread_100ba0195b99/msg_134d798c49b3](../../sources/locomo/thread_100ba0195b99.md#source-ec3a2b2a70281943)

The user decided to go with high-tensile wire to withstand the elements and animal pressure, asking about the maintenance involved in keeping an electric fencing system running smoothly.[^e-3cf9f53cac] ^777c0629

[^e-3cf9f53cac]: Time: `2023-05-25`; Sources: [locomo/thread_100ba0195b99/msg_292dab1a066d](../../sources/locomo/thread_100ba0195b99.md#source-b4e6daa454973464)

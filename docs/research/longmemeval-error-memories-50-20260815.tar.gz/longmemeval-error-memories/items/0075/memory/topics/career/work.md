# Work & Career

The user started a new job in March 2023, which has been a source of anxiety as they continue adjusting to the new environment and role.[^e-23f6683cc0] ^980d3c83

[^e-23f6683cc0]: Time: `2023-03`; Sources: [locomo/thread_01ea86c3d49e/msg_099b87789e90](../../sources/locomo/thread_01ea86c3d49e.md#source-9753659f08da0f61)

The user committed to a daily routine of focusing on one task at a time to manage work-related stress and avoid feeling overwhelmed, and plans to do meditation and journaling in the evening to unwind.[^e-464c424f32] ^67e5095c

[^e-464c424f32]: Time: `2023-05-25`; Sources: [locomo/thread_01ea86c3d49e/msg_9b96d338f175](../../sources/locomo/thread_01ea86c3d49e.md#source-99ffec8bc9ba20ae), [locomo/thread_01ea86c3d49e/msg_e7e524d0b642](../../sources/locomo/thread_01ea86c3d49e.md#source-eef94db99f377467), [locomo/thread_01ea86c3d49e/msg_71e26acb8c06](../../sources/locomo/thread_01ea86c3d49e.md#source-1408496e554a6289)

The user is feeling stuck in their career and is looking for resources to find a more fulfilling job or career path, including online courses, books, and reflection exercises on career development.[^e-36ae35084b] ^abf0e66e

[^e-36ae35084b]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_f0d74ae50aaa](../../sources/locomo/thread_b6fdc3c2643b.md#source-1c124a978a422942)

The user has been working in the corporate world for over 5 years; while it has provided financial stability, they are not sure it is truly fulfilling and are considering a career transition, exploring whether writing could be a viable career option.[^e-455035687b] ^8de74c79

[^e-455035687b]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_79b1830ae93f](../../sources/locomo/thread_b6fdc3c2643b.md#source-7b1e75cde58993c0)

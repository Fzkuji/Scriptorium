# Car Care & Maintenance

The user received a $50 parking ticket in April 2023, describing it as a pricey reminder to always feed the meter.[^e-9bc76c6899] ^25f7a9cf

[^e-9bc76c6899]: Time: `2023-04`; Sources: [locomo/thread_d5369eec43f1/msg_f4c416079023](../../sources/locomo/thread_d5369eec43f1.md#source-ee51e609c80a9198)

The user is selling their old bike rack online, planning to post it on Craigslist or Facebook Marketplace, and sought tips on taking good photos of it and on estimating its value to price it competitively, including using eBay completed listings, local listings, and bike-specific communities.[^e-229576daaf][^e-856fdbf477] ^e83fc5c4

[^e-229576daaf]: Time: `2023-05-29`; Sources: [locomo/thread_d5369eec43f1/msg_f4c416079023](../../sources/locomo/thread_d5369eec43f1.md#source-ee51e609c80a9198), [locomo/thread_d5369eec43f1/msg_f494b6626eb1](../../sources/locomo/thread_d5369eec43f1.md#source-2ee7d0024a6a5b56)

[^e-856fdbf477]: Time: `2023-05-29`; Sources: [locomo/thread_d5369eec43f1/msg_de327104af40](../../sources/locomo/thread_d5369eec43f1.md#source-dac99eed0b2fe6be)

The user's car has been pulling slightly to the left when driving on the highway, so they plan to get the wheels aligned soon, and learned about signs of misalignment including uneven tire wear, a crooked steering wheel, vibrations while driving, and recent tire replacement.[^e-461b662378][^e-a9d6d0ea76] ^7c2f492c

[^e-461b662378]: Time: `2023-05-29`; Sources: [locomo/thread_d5369eec43f1/msg_0c02aad8863e](../../sources/locomo/thread_d5369eec43f1.md#source-14684dae2d2281d3)

[^e-a9d6d0ea76]: Time: `2023-05-29`; Sources: [locomo/thread_d5369eec43f1/msg_5f2be11711cc](../../sources/locomo/thread_d5369eec43f1.md#source-97af2871c8f557d2), [locomo/thread_d5369eec43f1/msg_df6584837c48](../../sources/locomo/thread_d5369eec43f1.md#source-30508f9f81cde9ff)

The user is planning a full exterior detailing of their car to make it look shiny and new again, starting with a thorough wash and clay bar, and needs to remove stubborn stains and tar spots on the hood, planning to practice with a dual-action polisher on a small area first.[^e-0feed8739a][^e-8ebda2eb4e] ^856d2531

[^e-0feed8739a]: Time: `2023-05-29`; Sources: [locomo/thread_d5369eec43f1/msg_a0d4abf57702](../../sources/locomo/thread_d5369eec43f1.md#source-bfbb3d24e39ec99e)

[^e-8ebda2eb4e]: Time: `2023-05-29`; Sources: [locomo/thread_d5369eec43f1/msg_6b55410d165d](../../sources/locomo/thread_d5369eec43f1.md#source-176b1f755c5f652d), [locomo/thread_d5369eec43f1/msg_bb0e66cb5673](../../sources/locomo/thread_d5369eec43f1.md#source-3803be6d5b358b37)

The user is considering getting a new air freshener for their car and asked about popular brands and scents and for tips on keeping the car smelling fresh and clean.[^e-6262e7a58a] ^f392e9dc

[^e-6262e7a58a]: Time: `2023-05-29`; Sources: [locomo/thread_d5369eec43f1/msg_4f71a4f51c09](../../sources/locomo/thread_d5369eec43f1.md#source-7e0df69b2f157915), [locomo/thread_d5369eec43f1/msg_0e41db8b9c79](../../sources/locomo/thread_d5369eec43f1.md#source-9e2d9b1d6254e860)

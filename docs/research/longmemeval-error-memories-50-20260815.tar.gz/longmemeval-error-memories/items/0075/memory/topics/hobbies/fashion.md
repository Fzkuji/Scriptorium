# Sustainable Fashion

The user wants to support fashion brands that prioritize sustainability and ethical production.[^e-ad53edb5f5] ^e0bc7b0a

[^e-ad53edb5f5]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_6c0a984c5fc6](../../sources/locomo/thread_37d993f7a9d6.md#source-5563975dea57329b)

The user is interested in affordable sustainable clothing brands and looked into Everlane's selection of men's clothing.[^e-e0d6b4616a] ^e698a612

[^e-e0d6b4616a]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_6c0a984c5fc6](../../sources/locomo/thread_37d993f7a9d6.md#source-5563975dea57329b), [locomo/thread_37d993f7a9d6/msg_dfde6a0693d2](../../sources/locomo/thread_37d993f7a9d6.md#source-6069515421af360a)

The user bought a new winter coat at Macy's during the pre-Black Friday sale event with 40% off and a pair of boots with a buy-one-get-one 50% off deal, saving $30 in total, and is now considering getting gloves and a scarf to match.[^e-d3051dc30b][^e-3a3a3a9a97] ^731f0177

[^e-d3051dc30b]: Time: `2023-05-27`; Sources: [locomo/thread_7ad370356362/msg_cf31fbfc2cc1](../../sources/locomo/thread_7ad370356362.md#source-20ae3a1bdecb4216)

[^e-3a3a3a9a97]: Time: `2023-05-27`; Sources: [locomo/thread_7ad370356362/msg_fa994f441834](../../sources/locomo/thread_7ad370356362.md#source-083ef022c95c5910)

The user decided to go with touchscreen-compatible gloves and a scarf with a soft, plush texture, and plans to shop online for winter accessories, including at Macy's website where they will look for sales, clearance sections, bundle deals, and cash back or rewards offers.[^e-270d9abbe2][^e-d611b7d32a][^e-1a9a4e0318] ^8ec78e75

[^e-270d9abbe2]: Time: `2023-05-27`; Sources: [locomo/thread_7ad370356362/msg_d62ca4bce275](../../sources/locomo/thread_7ad370356362.md#source-65bea40fc9fd04f4)

[^e-d611b7d32a]: Time: `2023-05-27`; Sources: [locomo/thread_7ad370356362/msg_4690d0ff07cd](../../sources/locomo/thread_7ad370356362.md#source-72dda7e8710e58c9)

[^e-1a9a4e0318]: Time: `2023-05-27`; Sources: [locomo/thread_7ad370356362/msg_48aacfc7cd5d](../../sources/locomo/thread_7ad370356362.md#source-47d2f82c5726925b)

The user has been using the RetailMeNot app to find coupons and promo codes, which has saved them around $50 over the past few months on purchases from various retailers, and plans to use it to find deals on winter accessories, including at Macy's.[^e-b606ff92f3][^e-5d8d213758] ^530045e6

[^e-b606ff92f3]: Time: `2023-05-27`; Sources: [locomo/thread_7ad370356362/msg_37a8ed176ced](../../sources/locomo/thread_7ad370356362.md#source-fcb254a2d25d6a29)

[^e-5d8d213758]: Time: `2023-05-27`; Sources: [locomo/thread_7ad370356362/msg_ea7646ca78b8](../../sources/locomo/thread_7ad370356362.md#source-85dbb7853648edf3), [locomo/thread_7ad370356362/msg_2b7efd389e24](../../sources/locomo/thread_7ad370356362.md#source-8ba640741ca71e59)

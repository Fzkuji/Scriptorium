# Board Games

The user plays board games and recently enjoyed Settlers of Catan at a board game meetup at a local game store, learning strategies from other players such as clever resource trading and building near good resources.[^e-32dcf0f75d] ^87f3d0e9

[^e-32dcf0f75d]: Time: `2023-05-24`; Sources: [locomo/thread_14f6bc69bb92/msg_85e2fa90cef9](../../sources/locomo/thread_14f6bc69bb92.md#source-907542218edfbb75), [locomo/thread_14f6bc69bb92/msg_40249297a064](../../sources/locomo/thread_14f6bc69bb92.md#source-1001eb0c5d07d83e)

The user is interested in cooperative games and is considering trying Pandemic as their first cooperative game, as well as Forbidden Island and Forbidden Desert.[^e-8bd850d748] ^e98737ba

[^e-8bd850d748]: Time: `2023-05-24`; Sources: [locomo/thread_14f6bc69bb92/msg_ad9ff0d6af6b](../../sources/locomo/thread_14f6bc69bb92.md#source-dc9853581dd70d00), [locomo/thread_14f6bc69bb92/msg_5a0b4cc9e66e](../../sources/locomo/thread_14f6bc69bb92.md#source-4a29a65ca2f337dd)

The user is exploring online board game communities such as Board Game Geek and r/boardgames, and plans to return to the local game store they found welcoming, which had a large game library, knowledgeable staff, and snacks and drinks.[^e-15e3dee959] ^84b2aa89

[^e-15e3dee959]: Time: `2023-05-24`; Sources: [locomo/thread_14f6bc69bb92/msg_7e8e9e9d838f](../../sources/locomo/thread_14f6bc69bb92.md#source-38b12238576c0865), [locomo/thread_14f6bc69bb92/msg_ef96b87b06ca](../../sources/locomo/thread_14f6bc69bb92.md#source-61e9c221291303e7), [locomo/thread_14f6bc69bb92/msg_40249297a064](../../sources/locomo/thread_14f6bc69bb92.md#source-1001eb0c5d07d83e)

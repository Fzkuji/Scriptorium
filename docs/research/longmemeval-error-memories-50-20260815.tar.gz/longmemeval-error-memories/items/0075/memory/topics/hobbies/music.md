# Music

The user is learning music programming and has been working with arrays in ChucK.[^e-87388e0357] ^ed66fda4

[^e-87388e0357]: Time: `2023-05-21`; Sources: [locomo/thread_cbcd98836154/msg_4efa0dd0ad5d](../../sources/locomo/thread_cbcd98836154.md#source-d36bc6e70ac12196), [locomo/thread_cbcd98836154/msg_8efa0e8abaf5](../../sources/locomo/thread_cbcd98836154.md#source-ecffe79b3060cdbc)

After comparing beginner-friendly options, the user decided to start with Sonic Pi, a free, open-source live-coding environment for creating music.[^e-59d0a1f5dc] ^d6a65c6b

[^e-59d0a1f5dc]: Time: `2023-05-21`; Sources: [locomo/thread_cbcd98836154/msg_d525919619ba](../../sources/locomo/thread_cbcd98836154.md#source-6e85589557e4cc39), [locomo/thread_cbcd98836154/msg_6aa0279dcf94](../../sources/locomo/thread_cbcd98836154.md#source-8761e1d7fb10ed5e)

The user is setting up a music room in their garage and sought advice on soundproofing it, including sealing gaps and cracks, adding mass, decoupling and isolation, and treating the ceiling.[^e-01454d62f8] ^df5b43e8

[^e-01454d62f8]: Time: `2023-05-23`; Sources: [locomo/thread_5623a6557221/msg_aa8874e72af8](../../sources/locomo/thread_5623a6557221.md#source-69a42660a73a7919), [locomo/thread_5623a6557221/msg_ab1536172a10](../../sources/locomo/thread_5623a6557221.md#source-b047ece1aff1df06)

The user plans to sell their old Fender Deluxe 90 guitar amp and is also considering selling their Yamaha PSR-E263 keyboard, and was advised to sell the two items separately since they appeal to different buyers.[^e-a7ce4223f3] ^a925bbc2

[^e-a7ce4223f3]: Time: `2023-05-23`; Sources: [locomo/thread_5623a6557221/msg_04f911880f68](../../sources/locomo/thread_5623a6557221.md#source-feac40c29701a587), [locomo/thread_5623a6557221/msg_1ba1e9ca8f74](../../sources/locomo/thread_5623a6557221.md#source-b3179bdecb7e1f42), [locomo/thread_5623a6557221/msg_f26bd4df9fde](../../sources/locomo/thread_5623a6557221.md#source-587407e4739446c4)

The user has been playing their ukulele a lot lately, planning to record a first video of themselves playing it in the new music room using their new Kala KA-CE15S ukulele and their phone's camera.[^e-2e5c0f0ad7] ^d1ce3fe7

[^e-2e5c0f0ad7]: Time: `2023-05-23`; Sources: [locomo/thread_5623a6557221/msg_e1c7efab79a0](../../sources/locomo/thread_5623a6557221.md#source-8279591945f442ea), [locomo/thread_5623a6557221/msg_76f2ebf48b74](../../sources/locomo/thread_5623a6557221.md#source-2c6aa351cbcfb665)

The user is interested in contemporary jazz, particularly double bass players, and asked about the top contemporary jazz bassists, learning about Esperanza Spalding, Christian McBride, and John Patitucci and their notable albums.[^e-6ff6ef136b] ^d2806744

[^e-6ff6ef136b]: Time: `2023-05-25`; Sources: [locomo/thread_aaa7a92208f6/msg_8b3dc879fb94](../../sources/locomo/thread_aaa7a92208f6.md#source-102bf208edd54a78), [locomo/thread_aaa7a92208f6/msg_f6fae4c00dfe](../../sources/locomo/thread_aaa7a92208f6.md#source-44823ba473b45d8c), [locomo/thread_aaa7a92208f6/msg_d775b76e59a0](../../sources/locomo/thread_aaa7a92208f6.md#source-00354b3efdd90ed0), [locomo/thread_aaa7a92208f6/msg_47a8a6a34e5a](../../sources/locomo/thread_aaa7a92208f6.md#source-2ebd1848184c96fa), [locomo/thread_aaa7a92208f6/msg_36450f4424a0](../../sources/locomo/thread_aaa7a92208f6.md#source-346d40c6a750cb5d)

The user explored how the COVID-19 pandemic affected the music industry, including the shift to online concerts and live-streamed performances, the industry's recovery plans, and successful examples such as One World: Together At Home, VERZUZ battles, NPR's Tiny Desk (Home) Concerts, BTS's virtual concerts, and DJ D-Nice's Club Quarantine.[^e-d222635a75] ^bf148118

[^e-d222635a75]: Time: `2023-05-26`; Sources: [locomo/thread_ae05743e8c30/msg_b2d0ad460ac7](../../sources/locomo/thread_ae05743e8c30.md#source-aee41b66d1562ee0), [locomo/thread_ae05743e8c30/msg_336ee2792c91](../../sources/locomo/thread_ae05743e8c30.md#source-806a29acfd8c7483), [locomo/thread_ae05743e8c30/msg_cb704212b8ec](../../sources/locomo/thread_ae05743e8c30.md#source-a4b7adbcaf547cd2)

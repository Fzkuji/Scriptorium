# Wildlife Conservation

The user learned about the efforts to restore the natural habitats of animals affected by the Australian bushfires, including providing food and water, building artificial homes such as nest boxes for birds and burrows for small mammals, planting native vegetation, creating vegetation corridors, and capturing and treating injured animals; they also learned that some estimates suggest nearly three billion animals were affected by the bushfires.[^e-af065a8f48] ^cacbda97

[^e-af065a8f48]: Time: `2023-05-30`; Sources: [locomo/thread_17e63281815b/msg_247a45632acc](../../sources/locomo/thread_17e63281815b.md#source-cc20c44970b8f482), [locomo/thread_17e63281815b/msg_4fe011405b06](../../sources/locomo/thread_17e63281815b.md#source-47824c1a99339dd8), [locomo/thread_17e63281815b/msg_29c0f716130a](../../sources/locomo/thread_17e63281815b.md#source-2c5a12802497302b)

The user decided to donate to organizations leading Australian bushfire restoration efforts, including WWF Australia's Bushfire Emergency Fund, WIRES, the Australian Conservation Foundation, and Birds in Backyards.[^e-1fa5b46341] ^27444641

[^e-1fa5b46341]: Time: `2023-05-30`; Sources: [locomo/thread_17e63281815b/msg_022f5abb1482](../../sources/locomo/thread_17e63281815b.md#source-c213fc69126e3e38), [locomo/thread_17e63281815b/msg_c502c94679e3](../../sources/locomo/thread_17e63281815b.md#source-1f54ed94148cb8f2), [locomo/thread_17e63281815b/msg_e8e70b5f7225](../../sources/locomo/thread_17e63281815b.md#source-083e7e8fa9794e49)

The user discussed measures to reduce the intensity and spread of future bushfires, including reducing fuel load, managing forests, raising fire safety awareness, monitoring changing weather, and using firefighting technology.[^e-a5cc35671b] ^da28e022

[^e-a5cc35671b]: Time: `2023-05-30`; Sources: [locomo/thread_17e63281815b/msg_bf6b245cba15](../../sources/locomo/thread_17e63281815b.md#source-7ad46aa811e4a058), [locomo/thread_17e63281815b/msg_11fe143afc8c](../../sources/locomo/thread_17e63281815b.md#source-665a47ebd051268c)

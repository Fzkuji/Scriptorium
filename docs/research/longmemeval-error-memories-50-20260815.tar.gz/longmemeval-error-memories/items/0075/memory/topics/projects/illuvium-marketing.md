# Illuvium Influencer Marketing

The user asked for an influencer marketing strategy for the triple-A web3 video game "Illuvium" that concentrates on targeting influencers and audiences outside the web3 sphere.[^e-98881bbff7] ^c521eff8

[^e-98881bbff7]: Time: `2023-05-27`; Sources: [locomo/thread_e75d517f7f0b/msg_73995c263c38](../../sources/locomo/thread_e75d517f7f0b.md#source-bcee965ff0e9b62f)

The suggested strategy involved identifying influencers in the gaming industry interested in web3, building relationships with them through early access, creating and amplifying content, monitoring and analyzing results, targeting audiences outside the web3 sphere, and cross-promoting with other web3 projects.[^e-66b37f1288] ^23ef226a

[^e-66b37f1288]: Time: `2023-05-27`; Sources: [locomo/thread_e75d517f7f0b/msg_aff28aa33f74](../../sources/locomo/thread_e75d517f7f0b.md#source-2c5ce1b700b7181f)

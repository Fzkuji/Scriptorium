# College Roommate

The user plans to attend their college roommate's son's graduation party next month and is considering gift ideas for the graduate.[^e-37b2fc4221] ^45f8c26b

[^e-37b2fc4221]: Time: `2023-06`; Sources: [locomo/thread_6e68d84c9eb7/msg_a6c25b17a85a](../../sources/locomo/thread_6e68d84c9eb7.md#source-8267e5a813efb80b)

The user decided to create a scrapbook or photo album showcasing their own college experiences as a graduation gift, using scanned old photos organized chronologically with captions highlighting academic achievements, friendships, and memorable moments, along with inspirational quotes, humorous anecdotes, and possibly a personal message or letter to the graduate.[^e-52d0b671e8][^e-3bcabee98c][^e-ebf7e2b8ce] ^b3c1b7c3

[^e-52d0b671e8]: Time: `2023-05-29`; Sources: [locomo/thread_6e68d84c9eb7/msg_4d513b056e22](../../sources/locomo/thread_6e68d84c9eb7.md#source-e64311435136cbcc), [locomo/thread_6e68d84c9eb7/msg_a99152459ad4](../../sources/locomo/thread_6e68d84c9eb7.md#source-81fc42ed4d073dc4)

[^e-3bcabee98c]: Time: `2023-05-29`; Sources: [locomo/thread_6e68d84c9eb7/msg_1fab79136f44](../../sources/locomo/thread_6e68d84c9eb7.md#source-5643e759585a8ef4), [locomo/thread_6e68d84c9eb7/msg_c0d6ed850ace](../../sources/locomo/thread_6e68d84c9eb7.md#source-f06f36d4263176b3)

[^e-ebf7e2b8ce]: Time: `2023-05-29`; Sources: [locomo/thread_6e68d84c9eb7/msg_378f0790ac4e](../../sources/locomo/thread_6e68d84c9eb7.md#source-f9d4760837380ca5), [locomo/thread_6e68d84c9eb7/msg_34778fcf6dc7](../../sources/locomo/thread_6e68d84c9eb7.md#source-1093e75f3a2d5149)

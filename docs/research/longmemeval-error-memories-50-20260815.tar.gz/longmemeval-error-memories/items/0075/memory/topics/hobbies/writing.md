# Writing

The user is interested in narrative craft and sought advice on weaving characters' backstories and flashbacks into a narrative without disrupting the flow or confusing readers; the guidance covered determining the purpose of each flashback, using clear transitions, avoiding info-dumps, keeping flashbacks relevant, and making them interesting.[^e-f7d0acefd6] ^f6d96e18

[^e-f7d0acefd6]: Time: `2023-05-24`; Sources: [locomo/thread_782f9c17d73c/msg_fff52c1ad2fa](../../sources/locomo/thread_782f9c17d73c.md#source-7b57767aa105eb5b)

While exploring how backstories and flashbacks are handled in books and films, the user has read "The Handmaid's Tale" and "The Kite Runner" and watched "The Godfather", "Forrest Gump", and "A Star is Born", and planned to check out recommended works including "One Hundred Years of Solitude", "The Midnight Library", "House of Cards", "Westworld", and "Before We Were Yours".[^e-7758be1b88] ^2c9d70ee

[^e-7758be1b88]: Time: `2023-05-24`; Sources: [locomo/thread_782f9c17d73c/msg_0e1990088149](../../sources/locomo/thread_782f9c17d73c.md#source-4c6e9b979aae1078), [locomo/thread_782f9c17d73c/msg_c12d70257935](../../sources/locomo/thread_782f9c17d73c.md#source-5e8321495a35e8c0), [locomo/thread_782f9c17d73c/msg_a8c1d09a04d8](../../sources/locomo/thread_782f9c17d73c.md#source-c782b9578cf4f536), [locomo/thread_782f9c17d73c/msg_1f6919e8ee98](../../sources/locomo/thread_782f9c17d73c.md#source-e8d792ab980755e5)

The user considers the TV show This Is Us to be an excellent example of weaving flashbacks and backstories into an emotional narrative.[^e-532c20f290] ^a399738d

[^e-532c20f290]: Time: `2023-05-24`; Sources: [locomo/thread_782f9c17d73c/msg_dae89357106a](../../sources/locomo/thread_782f9c17d73c.md#source-6dcc4e3ed3390538)

The user is a beginner interested in taking a writing course and asked for recommendations on online resources or courses suitable for beginners.[^e-4e0a80762c] ^e5165d67

[^e-4e0a80762c]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_7679159943d0](../../sources/locomo/thread_b6fdc3c2643b.md#source-ea454525e1b4f702)

The user is thinking about pursuing fiction writing and, though unsure about whether they could make a living from it, is willing to put in the time and effort to develop their craft and see if they can produce quality work; they have already started writing short stories and experimenting with different styles.[^e-4d3972bccb][^e-a90f3332bd] ^59d359d9

[^e-4d3972bccb]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_b219c71099df](../../sources/locomo/thread_b6fdc3c2643b.md#source-a93d559dd0b53b50)

[^e-a90f3332bd]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_e77022dc0d54](../../sources/locomo/thread_b6fdc3c2643b.md#source-3a03cff87f73f1c6)

The user weighed the pros and cons of focusing on a specific genre, such as fantasy or romance, versus writing across different genres, and planned to take an online course or attend a writing workshop to learn more about the industry and get feedback on their work before deciding.[^e-2d07d7eabb][^e-85884c08a5][^e-369cbc25ea] ^7b3dfdc9

[^e-2d07d7eabb]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_97a142d92e39](../../sources/locomo/thread_b6fdc3c2643b.md#source-e970f583b2f37866)

[^e-85884c08a5]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_051c3dbc49ff](../../sources/locomo/thread_b6fdc3c2643b.md#source-92acb03cae2f997a)

[^e-369cbc25ea]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_34fc35f752e8](../../sources/locomo/thread_b6fdc3c2643b.md#source-19583c1d87da52ff)

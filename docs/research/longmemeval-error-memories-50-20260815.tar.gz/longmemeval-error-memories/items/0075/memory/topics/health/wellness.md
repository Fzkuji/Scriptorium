# Health & Wellness

The user is easing back into their fitness routine after a few months of dealing with health issues and sought gentle at-home exercises to improve their flexibility.[^e-5ad97b102b] ^a3227697

[^e-5ad97b102b]: Time: `2023-05-25`; Sources: [locomo/thread_810c4bac6d0f/msg_40ebc5271110](../../sources/locomo/thread_810c4bac6d0f.md#source-9f03b52650c20a1d)

The user recently had a bad case of bronchitis that they initially thought was just a cold.[^e-34b814b2d7] ^b8fefc8e

[^e-34b814b2d7]: Time: `2023-05`; Sources: [locomo/thread_810c4bac6d0f/msg_b37ea7a6bf63](../../sources/locomo/thread_810c4bac6d0f.md#source-6b07b0c35f407343)

The user has started taking yoga classes on Saturday mornings, which have helped calm their mind and improve their flexibility, and has been cooking more meals at home and cutting back on processed foods to boost their immune system in the long run.[^e-7604cd7adc] ^59fee3b8

[^e-7604cd7adc]: Time: `2023-05`; Sources: [locomo/thread_810c4bac6d0f/msg_2f8a85df49fb](../../sources/locomo/thread_810c4bac6d0f.md#source-f669b521a9f819bb)

The user is thinking of starting a journal to track their progress and reflect on their thoughts and feelings.[^e-c93917cc29] ^dc9fe1d8

[^e-c93917cc29]: Time: `2023-05-25`; Sources: [locomo/thread_810c4bac6d0f/msg_f91bb19ddb67](../../sources/locomo/thread_810c4bac6d0f.md#source-83c02a13a2357013)

The user is excited to start a meditation and journaling practice in the evening, looking forward to feeling more relaxed and in control of their thoughts and emotions, though concerned about not being able to quiet their mind during meditation; they hope the practice will help them manage stress and anxiety from their new job and feel more confident and competent.[^e-8dd73bcbd5] ^368d06d5

[^e-8dd73bcbd5]: Time: `2023-05-25`; Sources: [locomo/thread_01ea86c3d49e/msg_1aaac318d583](../../sources/locomo/thread_01ea86c3d49e.md#source-263d30c5992363ee)

# Long-Distance Relationship

The user is working to rebuild trust in a long-distance relationship after a breach of trust such as infidelity or deception, and sought advice on open and honest communication, apology, time and patience, consistency, forgiveness, and counseling.[^e-882584c6d1] ^196b9d36

[^e-882584c6d1]: Time: `2023-05-30`; Sources: [locomo/thread_3521d895e8f1/msg_1e432e7b3717](../../sources/locomo/thread_3521d895e8f1.md#source-824441a91d87faf5), [locomo/thread_3521d895e8f1/msg_2468bcfaa96e](../../sources/locomo/thread_3521d895e8f1.md#source-89a9126efd6e19bd)

The user feels overwhelmed by the difficult conversations involved in rebuilding trust and worries that their partner might not be fully committed to the process, but is determined to stay calm and focus on rebuilding the relationship.[^e-db0ce94f42] ^cfa1b93e

[^e-db0ce94f42]: Time: `2023-05-30`; Sources: [locomo/thread_3521d895e8f1/msg_4858343ec15f](../../sources/locomo/thread_3521d895e8f1.md#source-de08df2cc5b1d139), [locomo/thread_3521d895e8f1/msg_880ed7581f47](../../sources/locomo/thread_3521d895e8f1.md#source-5f335901447f8e6d), [locomo/thread_3521d895e8f1/msg_9c13ba260a15](../../sources/locomo/thread_3521d895e8f1.md#source-3d970793af66ce47)

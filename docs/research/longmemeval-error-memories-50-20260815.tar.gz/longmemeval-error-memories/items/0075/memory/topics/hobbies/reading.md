# Reading

The user is getting back into reading graphic novels and enjoys Saga by Brian K. Vaughan and Fiona Staples.[^e-ae43a5327d] ^91d6db37

[^e-ae43a5327d]: Time: `2023-05-22`; Sources: [locomo/thread_f4407b5e69a3/msg_b7e48307cffc](../../sources/locomo/thread_f4407b5e69a3.md#source-feeae438fd5ea0c5)

The user started reading "The Seven Husbands of Evelyn Hugo" by Taylor Jenkins Reid on 2023-01-29 and has been loving its character development.[^e-c2af54ca68] ^630acdd6

[^e-c2af54ca68]: Time: `2023-01-29`; Sources: [locomo/thread_f4407b5e69a3/msg_b7e48307cffc](../../sources/locomo/thread_f4407b5e69a3.md#source-feeae438fd5ea0c5), [locomo/thread_f4407b5e69a3/msg_4c55976ef78e](../../sources/locomo/thread_f4407b5e69a3.md#source-5c9eed9aa4fa74fa)

The user was drawn into the book by the way the characters are all interconnected and by Evelyn's backstory as a Cuban immigrant, and is curious to see how the rest of the story unfolds, especially the mystery surrounding her husbands.[^e-09b2299a29] ^8dbe44af

[^e-09b2299a29]: Time: `2023-05-22`; Sources: [locomo/thread_f4407b5e69a3/msg_255d528a32f4](../../sources/locomo/thread_f4407b5e69a3.md#source-32adf334dc723fa7)

The user thinks Monique, the journalist writing Evelyn's biography, is a great narrator because she is not just a passive listener but an active participant in uncovering Evelyn's secrets, and her own life and biases influence her perceptions of Evelyn and her story.[^e-9c551a024f] ^d87f1bea

[^e-9c551a024f]: Time: `2023-05-22`; Sources: [locomo/thread_f4407b5e69a3/msg_e1bb2f87354c](../../sources/locomo/thread_f4407b5e69a3.md#source-11958cf40bbc4e48)

The user resonates with the book's exploration of identity, agreeing that everyone has public and private selves that can feel in conflict, and noting that Evelyn's identity is intersectional, shaped by her experiences as a woman, a Latina, and an immigrant.[^e-af6892fe04] ^68f9332e

[^e-af6892fe04]: Time: `2023-05-22`; Sources: [locomo/thread_f4407b5e69a3/msg_98493d57f0de](../../sources/locomo/thread_f4407b5e69a3.md#source-30df1c1628335d2d)

The user considers the portrayal of relationships between women one of the book's strongest aspects, noting that female relationships can be both supportive and competitive, loving and complicated, and that Evelyn's relationships with Celia, Monique, and Lucy are central to her life and identity.[^e-f7782a0e90] ^5f7fc171

[^e-f7782a0e90]: Time: `2023-05-22`; Sources: [locomo/thread_f4407b5e69a3/msg_3c6f6cbb4613](../../sources/locomo/thread_f4407b5e69a3.md#source-f0f7d5b0d1420a9b)

The user enjoys contemporary fiction featuring strong female protagonists and complex relationships, and asked for recommendations similar to "The Seven Husbands of Evelyn Hugo".[^e-4e0d031962] ^b1150357

[^e-4e0d031962]: Time: `2023-05-22`; Sources: [locomo/thread_f4407b5e69a3/msg_4c55976ef78e](../../sources/locomo/thread_f4407b5e69a3.md#source-5c9eed9aa4fa74fa)

The user has been getting into literary fiction, was drawn to authors such as Isabel Allende and Celeste Ng, and is looking for online book clubs or forums to discuss literary fiction with fellow readers.[^e-35967ab698] ^2e6fec8d

[^e-35967ab698]: Time: `2023-05-24`; Sources: [locomo/thread_2722126b02ae/msg_89c8fca8566c](../../sources/locomo/thread_2722126b02ae.md#source-ad3343c88e9e397f), [locomo/thread_2722126b02ae/msg_7f3100be9a74](../../sources/locomo/thread_2722126b02ae.md#source-da4ff7e4d1994078)

The user previously participated in an online book club for "The Seven Husbands of Evelyn Hugo" by Taylor Jenkins Reid and, for literary fiction discussions, plans to explore Goodreads and The Rumpus Book Club.[^e-3eb1afc8ef] ^4330b6d1

[^e-3eb1afc8ef]: Time: `2023-05-24`; Sources: [locomo/thread_2722126b02ae/msg_cd7648ea9f34](../../sources/locomo/thread_2722126b02ae.md#source-229df720b23033c6), [locomo/thread_2722126b02ae/msg_2ad050adc24d](../../sources/locomo/thread_2722126b02ae.md#source-feffdcb20980130f)

# Home Technology

The user set up a device on 2023-02-10 that allows them to control the temperature from their phone, describing it as a game-changer for their home's temperature management.[^e-adb314f3a4] ^9e498752

[^e-adb314f3a4]: Time: `2023-02-10`; Sources: [locomo/thread_551cc7f69a7b/msg_d43837dfd41b](../../sources/locomo/thread_551cc7f69a7b.md#source-8856a15964658c57)

The user has a new router, which they got on 2023-01-15.[^e-8af875ecde] ^e928cc5c

[^e-8af875ecde]: Time: `2023-01-15`; Sources: [locomo/thread_551cc7f69a7b/msg_aef5f2dcbddd](../../sources/locomo/thread_551cc7f69a7b.md#source-9439fe0e2fd6bf2e)

The user was considering setting up a guest network feature on their new router and asked for tips on how to do it.[^e-fd0900213f] ^2af6e125

[^e-fd0900213f]: Time: `2023-05-30`; Sources: [locomo/thread_551cc7f69a7b/msg_e139ce4b11ca](../../sources/locomo/thread_551cc7f69a7b.md#source-ddd957ae3225c8f0), [locomo/thread_551cc7f69a7b/msg_ad5831107b0a](../../sources/locomo/thread_551cc7f69a7b.md#source-79ebca4f00712c52)

The user ordered cable organizers online on 2023-01-28 to tidy up the messy cords and cables at home, but they had not arrived yet as of the conversation.[^e-d0025ec7c4] ^977f4868

[^e-d0025ec7c4]: Time: `2023-01-28`; Sources: [locomo/thread_551cc7f69a7b/msg_9b9ea2c8d118](../../sources/locomo/thread_551cc7f69a7b.md#source-7615a980a7a5d553)

After an incident on 2023-02-01 when their laptop would not turn on, the user wanted to back up their laptop files more regularly and asked for tips on setting up a backup system.[^e-3613d05092] ^103a7480

[^e-3613d05092]: Time: `2023-02-01`; Sources: [locomo/thread_551cc7f69a7b/msg_846688edaf64](../../sources/locomo/thread_551cc7f69a7b.md#source-bde6abc7a110fe96)

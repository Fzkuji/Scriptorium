# Budgeting & Spending

The user wants to get a better handle on their spending habits and started tracking their expenses, categorizing them by type such as clothing and groceries.[^e-8a11f27b96] ^3c92056b

[^e-8a11f27b96]: Time: `2023-05-29`; Sources: [locomo/thread_0e19af4ae30e/msg_b4f6e84e043d](../../sources/locomo/thread_0e19af4ae30e.md#source-4ee21c9138302131), [locomo/thread_0e19af4ae30e/msg_7da145852733](../../sources/locomo/thread_0e19af4ae30e.md#source-fc94e147cf7764ed)

The user recognized that they oscillate between luxury and budget shopping for clothing and set up separate luxury versus budget subcategories within the clothing category to make more intentional decisions, and recently splurged on a designer handbag at Saks Fifth Avenue.[^e-43ecf3e980][^e-d0562c9deb] ^0541ab6e

[^e-43ecf3e980]: Time: `2023-05-29`; Sources: [locomo/thread_0e19af4ae30e/msg_a70fba142d4f](../../sources/locomo/thread_0e19af4ae30e.md#source-474b7c6298ba732c), [locomo/thread_0e19af4ae30e/msg_d7ca8f0198eb](../../sources/locomo/thread_0e19af4ae30e.md#source-537201c0d187d409)

[^e-d0562c9deb]: Time: `2023-05-27`; Sources: [locomo/thread_0e19af4ae30e/msg_a70fba142d4f](../../sources/locomo/thread_0e19af4ae30e.md#source-474b7c6298ba732c)

The user has been trying to shop more budget-friendly for groceries by buying in bulk and using coupons, but still splurges on luxury food items from time to time and wants to save money on groceries without sacrificing quality.[^e-254f4282cd] ^1ea3bdb2

[^e-254f4282cd]: Time: `2023-05-29`; Sources: [locomo/thread_0e19af4ae30e/msg_2845b08c6a5f](../../sources/locomo/thread_0e19af4ae30e.md#source-df9f7f8a2f888e95)

The user likes the idea of meal planning and prep and has been meaning to try it out to help reduce grocery spending and food waste, asking for guidance and support to get started.[^e-38286dd6bc][^e-b855b64209] ^0327a4ea

[^e-38286dd6bc]: Time: `2023-05-29`; Sources: [locomo/thread_0e19af4ae30e/msg_baccc5682ef9](../../sources/locomo/thread_0e19af4ae30e.md#source-a0c38c5ca7073aac)

[^e-b855b64209]: Time: `2023-05-29`; Sources: [locomo/thread_0e19af4ae30e/msg_f4dd7c7ed74b](../../sources/locomo/thread_0e19af4ae30e.md#source-e0b9c048f9251d32), [locomo/thread_0e19af4ae30e/msg_93ec9a859a1b](../../sources/locomo/thread_0e19af4ae30e.md#source-d511ae71bd1138c9)

The user asked about apps and tools to track their grocery spending and stay within their budget, and explored budgeting templates and spreadsheets, such as those in Google Sheets or Microsoft Excel, for tracking grocery spending.[^e-6c09fae3d7][^e-7cc2c9cb17] ^6de13406

[^e-6c09fae3d7]: Time: `2023-05-29`; Sources: [locomo/thread_0e19af4ae30e/msg_baccc5682ef9](../../sources/locomo/thread_0e19af4ae30e.md#source-a0c38c5ca7073aac), [locomo/thread_0e19af4ae30e/msg_73d77f622cfc](../../sources/locomo/thread_0e19af4ae30e.md#source-712b4ea500f8d660)

[^e-7cc2c9cb17]: Time: `2023-05-29`; Sources: [locomo/thread_0e19af4ae30e/msg_90da418bba32](../../sources/locomo/thread_0e19af4ae30e.md#source-400418c871cf83f3), [locomo/thread_0e19af4ae30e/msg_b257cdcf1fdc](../../sources/locomo/thread_0e19af4ae30e.md#source-ed00d35ace83f1e1)

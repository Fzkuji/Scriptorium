# Art & Exhibitions

The user attended a gallery opening at the Contemporary Art Space in October 2022 that featured a renowned artist and spent over two hours there taking it all in.[^e-fcaf15bae9] ^0bdcf564

[^e-fcaf15bae9]: Time: `2022-10`; Sources: [locomo/thread_987adb9e3384/msg_49916e9f133b](../../sources/locomo/thread_987adb9e3384.md#source-3476c113605b1c56)

The user is particularly interested in emerging artists and plans to look into local artist networks and collectives.[^e-26ffb5789a] ^1a9f327f

[^e-26ffb5789a]: Time: `2023-05-23`; Sources: [locomo/thread_987adb9e3384/msg_cedd23a82653](../../sources/locomo/thread_987adb9e3384.md#source-a01f1646c2b15630)

The user plans to explore online platforms that focus on contemporary art and emerging artists, including Artsy, Saatchi Art, Artspace, and Uprise Art.[^e-c38f5e9136] ^32f83317

[^e-c38f5e9136]: Time: `2023-05-23`; Sources: [locomo/thread_987adb9e3384/msg_93ccddf82484](../../sources/locomo/thread_987adb9e3384.md#source-24da4a402bb04a09), [locomo/thread_987adb9e3384/msg_f9630cd69044](../../sources/locomo/thread_987adb9e3384.md#source-482b57b767e06b70), [locomo/thread_987adb9e3384/msg_860def65ef76](../../sources/locomo/thread_987adb9e3384.md#source-57d135f1603352ec), [locomo/thread_987adb9e3384/msg_3bb059d845a8](../../sources/locomo/thread_987adb9e3384.md#source-79c2bf60832ee966)

At the "Contemporary Art Exhibition" at the Modern Art Museum, the user saw installations and paintings by emerging artists, including Sarah Johnson, who showcased a thought-provoking installation on climate change.[^e-9d37430068] ^36becd13

[^e-9d37430068]: Time: `undated`; Sources: [locomo/thread_987adb9e3384/msg_93ccddf82484](../../sources/locomo/thread_987adb9e3384.md#source-24da4a402bb04a09)

The user has been learning about Midjourney image generation parameters, including seeds (--seed and --sameseed), --stop, and --stylize, and asked to have the parameter documentation organized into tables.[^e-fb5cdb4d35] ^7a21ad93

[^e-fb5cdb4d35]: Time: `2023-05-26`; Sources: [locomo/thread_22a07b103833/msg_b625ff29c59f](../../sources/locomo/thread_22a07b103833.md#source-025edd7557cacace), [locomo/thread_22a07b103833/msg_fdf24b7882b4](../../sources/locomo/thread_22a07b103833.md#source-c5eb0bf4c2b72ead)

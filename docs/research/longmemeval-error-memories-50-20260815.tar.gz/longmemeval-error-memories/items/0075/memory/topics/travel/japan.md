# Japan Travel

The user traveled to Japan and stayed in an Airbnb in the Shibuya area of Tokyo; on 2023-05-30 they checked out of their Airbnb and headed to Narita Airport for their return flight to the US.[^e-f14f8927aa] ^42209ca6

[^e-f14f8927aa]: Time: `2023-05-30`; Sources: [locomo/thread_63a836c4c904/msg_42372b5670ff](../../sources/locomo/thread_63a836c4c904.md#source-1083c48cfc3288ad), [locomo/thread_63a836c4c904/msg_8086506981b8](../../sources/locomo/thread_63a836c4c904.md#source-2bc7416aa68e6d7c)

The user asked about the current US dollar to Japanese yen exchange rate and about US customs declaration requirements when returning to the US.[^e-afa32a5256] ^4e733b12

[^e-afa32a5256]: Time: `2023-05-30`; Sources: [locomo/thread_63a836c4c904/msg_42372b5670ff](../../sources/locomo/thread_63a836c4c904.md#source-1083c48cfc3288ad), [locomo/thread_63a836c4c904/msg_a64cf7010e37](../../sources/locomo/thread_63a836c4c904.md#source-997864e2f1071ead)

The user planned to take the Narita Express (N'EX) from Tokyo Station to Narita Airport for the return journey, chose to reserve their seat online, and asked about the power outlets available on the train.[^e-e8ac74f3d5] ^c6dc8e04

[^e-e8ac74f3d5]: Time: `2023-05-30`; Sources: [locomo/thread_63a836c4c904/msg_caaae9351576](../../sources/locomo/thread_63a836c4c904.md#source-3eb60f5d5f62e28a), [locomo/thread_63a836c4c904/msg_8fa4dd0aa8a4](../../sources/locomo/thread_63a836c4c904.md#source-4fa3af731013de77), [locomo/thread_63a836c4c904/msg_f6cf033e5b31](../../sources/locomo/thread_63a836c4c904.md#source-79ef8591aa3d3bd5)

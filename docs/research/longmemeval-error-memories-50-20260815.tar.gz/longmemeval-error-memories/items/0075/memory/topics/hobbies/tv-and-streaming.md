# TV & Streaming

The user has watched "Stranger Things" and "Narcos", and has also seen "The Haunting of Hill House" and "Breaking Bad".[^e-edf4d4a0d4] ^35126c5d

[^e-edf4d4a0d4]: Time: `2023-05-29`; Sources: [locomo/thread_d7ef2bcadc43/msg_6e7dcb803047](../../sources/locomo/thread_d7ef2bcadc43.md#source-d7e974963db3cfe9), [locomo/thread_d7ef2bcadc43/msg_1ca767639772](../../sources/locomo/thread_d7ef2bcadc43.md#source-aaa80229ca9fe769)

The user is interested in space and astronomy documentaries and cited "When We Left Earth: The NASA Missions" as a documentary series they have really been into lately.[^e-14945a6346] ^598263e1

[^e-14945a6346]: Time: `2023-05-29`; Sources: [locomo/thread_d7ef2bcadc43/msg_1ca767639772](../../sources/locomo/thread_d7ef2bcadc43.md#source-aaa80229ca9fe769)

The user has been binge-watching a lot lately and decided to set a limit for themselves and make more time for outdoor activities, so they looked into ways to track and limit their screen time.[^e-e63a2e7436] ^fb470661

[^e-e63a2e7436]: Time: `2023-05-29`; Sources: [locomo/thread_d7ef2bcadc43/msg_c207762bb83b](../../sources/locomo/thread_d7ef2bcadc43.md#source-ca0ae7e6388f4710)

The user has been using Netflix for about six months and has watched a lot of shows and movies on it, and is now looking to explore other streaming services; on Apple TV+ they have already watched "The Morning Show" and "Servant".[^e-0c1d40cf7e] ^2f600f02

[^e-0c1d40cf7e]: Time: `2023-05-29`; Sources: [locomo/thread_d7ef2bcadc43/msg_0882565edb96](../../sources/locomo/thread_d7ef2bcadc43.md#source-472d2a85c3331097), [locomo/thread_d7ef2bcadc43/msg_771c093402ec](../../sources/locomo/thread_d7ef2bcadc43.md#source-938225b1c31bcc66)

The user is considering canceling their HBO subscription because they have not been watching it much; the last show they watched on it was "Game of Thrones", which ended months ago, and they have not found anything else on the platform that interests them.[^e-33f9b74089] ^1d774687

[^e-33f9b74089]: Time: `2023-05-29`; Sources: [locomo/thread_d7ef2bcadc43/msg_bc162f52cd6a](../../sources/locomo/thread_d7ef2bcadc43.md#source-eb4032581fcce6b3)

The user asked for podcast recommendations related to space and astronomy, as they have been really into those topics lately.[^e-e494f81764] ^d61ae29f

[^e-e494f81764]: Time: `2023-05-29`; Sources: [locomo/thread_d7ef2bcadc43/msg_d0d164269b27](../../sources/locomo/thread_d7ef2bcadc43.md#source-c2599d80d8360fb6)

The user uses the StreamMax streaming service on their Samsung QLED 4K smart TV and encountered an "Authentication Failed" error when trying to connect; they were troubleshooting by confirming their account credentials were correct, updating the StreamMax app to the latest version, and planning to disable and re-enable the app if the problem persisted.[^e-3e2cce0a48] ^483195ac

[^e-3e2cce0a48]: Time: `2023-05-30`; Sources: [locomo/thread_551cc7f69a7b/msg_aef5f2dcbddd](../../sources/locomo/thread_551cc7f69a7b.md#source-9439fe0e2fd6bf2e), [locomo/thread_551cc7f69a7b/msg_9b9ea2c8d118](../../sources/locomo/thread_551cc7f69a7b.md#source-7615a980a7a5d553), [locomo/thread_551cc7f69a7b/msg_846688edaf64](../../sources/locomo/thread_551cc7f69a7b.md#source-bde6abc7a110fe96)

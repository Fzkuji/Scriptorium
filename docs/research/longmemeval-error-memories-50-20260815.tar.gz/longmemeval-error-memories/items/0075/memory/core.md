# Core Memory

The user is preparing a lesson plan for the 10th session of a digital literacy course for 6th-grade elementary school students, focused on evaluating online information.[^e-f6d0d7a7fe] ^feec6467

[^e-f6d0d7a7fe]: Time: `2023-05-21`; Sources: [locomo/thread_5c188c1c98ea/msg_c93b211f719c](sources/locomo/thread_5c188c1c98ea.md#source-ad7ffc82fccaa51c)

The user prioritizes sustainability and ethical production when shopping for fashion and wants to support brands aligned with those values.[^e-e284c98b33] ^afd7e133

[^e-e284c98b33]: Time: `2023-05-20`; Sources: [locomo/thread_37d993f7a9d6/msg_6c0a984c5fc6](sources/locomo/thread_37d993f7a9d6.md#source-5563975dea57329b)

The user enjoys reading graphic novels, such as Saga, and contemporary fiction featuring strong female protagonists and complex relationships.[^e-7a8877526e] ^4c06b154

[^e-7a8877526e]: Time: `2023-05-22`; Sources: [locomo/thread_f4407b5e69a3/msg_b7e48307cffc](sources/locomo/thread_f4407b5e69a3.md#source-feeae438fd5ea0c5), [locomo/thread_f4407b5e69a3/msg_4c55976ef78e](sources/locomo/thread_f4407b5e69a3.md#source-5c9eed9aa4fa74fa)

The user cares for houseplants (a peace lily, a succulent, a fern, a rose bush, a snake plant, an orchid, African violets, a spider plant, and a basil plant) and tracks watering and fertilization with a plant tracking app.[^e-95364d3122][^e-c4b2f8a59a][^e-005f70f8f1] ^a1858f46

[^e-95364d3122]: Time: `2023-05-20`; Sources: [locomo/thread_7a2d72a9009a/msg_cef6e3a88f68](sources/locomo/thread_7a2d72a9009a.md#source-52c4794a71fd2442), [locomo/thread_7a2d72a9009a/msg_db5b60cf8fd1](sources/locomo/thread_7a2d72a9009a.md#source-09eb5fd0b8dae9a0)

[^e-c4b2f8a59a]: Time: `2023-05-24`; Sources: [locomo/thread_046276ceb02b/msg_20610c3cfbd0](sources/locomo/thread_046276ceb02b.md#source-bfb012a87e2319f9), [locomo/thread_046276ceb02b/msg_a857f58c3571](sources/locomo/thread_046276ceb02b.md#source-8ef15830982270cc), [locomo/thread_046276ceb02b/msg_817878b93de4](sources/locomo/thread_046276ceb02b.md#source-2d741f259a00a35d), [locomo/thread_046276ceb02b/msg_7940ea7fea7c](sources/locomo/thread_046276ceb02b.md#source-aaceada76ff8beba)

[^e-005f70f8f1]: Time: `2023-05-25`; Sources: [locomo/thread_3dfeec2de60c/msg_8c4ecc50b41f](sources/locomo/thread_3dfeec2de60c.md#source-7de3472b38635a32)

The user is learning to make kimchi and is refining their recipe to balance spice, salt, and other flavors.[^e-400089e733] ^4b0076b6

[^e-400089e733]: Time: `2023-05-21`; Sources: [locomo/thread_6bc2090ac4de/msg_a24e4dfe6c20](sources/locomo/thread_6bc2090ac4de.md#source-a32718f8a803603d)

The user is a beginner in music programming and is starting with Sonic Pi.[^e-7cf5fe54c2] ^db468b5d

[^e-7cf5fe54c2]: Time: `2023-05-21`; Sources: [locomo/thread_cbcd98836154/msg_6aa0279dcf94](sources/locomo/thread_cbcd98836154.md#source-8761e1d7fb10ed5e)

The user is exploring a career path involving Amazon Web Services, investigating how an Escalation Engineer II role maps to a Computer Network and Systems Engineer position.[^e-17a3b0cccb] ^520760a1

[^e-17a3b0cccb]: Time: `2023-05-21`; Sources: [locomo/thread_89990fbd2a44/msg_159ca96fc9cf](sources/locomo/thread_89990fbd2a44.md#source-dbb89dc4c282dd9b)

The user has a dog named Max.[^e-033c358228] ^1934119c

[^e-033c358228]: Time: `2023-05-23`; Sources: [locomo/thread_bb376441501c/msg_ff4264064f14](sources/locomo/thread_bb376441501c.md#source-7e33fd17b92c937a)

The user is setting up a music room in their garage and plans to record ukulele videos there.[^e-acc4f250f0] ^49d25af4

[^e-acc4f250f0]: Time: `2023-05-23`; Sources: [locomo/thread_5623a6557221/msg_aa8874e72af8](sources/locomo/thread_5623a6557221.md#source-69a42660a73a7919), [locomo/thread_5623a6557221/msg_e1c7efab79a0](sources/locomo/thread_5623a6557221.md#source-8279591945f442ea)

The user is interested in contemporary art and discovering emerging artists.[^e-9d6eb405c6] ^30d18ce0

[^e-9d6eb405c6]: Time: `2023-05-23`; Sources: [locomo/thread_987adb9e3384/msg_49916e9f133b](sources/locomo/thread_987adb9e3384.md#source-3476c113605b1c56), [locomo/thread_987adb9e3384/msg_cedd23a82653](sources/locomo/thread_987adb9e3384.md#source-a01f1646c2b15630)

The user is prioritizing their health and self-care, easing back into exercise after a few months of health issues and a recent case of bronchitis, and has started Saturday-morning yoga classes and cooking more at home.[^e-e135e6406d][^e-5506a9e956] ^e8047a4f

[^e-e135e6406d]: Time: `2023-05-25`; Sources: [locomo/thread_810c4bac6d0f/msg_40ebc5271110](sources/locomo/thread_810c4bac6d0f.md#source-9f03b52650c20a1d)

[^e-5506a9e956]: Time: `2023-05`; Sources: [locomo/thread_810c4bac6d0f/msg_b37ea7a6bf63](sources/locomo/thread_810c4bac6d0f.md#source-6b07b0c35f407343), [locomo/thread_810c4bac6d0f/msg_2f8a85df49fb](sources/locomo/thread_810c4bac6d0f.md#source-f669b521a9f819bb)

The user started a new job in March 2023 and is adjusting to it while managing work-related stress.[^e-e96d2c08fe] ^6b0c328f

[^e-e96d2c08fe]: Time: `2023-03`; Sources: [locomo/thread_01ea86c3d49e/msg_099b87789e90](sources/locomo/thread_01ea86c3d49e.md#source-9753659f08da0f61)

The user is planning new electric fencing for their rural property and decided on high-tensile wire.[^e-511f0396d9] ^b578befc

[^e-511f0396d9]: Time: `2023-05-25`; Sources: [locomo/thread_100ba0195b99/msg_ebd760f46e80](sources/locomo/thread_100ba0195b99.md#source-b010eae73e629d10), [locomo/thread_100ba0195b99/msg_292dab1a066d](sources/locomo/thread_100ba0195b99.md#source-b4e6daa454973464)

The user is building a 3D Turkish marketplace and planned its environment assets, including traditional buildings such as mosques and bazaars, market stalls, furniture and decorations, vehicles, people, Turkish food and drink, animals, and landscaping.[^e-efce6f37bc] ^7fda6224

[^e-efce6f37bc]: Time: `2023-05-26`; Sources: [locomo/thread_774d07d5ad9c/msg_3d961a2ab2a2](sources/locomo/thread_774d07d5ad9c.md#source-ac236a878fbf7dc6), [locomo/thread_774d07d5ad9c/msg_37f6d8fe146a](sources/locomo/thread_774d07d5ad9c.md#source-88b10b91ec04dc53)

The user completed a master's program in May 2023 and is planning to pursue a PhD in Computer Science at Stanford University.[^e-de310bee39] ^b3516c15

[^e-de310bee39]: Time: `2023-05`; Sources: [locomo/thread_85a4c6cb88e4/msg_7d4597b48c1f](sources/locomo/thread_85a4c6cb88e4.md#source-3e1244b164ec31b8), [locomo/thread_85a4c6cb88e4/msg_306129b77529](sources/locomo/thread_85a4c6cb88e4.md#source-aa4b8849c9b101b3)

The user is applying to academic programs at the University of Sussex and researching scholarship opportunities there.[^e-6ba456b130] ^6a80444d

[^e-6ba456b130]: Time: `2023-05-27`; Sources: [locomo/thread_023f8650f638/msg_0225eb431b77](sources/locomo/thread_023f8650f638.md#source-0e82838c5d4f1111), [locomo/thread_023f8650f638/msg_5ba654acec46](sources/locomo/thread_023f8650f638.md#source-0865d6d678ff0fc8)

The user has worked in the corporate world for over five years and, while the job has provided financial stability, feels it is not truly fulfilling and is considering a career transition, exploring whether writing could be a viable career option.[^e-1c3c5b77ba] ^18f84dab

[^e-1c3c5b77ba]: Time: `2023-05-29`; Sources: [locomo/thread_b6fdc3c2643b/msg_79b1830ae93f](sources/locomo/thread_b6fdc3c2643b.md#source-7b1e75cde58993c0)

The user is working to rebuild trust in a long-distance relationship after a breach of trust and is worried about their partner's commitment to the process.[^e-9dab8f6ae1] ^f67caab4

[^e-9dab8f6ae1]: Time: `2023-05-30`; Sources: [locomo/thread_3521d895e8f1/msg_1e432e7b3717](sources/locomo/thread_3521d895e8f1.md#source-824441a91d87faf5), [locomo/thread_3521d895e8f1/msg_880ed7581f47](sources/locomo/thread_3521d895e8f1.md#source-5f335901447f8e6d)

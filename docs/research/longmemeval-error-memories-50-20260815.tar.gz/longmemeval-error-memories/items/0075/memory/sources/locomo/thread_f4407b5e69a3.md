# thread_f4407b5e69a3

<a id="source-feeae438fd5ea0c5"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_b7e48307cffc -->
[2023-05-22] user: I'm trying to get back into reading more graphic novels, and I was wondering if you could recommend some popular ones that are similar to Saga by Brian K. Vaughan and Fiona Staples. By the way, I've been reading a lot lately, I just started "The Seven Husbands of Evelyn Hugo" on January 29th, and it's been keeping me up at night.

<a id="source-088648957dfc986e"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_2058bf23b233 -->
[2023-05-22] assistant: Saga is an amazing series! If you enjoyed its blend of science fiction, adventure, and complex characters, here are some popular graphic novels that you might enjoy:

1. **Monstress** by Marjorie Liu and Sana Takeda: This fantasy epic follows a young woman with supernatural abilities as she battles against powerful forces in a richly imagined world. The art is stunning, and the story is full of complex characters and moral ambiguity.
2. **The Wicked + The Divine** by Kieron Gillen and Jamie McKelvie: This series explores the intersection of mythology and pop culture, as a group of gods reincarnate as pop stars. It's a wild ride with great characters, stunning art, and a lot of depth.
3. **Black Hammer** by Jeff Lemire and Dean Ormston: This superhero deconstruction follows a group of heroes stranded on a rural farm after a cosmic event. It's a great exploration of the human side of superheroism, with complex characters and a mysterious plot.
4. **The Umbrella Academy** by Gerard Way and Gabriel Bá: This series follows a dysfunctional family of superheroes as they try to uncover the secrets of their past and prevent the apocalypse. It's a great blend of action, drama, and humor.
5. **Descender** by Jeff Lemire and Dustin Nguyen: This sci-fi epic follows a young robot boy as he tries to survive in a universe where robots are hunted by humans. It's a great exploration of identity, humanity, and what it means to be alive.
6. **The Goddamned** by Jason Aaron and R.M. Guéra: This series is set in a world where biblical figures and mythological creatures exist in a dark, gritty reality. It's a great blend of action, drama, and horror.
7. **Y: The Last Man** by Brian K. Vaughan and Pia Guerra: Another classic series by Vaughan, this one follows a young man who becomes the last human male on Earth after a mysterious event. It's a great exploration of gender, power, and humanity.

As for "The Seven Husbands of Evelyn Hugo", I'm glad to hear you're enjoying it! It's a great novel that explores the complexities of identity, love, and fame. The author, Taylor Jenkins Reid, has a way of crafting relatable characters and stories that really resonate with readers.

I hope you enjoy these graphic novel recommendations, and happy reading!

<a id="source-5c9eed9aa4fa74fa"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_4c55976ef78e -->
[2023-05-22] user: I'll definitely check out some of those recommendations. I'm loving the character development in Evelyn Hugo, and I'm curious to see how the story unfolds. Do you have any recommendations for contemporary fiction novels that feature strong female protagonists and complex relationships like Evelyn Hugo?

<a id="source-2c7699314ff45c3c"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_ded698426bc5 -->
[2023-05-22] assistant: I'm so glad you're enjoying Evelyn Hugo! If you're looking for more contemporary fiction novels with strong female protagonists and complex relationships, here are some recommendations:

1. **The Devil Wears Prada** by Lauren Weisberger: While not exactly like Evelyn Hugo, this classic novel explores the complex relationship between a demanding boss and her assistant, with a strong focus on female characters and relationships.
2. **The Mothers** by Brit Bennett: This novel follows a young girl's coming-of-age in a tight-knit Southern California community, exploring themes of motherhood, identity, and complex relationships between women.
3. **The Girls** by Emma Cline: Set in the 1960s, this novel follows a group of teenage girls who get caught up in a Manson-esque cult, exploring themes of female relationships, identity, and the power dynamics between women.
4. **The Interestings** by Meg Wolitzer: This novel follows a group of friends who meet at a summer camp for the arts, exploring their complex relationships and the ways in which they shape each other's lives over the years.
5. **Conversations with Friends** by Sally Rooney: This novel follows the complex relationships between two young women and the couple they become embroiled with, exploring themes of power, identity, and desire.
6. **The Female Persuasion** by Meg Wolitzer: Another novel by Wolitzer, this one follows a young woman's complex relationships with her mentor, a famous feminist, and explores themes of identity, power, and relationships between women.
7. **The Last Romantics** by Tara Conklin: This novel follows four siblings who grow up together, exploring their complex relationships and the ways in which they shape each other's lives over the years.
8. **The Age of Light** by Whitney Scharer: This novel is based on the true story of Lee Miller, a model and photographer who was part of the Parisian avant-garde in the 1920s and 1930s. It explores her complex relationships with the men in her life, as well as her own identity and desires.

These novels all feature strong female protagonists and complex relationships, although some may not have the same level of glamour and celebrity as Evelyn Hugo. I hope you find something that interests you!

(By the way, I'm curious: what do you think of the themes and characters in Evelyn Hugo so far? Do you have a favorite character or plot thread?)

<a id="source-32adf334dc723fa7"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_255d528a32f4 -->
[2023-05-22] user: I'm really loving the characters in Evelyn Hugo, especially the way they're all interconnected. I think what drew me in was the way the story started with Evelyn's life as a Cuban immigrant, and how it shaped her into the person she became. I'm curious to see how the rest of the story unfolds, especially with the mystery surrounding her husbands.

<a id="source-7e2af5d7563f4b8e"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_c0fc02ca5cef -->
[2023-05-22] assistant: The way the characters are interconnected is one of the strengths of the book, isn't it? Taylor Jenkins Reid does a great job of weaving together the different storylines and characters to create a rich and complex narrative.

Evelyn's backstory as a Cuban immigrant is so powerful, and it's great that you were drawn in by that aspect of the story. It's a really important part of her character, and it informs so much of her behavior and motivations throughout the book. The way she navigates the challenges of being a woman, a Latina, and an immigrant in Hollywood is really compelling, and it adds so much depth to the story.

And of course, the mystery surrounding her husbands is a big part of the book's appeal! I think it's safe to say that each of Evelyn's husbands plays a significant role in her life, and their stories are all intertwined in interesting ways. As you continue reading, you'll learn more about each of them and how they fit into Evelyn's narrative.

One of the things that's so impressive about Taylor Jenkins Reid's writing is the way she's able to balance the glamour and excitement of Evelyn's celebrity life with the more serious themes and emotions that underpin the story. It's a really skillful balancing act, and it makes the book feel both escapist and thought-provoking at the same time.

What do you think of Monique, the journalist who's writing Evelyn's biography? Do you think she's a good narrator for the story, or do you wish we were seeing things more from Evelyn's perspective?

<a id="source-11958cf40bbc4e48"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_e1bb2f87354c -->
[2023-05-22] user: I think Monique is a great narrator for the story, she brings a nice outside perspective to Evelyn's life and experiences. I like how she's not just a passive listener, but an active participant in uncovering Evelyn's secrets and stories. It's interesting to see how Monique's own life and biases influence her perceptions of Evelyn and her story.

<a id="source-e5390bbc74e21171"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_174bc3f22d46 -->
[2023-05-22] assistant: Exactly! Monique is a great narrator because she's not just a passive observer, but an active participant in the storytelling process. She's got her own biases and motivations, and that adds an extra layer of complexity to the story. It's also interesting to see how Monique's own life and experiences influence her perceptions of Evelyn and her story.

I think Monique's character also serves as a kind of stand-in for the reader. We're learning about Evelyn's life through Monique's eyes, and Monique's reactions and thoughts help to guide our own understanding of the story. It's a clever narrative device, and it adds to the sense of intimacy and immediacy that makes the book so compelling.

And you're right, Monique's own life and biases do influence her perceptions of Evelyn. She's got her own struggles and insecurities, and those inform the way she approaches Evelyn's story. It's a great example of how our own experiences and biases can shape the way we see the world and the people in it.

I think Taylor Jenkins Reid does a great job of using Monique's character to explore some really interesting themes, like the nature of celebrity and fame, the power dynamics between women, and the way that our personal experiences shape our perceptions of the world. It's a really nuanced and thought-provoking book, and Monique's character is a big part of what makes it so effective.

What do you think about the way the book explores the theme of identity? Evelyn's identity is so tied up in her celebrity persona, but we're also seeing glimpses of her inner life and her true self. Do you think that's something that resonates with you, or is it more of a fascination with the glamour of celebrity culture?

<a id="source-30df1c1628335d2d"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_98493d57f0de -->
[2023-05-22] user: I think the exploration of identity is really interesting in Evelyn Hugo. It's clear that Evelyn's identity is deeply tied to her celebrity persona, but at the same time, we're seeing glimpses of her inner life and true self through her stories and interactions with Monique. It's like she's performing this persona for the public, but there's a more vulnerable person beneath the surface.

I think that's something that resonates with me, because I think we all have these different personas or masks that we wear in different situations. Maybe it's not to the same extent as a celebrity like Evelyn, but I think it's a universal human experience to some degree. We all have our public selves and our private selves, and sometimes those two selves can feel like they're in conflict with each other.

It's also interesting to see how Evelyn's identity is shaped by her experiences as a woman, a Latina, and an immigrant. Her identity is intersectional, and that's something that I think

<a id="source-f29da36a5425b668"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_af2ba6f017d5 -->
[2023-05-22] assistant: Beautifully said! You're absolutely right, the exploration of identity in Evelyn Hugo is one of the book's strongest aspects. The way Evelyn's celebrity persona is performative, yet beneath that, there's a vulnerable person struggling to reconcile her true self with the image she presents to the world, is so relatable.

And I love how you phrased it - we all have our public selves and private selves, and sometimes those two selves can feel like they're in conflict with each other. That's such a universal human experience, and it's something that I think many readers can identify with.

The intersectionality of Evelyn's identity is also a crucial aspect of the book. As a woman, a Latina, and an immigrant, she faces multiple forms of marginalization and oppression, and those experiences shape her identity in profound ways. The book does an excellent job of exploring how those different aspects of her identity intersect and impact her life, and it's something that adds so much depth and nuance to the story.

It's also interesting to consider how Evelyn's identity is shaped by the societal expectations placed upon her. As a celebrity, she's expected to present a certain image, and that pressure can be suffocating. But as a woman, a Latina, and an immigrant, she's also expected to conform to certain stereotypes and norms, and that can be even more limiting. The book does a great job of highlighting the ways in which these expectations can be damaging and restrictive, and how Evelyn struggles to navigate them.

What do you think about the way the book portrays the relationships between women? Evelyn's relationships with her friends, lovers, and colleagues are all so complex and multifaceted, and they add so much to the story.

<a id="source-f0f7d5b0d1420a9b"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_3c6f6cbb4613 -->
[2023-05-22] user: I think the portrayal of relationships between women in Evelyn Hugo is one of the book's strongest aspects. The way the author depicts the complexities, nuances, and depth of female relationships is really remarkable. Evelyn's relationships with her friends, lovers, and colleagues are all multifaceted and richly drawn, and they add so much to the story.

I love how the book shows that female relationships can be both supportive and competitive, loving and complicated, all at the same time. The way Evelyn navigates her relationships with women like Celia, Monique, and Lucy is so realistic and relatable. It's clear that these relationships are central to Evelyn's life and identity, and that they shape her in profound ways.

The book also does a great job of highlighting the ways in which women can be both empowered and limited by their relationships with each other. Evelyn's relationships with women are often sources of strength and inspiration, but they can also be sources of pain and struggle. I think that's a

<a id="source-c08f618f0eac3e4b"></a>
<!-- source-id:locomo/thread_f4407b5e69a3/msg_09e2e3ff715f -->
[2023-05-22] assistant: I couldn't agree more! The portrayal of relationships between women in Evelyn Hugo is truly remarkable. The book shows that female relationships can be complex, multifaceted, and richly nuanced, and that they can be both sources of strength and inspiration, as well as sources of pain and struggle.

I love how the book highlights the ways in which women can be both empowered and limited by their relationships with each other. Evelyn's relationships with women like Celia, Monique, and Lucy are all significant in different ways, and they shape her identity and experiences in profound ways.

The way the book depicts the complexities of female friendships is also noteworthy. Evelyn's friendships with Celia and Lucy are particularly significant, and they show that female friendships can be deep, loyal, and long-lasting, but also fraught with tension, competition, and misunderstandings.

I think the book also does a great job of exploring the ways in which societal expectations and patriarchal norms can impact women's relationships with each other. Evelyn's experiences as a woman in a male-dominated industry, and her relationships with men, are all influenced by these broader societal forces, and the book shows how these forces can shape women's lives and relationships in profound ways.

The way the book portrays the relationships between women is also deeply intersectional, taking into account the ways in which race, class, sexuality, and other factors can shape women's experiences and relationships. Evelyn's relationships with women of color, for example, are particularly significant, and the book shows how these relationships can be sources of solidarity, support, and empowerment, but also of tension and conflict.

Overall, I think the portrayal of relationships between women in Evelyn Hugo is one of the book's greatest strengths, and it's something that sets the book apart from other novels about celebrity culture and identity.

What do you think about the way the book explores the theme of power and privilege? Evelyn's experiences as a celebrity, a woman, and a Latina are all shaped by her access to power and privilege, and the book shows how these factors can impact her relationships and experiences.

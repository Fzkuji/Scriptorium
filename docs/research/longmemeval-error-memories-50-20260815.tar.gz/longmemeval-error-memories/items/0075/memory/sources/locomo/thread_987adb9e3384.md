# thread_987adb9e3384

<a id="source-3476c113605b1c56"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_49916e9f133b -->
[2023-05-23] user: I'm looking for some recommendations on contemporary art exhibitions in the city. I recently attended a gallery opening at the Contemporary Art Space back in October, which featured a renowned artist, and it was really thought-provoking. I ended up spending over 2 hours there, taking it all in. Do you know of any upcoming exhibitions that I might be interested in?

<a id="source-78bce046da0e42eb"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_291680872df2 -->
[2023-05-23] assistant: I'm happy to help! However, I have to clarify that I'm a large language model, I don't have real-time information about specific art exhibitions or galleries in your city. But I can suggest some ways to find out about upcoming exhibitions that might interest you:

1. Online Search: You can search for art galleries and museums in your city and check their websites for upcoming exhibitions. You can also use online platforms like Artsy, Artnet, or Culture Trip to discover exhibitions and events in your area.
2. Social Media: Follow local art galleries, museums, and art institutions on social media platforms like Instagram, Facebook, and Twitter. They often post about upcoming exhibitions, events, and artist talks.
3. Local Art Calendars: Look for local art calendars or event listings in newspapers, magazines, or online publications that focus on art and culture.
4. Artist Networks: If you're interested in a specific type of art or medium, you can look for local artist networks, collectives, or organizations that showcase the work of emerging and established artists.
5. Word of Mouth: Ask friends, colleagues, or fellow art enthusiasts for recommendations. They might have insider knowledge about upcoming exhibitions or events that are not yet publicized.

When searching for exhibitions, you can also consider the following criteria to find something that resonates with your interests:

* Theme: Look for exhibitions that explore themes or topics that interest you, such as social justice, environmentalism, or technology.
* Medium: If you're interested in a specific medium, like photography, painting, or sculpture, search for exhibitions that feature that medium.
* Artist: If you're interested in a particular artist or style, look for exhibitions that feature their work or similar artists.
* Institution: Consider exhibitions at institutions that align with your interests, such as museums, galleries, or non-profit spaces.

Remember to check the exhibition dates, times, and locations before heading out, and plan to spend a good amount of time taking it all in, just like you did at the Contemporary Art Space!

<a id="source-a01f1646c2b15630"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_cedd23a82653 -->
[2023-05-23] user: I'm particularly interested in emerging artists, so I'll definitely look into local artist networks and collectives. Do you know if there are any online platforms or websites that feature emerging artists and their work?

<a id="source-b0a9739cb35d01d2"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_e3e724690754 -->
[2023-05-23] assistant: There are many online platforms and websites that showcase emerging artists and their work. Here are some popular ones:

1. **Artsy**: Artsy is a leading online platform that features a vast collection of artworks from emerging and established artists. They have a dedicated section for emerging artists, and you can filter by medium, style, and more.
2. **Saatchi Art**: Saatchi Art is an online art gallery that focuses on emerging artists. They have a vast collection of artworks, and you can discover new artists through their curated collections and exhibitions.
3. **Behance**: Behance is a platform where creatives showcase their work, including artists, designers, and illustrators. You can search for emerging artists by medium, style, or location.
4. **Instagram**: Many emerging artists use Instagram to showcase their work, and you can discover new artists by using hashtags like #emergingartist, #artoftheday, #contemporaryart, or #artistsofinstagram.
5. **Juxtapoz**: Juxtapoz is an online art magazine that features emerging and established artists in the contemporary art world. They regularly publish artist profiles, interviews, and exhibitions.
6. **Hyperallergic**: Hyperallergic is an online art blog that covers news, exhibitions, and artist profiles. They often feature emerging artists and provide in-depth coverage of the art world.
7. **New American Paintings**: New American Paintings is an online platform that features emerging painters from the United States. They publish a bi-monthly magazine and have an online archive of past issues.
8. **ArtNet**: ArtNet is an online art platform that features news, exhibitions, and artist profiles. They have a section dedicated to emerging artists, and you can search for artists by medium, style, or location.
9. **The Artist's Institute**: The Artist's Institute is an online platform that features emerging artists through exhibitions, interviews, and essays.
10. **Platform**: Platform is an online art platform that showcases emerging artists from around the world. They feature a curated selection of artworks, artist profiles, and exhibitions.

These platforms are just a few examples of the many online resources available to discover emerging artists. You can also search for online art communities, forums, and social media groups dedicated to emerging artists and art enthusiasts. Happy discovering!

<a id="source-24da4a402bb04a09"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_93ccddf82484 -->
[2023-05-23] user: I'll definitely check out these platforms, especially Artsy and Saatchi Art. I've had a good experience with discovering emerging artists at events like the "Contemporary Art Exhibition" at the Modern Art Museum, where I saw some amazing installations and paintings by emerging artists like Sarah Johnson, who showcased a thought-provoking installation on climate change. Do you think I could find similar types of events or exhibitions on these online platforms?

<a id="source-a4b3ffb1038e77f2"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_0b04854e2403 -->
[2023-05-23] assistant: It's great that you've had a positive experience discovering emerging artists at events like the "Contemporary Art Exhibition" at the Modern Art Museum!

While online platforms can't replicate the physical experience of attending an event or exhibition, they can certainly provide access to similar types of events, exhibitions, and artworks. Here's what you can expect to find on online platforms like Artsy and Saatchi Art:

1. **Online Exhibitions**: Many online platforms, including Artsy and Saatchi Art, feature online exhibitions that showcase artworks by emerging artists. These exhibitions might be curated around a specific theme, medium, or style.
2. **Artist Showcases**: Online platforms often feature dedicated showcases for individual emerging artists, including their artworks, artist statements, and biographies.
3. **Virtual Events**: Some online platforms, like Artsy, host virtual events, such as artist talks, panel discussions, and live tours of exhibitions. These events can provide valuable insights into the artistic process and offer opportunities to engage with artists and art professionals.
4. **Art Fairs and Festivals**: Online art fairs and festivals, like the online edition of The Other Art Fair, can be found on platforms like Saatchi Art. These events bring together emerging artists from around the world and provide a platform for them to showcase their work.
5. **Curated Collections**: Online platforms often feature curated collections of artworks, which can be a great way to discover emerging artists and their work. These collections might be themed around specific topics, styles, or mediums.

While you might not be able to attend a physical event, online platforms can provide a similar sense of discovery and engagement with emerging artists and their work. You can:

* Browse through online exhibitions and showcases
* Read artist statements and biographies
* Engage with artists and art professionals through comments, messages, or live events
* Discover new artists and artworks
* Learn about emerging trends and themes in contemporary art

Remember to explore the online platforms, and you might stumble upon emerging artists like Sarah Johnson, who are creating thought-provoking installations and paintings that resonate with your interests!

<a id="source-482b57b767e06b70"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_f9630cd69044 -->
[2023-05-23] user: I'll definitely check out the online exhibitions and showcases on Artsy and Saatchi Art. Since I have a particular interest in contemporary art, I was wondering if there are any online platforms that focus specifically on contemporary art and emerging artists. Are there any platforms that provide a more curated experience, where I can discover new artists and artworks based on my interests?

<a id="source-60c95e27ae684761"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_0dadb6fb7cc3 -->
[2023-05-23] assistant: You're looking for a more curated experience that's tailored to your interests in contemporary art and emerging artists?

Yes, there are online platforms that focus specifically on contemporary art and emerging artists, and offer a more curated experience. Here are a few examples:

1. **Artspace**: Artspace is an online platform that focuses on contemporary art and emerging artists. They feature a curated selection of artworks, artist profiles, and exhibitions. You can discover new artists and artworks based on your interests, and even purchase artworks directly from the platform.
2. **1stdibs**: 1stdibs is an online marketplace that features a curated selection of contemporary art, design, and antiques. They work with leading galleries and dealers to showcase high-quality artworks by emerging and established artists.
3. **Uprise Art**: Uprise Art is an online platform that focuses on emerging artists and contemporary art. They offer a curated selection of artworks, artist profiles, and exhibitions. You can discover new artists and artworks based on your interests, and even purchase artworks directly from the platform.
4. **Minted**: Minted is an online platform that features a curated selection of contemporary art and design. They work with emerging artists and designers to showcase unique and exclusive artworks.
5. **Collecteurs**: Collecteurs is an online platform that focuses on contemporary art and emerging artists. They offer a curated selection of artworks, artist profiles, and exhibitions. You can discover new artists and artworks based on your interests, and even purchase artworks directly from the platform.

These platforms often use algorithms and human curation to provide a personalized experience, recommending artworks and artists based on your interests and preferences. Some platforms also offer features like:

* Personalized art advisory services
* Curated collections and exhibitions
* Artist spotlights and interviews
* Behind-the-scenes stories and artist statements
* Online events and webinars

By exploring these platforms, you can discover new emerging artists and artworks that resonate with your interests in contemporary art.

<a id="source-57d135f1603352ec"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_860def65ef76 -->
[2023-05-23] user: That's great! I'll definitely check out these platforms, especially Artspace and Uprise Art. Since I've had a good experience with discovering emerging artists at events like the "Gallery Opening" at the Contemporary Art Space, which featured the work of a renowned artist, I'm excited to explore these online platforms that focus on contemporary art and emerging artists.

<a id="source-8d7da21da4f040e1"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_87f57b71f2d7 -->
[2023-05-23] assistant: I'm glad to hear that you're excited to explore these online platforms! It's great that you've had a positive experience discovering emerging artists at events like the "Gallery Opening" at the Contemporary Art Space.

Remember, online platforms can be a fantastic way to discover new artists and artworks, but they can also be overwhelming with the sheer amount of content available. Take your time to browse through the platforms, and don't be afraid to reach out to the teams behind them if you have any questions or need more information about a particular artist or artwork.

Also, keep in mind that online platforms can be a great way to support emerging artists and the art community as a whole. By engaging with these platforms, you're helping to promote the work of emerging artists and contributing to the growth of the art market.

If you have any more questions or need further recommendations, feel free to ask! Otherwise, happy art discovering, and I hope you find some amazing emerging artists and artworks on these online platforms!

<a id="source-79c2bf60832ee966"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_3bb059d845a8 -->
[2023-05-23] user: Wait, I think I got a bit carried away there. Let me rephrase that.

I'll definitely check out Artspace and Uprise Art, and see what kind of emerging artists and artworks they have to offer. Thanks for the recommendations!

<a id="source-5c086bcdd2d3f1de"></a>
<!-- source-id:locomo/thread_987adb9e3384/msg_a38e14e55f89 -->
[2023-05-23] assistant: No worries, I understand! It's great that you're excited to explore these online platforms, and I'm happy to have been able to help.

You're welcome for the recommendations! I hope you have a great time discovering new emerging artists and artworks on Artspace and Uprise Art. If you have any more questions or need further recommendations, feel free to ask. Otherwise, happy art exploring!

# thread_7c96790ff4be

<a id="source-0f9d10005397692e"></a>
<!-- source-id:locomo/thread_7c96790ff4be/msg_78118bc0cf54 -->
[2023-05-25] assistant: There are several tweets about a team goal scored by Argentina in the World Cup final against France. Many people are praising the goal, calling it fantastic, beautiful, sublime, unbelievable, and the best team goal of the tournament. Some are also commenting on the poor performance of France, with no attempts on goal after 35 minutes. Messi and Di Maria are specifically mentioned as playing well in the match. The score is 2-0 in favor of Argentina, and some believe that they are dominating the game.

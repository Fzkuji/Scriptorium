# thread_4c22fc1ada7e

<a id="source-8cb8a421e0b22842"></a>
<!-- source-id:locomo/thread_4c22fc1ada7e/msg_f204f7793441 -->
[2023-05-27] user: Table 1: Critical values (percentiles) for the $t$ distribution.
 The table entries are the critical values (percentiles) for the $t$ distribution. The column headed DF (degrees of freedom) gives the degrees of freedom for the values in that row. The columns are labeled by ``Percent''. ``One-sided'' and ``Two-sided''. Percent is $100 \times \mbox{cumulative}$ distribution function - the table entry is the corresponding percentile. One-sided is the significance level for the one-sided upper critical value--the table entry is the critical value. Two-sided gives the two-sided significance level--the table entry is the corresponding two-sided critical value. 
 Percent
75 90 95 97.5 99 99.5 99.75 99.9 99.95 99.975 99.99 99.995
 One-sided $\alpha$
.25 .10 .05 .025 .01 .005 .0025 .001 .0005 .00025 .0001 .00005
 Two-sided $\alpha$
.50 .20 .10 .05 .02 .01 .005 .002 .001 .0005 .0002 .0001
df 
1 1.00 3.08 6.31 12.71 31.82 63.66 127.32 318.31 636.62 1273.24 3183.10 6366.20
2 .82 1.89 2.92 4.30 6.96 9.22 14.09 22.33 31.60 44.70 70.70 99.99
3 .76 1.64 2.35 3.18 4.54 5.84 7.45 10.21 12.92 16.33 22.20 28.00
4 .74 1.53 2.13 2.78 3.75 4.60 5.60 7.17 8.61 10.31 13.03 15.54
5 .73 1.48 2.02 2.57 3.37 4.03 4.77 5.89 6.87 7.98 9.68 11.18
6 .72 1.44 1.94 2.45 3.14 3.71 4.32 5.21 5.96 6.79 8.02 9.08
7 .71 1.42 1.90 2.37 3.00 3.50 4.03 4.79 5.41 6.08 7.06 7.88
8 .71 1.40 1.86 2.31 2.90 3.36 3.83 4.50 5.04 5.62 6.44 7.12
9 .70 1.38 1.83 2.26 2.82 3.25 3.69 4.30 4.78 5.29 6.01 6.59
10 .70 1.37 1.81 2.23 2.76 3.17 3.58 4.14 4.59 5.05 5.69 6.21
11 .70 1.36 1.80 2.20 2.72 3.11 3.50 4.03 4.44 4.86 5.45 5.92
12 .70 1.36 1.78 2.18 2.68 3.06 3.43 3.93 4.32 4.72 5.26 5.69
13 .69 1.35 1.77 2.16 2.65 3.01 3.37 3.85 4.22 4.60 5.11 5.51
14 .69 1.35 1.76 2.15 2.63 2.98 3.33 3.79 4.14 4.50 4.99 5.36
15 .69 1.34 1.75 2.13 2.60 2.95 3.29 3.73 4.07 4.42 4.88 5.24
16 .69 1.34 1.75 2.12 2.58 2.92 3.25 3.69 4.02 4.35 4.79 5.13
17 .69 1.33 1.74 2.11 2.57 2.90 3.22 3.65 3.97 4.29 4.71 5.04
18 .69 1.33 1.73 2.10 2.55 2.88 3.20 3.61 3.92 4.23 4.65 4.97
19 .69 1.33 1.73 2.09 2.54 2.86 3.17 3.58 3.88 4.19 4.59 4.90
20 .69 1.33 1.73 2.09 2.53 2.85 3.15 3.55 3.85 4.15 4.54 4.84
21 .69 1.32 1.72 2.08 2.52 2.83 3.14 3.53 3.82 4.11 4.49 4.78
22 .69 1.32 1.72 2.07 2.51 2.82 3.12 3.51 3.79 4.08 4.45 4.74
23 .68 1.32 1.71 2.07 2.50 2.81 3.10 3.49 3.77 4.05 4.42 4.69
24 .68 1.32 1.71 2.06 2.49 2.80 3.09 3.47 3.75 4.02 4.38 4.65
25 .68 1.32 1.71 2.06 2.49 2.79 3.08 3.45 3.73 4.00 4.35 4.62
26 .68 1.32 1.71 2.06 2.48 2.78 3.07 3.44 3.71 3.97 4.32 4.59
27 .68 1.31 1.70 2.05 2.47 2.77 3.06 3.42 3.69 3.95 4.30 4.56
28 .68 1.31 1.70 2.05 2.47 2.76 3.05 3.41 3.67 3.94 4.28 4.53
29 .68 1.31 1.70 2.05 2.46 2.76 3.04 3.40 3.66 3.92 4.25 4.51
30 .68 1.31 1.70 2.04 2.46 2.75 3.03 3.39 3.65 3.90 4.23 4.48
35 .68 1.31 1.69 2.03 2.44 2.72 3.00 3.34 3.59 3.84 4.15 4.39
40 .68 1.30 1.68 2.02 2.42 2.70 2.97 3.31 3.55 3.79 4.09 4.32
45 .68 1.30 1.68 2.01 2.41 2.69 2.95 3.28 3.52 3.75 4.05 4.27
50 .68 1.30 1.68 2.01 2.40 2.68 2.94 3.26 3.50 3.72 4.01 4.23
55 .68 1.30 1.67 2.00 2.40 2.67 2.93 3.25 3.48 3.70 3.99 4.20
60 .68 1.30 1.67 2.00 2.39 2.66 2.91 3.23 3.46 3.68 3.96 4.17
65 .68 1.29 1.67 2.00 2.39 2.65 2.91 3.22 3.45 3.66 3.94 4.15
70 .68 1.29 1.67 1.99 2.38 2.65 2.90 3.21 3.44 3.65 3.93 4.13
75 .68 1.29 1.67 1.99 2.38 2.64 2.89 3.20 3.43 3.64 3.91 4.11
80 .68 1.29 1.66 1.99 2.37 2.64 2.89 3.20 3.42 3.63 3.90 4.10
85 .68 1.29 1.66 1.99 2.37 2.64 2.88 3.19 3.41 3.62 3.89 4.08
90 .68 1.29 1.66 1.99 2.37 2.63 2.88 3.18 3.40 3.61 3.88 4.07
95 .68 1.29 1.66 1.99 2.37 2.63 2.87 3.18 3.40 3.60 3.87 4.06
100 .68 1.29 1.66 1.98 2.36 2.63 2.87 3.17 3.39 3.60 3.86 4.05
200 .68 1.29 1.65 1.97 2.35 2.60 2.84 3.13 3.34 3.54 3.79 3.97
500 .68 1.28 1.65 1.97 2.33 2.59 2.82 3.11 3.31 3.50 3.75 3.92
$\infty$ .67 1.28 1.65 1.96 2.33 2.58 2.81 3.10 3.30 3.49 3.73 3.91

<a id="source-592e59f740a6afbd"></a>
<!-- source-id:locomo/thread_4c22fc1ada7e/msg_ac68968e2f28 -->
[2023-05-27] assistant: The $t$ distribution is a probability distribution that is used to make inferences about the population mean when the sample size is small and/or the population standard deviation is unknown. It is a bell-shaped distribution that is similar to the standard normal distribution, but has heavier tails. The shape of the $t$ distribution depends on the degrees of freedom, which is equal to the sample size minus one.

The $t$ distribution is often used in hypothesis testing to test whether the sample mean is significantly different from a known or hypothesized population mean. In this case, a $t$-test is used to calculate a test statistic, which is then compared to critical values from the $t$ distribution to determine the p-value and make a decision about the null hypothesis.

The $t$ distribution is also used in confidence interval estimation. A confidence interval is a range of values that is likely to contain the true population mean with a certain level of confidence. The $t$ distribution is used to calculate the width of the confidence interval, which depends on the sample size, sample mean, and sample standard deviation.

The $t$ distribution is similar to the standard normal distribution in that it is symmetric about the mean, with a mean of 0 and a standard deviation of 1 for the standard $t$ distribution. However, as the degrees of freedom increase, the $t$ distribution approaches the standard normal distribution.

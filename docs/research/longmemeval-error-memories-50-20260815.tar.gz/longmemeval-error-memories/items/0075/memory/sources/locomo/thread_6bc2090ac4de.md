# thread_6bc2090ac4de

<a id="source-a32718f8a803603d"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_a24e4dfe6c20 -->
[2023-05-21] user: I'm trying to perfect my kimchi recipe, but my first attempt last weekend was a disaster. It was way too spicy and salty, so I'm looking for some tips on how to balance the flavors.

<a id="source-85f977f54f9b9a51"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_5d9d72415cf3 -->
[2023-05-21] assistant: Kimchi can be a bit finicky, but don't worry, I'm here to help! Balancing the flavors in kimchi is crucial, and it's great that you're willing to experiment and adjust. Here are some tips to help you achieve a harmonious balance of sweet, sour, salty, and spicy:

**Spice level:**

1. **Start with a smaller amount of chili peppers or gochugaru (Korean chili flakes)**: If you're new to making kimchi, it's better to err on the side of caution. You can always add more heat, but it's harder to remove excess spiciness.
2. **Use a variety of chili peppers**: Combining different types of chilies can create a more complex, balanced heat profile. For example, Korean chili flakes (gochugaru) are generally hotter than fresh Korean chilies (gochugaru).
3. **Add a dairy or starch component**: A small amount of dairy (e.g., fish sauce, yogurt, or milk) or starch (e.g., rice flour or cornstarch) can help neutralize some of the heat.

**Saltiness:**

1. **Use the right type of salt**: Korean chili flakes can be quite salty, so use a lighter, fluffier salt like kosher salt or sea salt to balance out the flavor.
2. **Monitor the salt content of your brine**: If you're using a store-bought fish sauce or other salty ingredients, be mindful of the overall salt content in your brine. You can always add more salt, but it's harder to remove excess salt.
3. **Rinse your vegetables**: After salting your vegetables, rinse them thoroughly to remove excess salt before adding the seasoning paste.

**Balancing flavors:**

1. **Taste as you go**: Regularly taste your kimchi as you're making it to adjust the seasoning. This will help you catch any imbalances early on.
2. **Use a balanced seasoning paste**: Aim for a seasoning paste with a harmonious balance of sweet, sour, salty, and umami flavors. You can adjust the proportions of ingredients like garlic, ginger, fish sauce, and sugar to achieve this balance.
3. **Add aromatics**: Onions, garlic, and ginger can add depth and balance to your kimchi. Saute them in a bit of oil before adding the seasoning paste to bring out their flavors.
4. **Experiment with different levels of fermentation**: Kimchi's flavor profile changes during fermentation. If your kimchi is too spicy or salty, try fermenting it for a shorter or longer period to mellow out the flavors.

**Additional tips:**

1. **Use fresh, high-quality ingredients**: Old or low-quality ingredients can affect the flavor and texture of your kimchi.
2. **Keep it simple**: Don't overcomplicate your recipe with too many ingredients. Focus on a few key flavors and let them shine.
3. **Be patient**: Kimchi is a fermented food, and fermentation takes time. Allow your kimchi to develop its flavors over time, and be patient with the process.

Remember, kimchi is a highly personal and variable condiment, so don't be afraid to experiment and adjust your recipe to your taste preferences. Good luck, and I hope your next batch turns out delicious!

<a id="source-dee9d2afa1a5912e"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_f8754e93bfdc -->
[2023-05-21] user: I understand that using the right type of chili flakes is important, but I think my main issue was adding too much of it. Do you have any tips on how to measure the right amount of chili flakes for kimchi?

<a id="source-51c0b10960aaec6f"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_43baac8711b5 -->
[2023-05-21] assistant: Adding too much chili flakes can quickly overpower your kimchi. Measuring the right amount of chili flakes can be a bit tricky, but here are some tips to help you get it just right:

**Start with a small amount**: When making kimchi for the first time, it's better to err on the side of caution. Begin with a small amount of chili flakes and adjust to taste.

**Use a spice level guide**: If you're new to working with Korean chili flakes (gochugaru), it's helpful to have a spice level guide. Here's a rough estimate of the heat levels:

* Mild: 1/4 to 1/2 teaspoon gochugaru per 2 cups of vegetables
* Medium: 1/2 to 1 teaspoon gochugaru per 2 cups of vegetables
* Hot: 1 to 2 teaspoons gochugaru per 2 cups of vegetables
* Extremely Hot: 2+ teaspoons gochugaru per 2 cups of vegetables

**Consider the type of chili flakes**: Different brands and types of chili flakes can have varying levels of heat. For example:
* Korean chili flakes (gochugaru) are generally hotter than other types of chili flakes.
* Flakes made from fresher chilies tend to be hotter than those made from dried chilies.

**Measure by weight, not volume**: Measuring chili flakes by weight is more accurate than measuring by volume. Use a digital kitchen scale to measure the flakes in grams or ounces.

**Taste as you go**: Remember, you can always add more chili flakes, but it's harder to remove excess heat. Taste your kimchi as you're making it and adjust the seasoning accordingly.

**Dilute the heat**: If you do add too much chili flakes, you can try diluting the heat by adding a bit more of the other ingredients, like fish sauce, garlic, or ginger.

**Store leftover chili flakes properly**: To maintain the potency of your chili flakes, store them in an airtight container in a cool, dark place.

**Experiment and adjust**: Kimchi is all about balance and personal preference. Don't be afraid to experiment with different levels of heat and adjust the recipe to your taste.

By following these tips, you'll be well on your way to creating a beautifully balanced and delicious kimchi. Happy fermenting!

<a id="source-8e2c6b6819bdc31c"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_751195df2930 -->
[2023-05-21] user: I think I added way too much salt too, do you have any tips on how to adjust the salt content in kimchi?

<a id="source-3eb33e86e5d31093"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_42165ae9055a -->
[2023-05-21] assistant: Too much salt can be a common issue in kimchi, but don't worry, there are ways to adjust the salt content. Here are some tips to help you rescue your kimchi:

**Rinse the kimchi**: If you've added too much salt, try rinsing the kimchi under cold running water to remove excess salt. Gently massage the kimchi with your hands to help release the salt. This method works best if you catch the issue early, before the kimchi has fermented too much.

**Add more vegetables**: If the kimchi is still in the early stages of fermentation, you can try adding more vegetables to dilute the salt content. This will also help to balance out the flavors. Make sure to massage the new vegetables with a bit of salt to help them release their juices and blend with the existing kimchi.

**Add a desalting agent**: In some cases, you can add a small amount of a desalting agent like rice vinegar, Korean chili paste (gochujang), or even a splash of water to help balance out the saltiness. However, be cautious when adding liquids, as this can affect the fermentation process.

**Use a salt-reducing technique**: If the kimchi has already fermented, you can try a salt-reducing technique called "salt-breaking" (, geom-sul). This involves soaking the kimchi in cold water for several hours or overnight, then rinsing it under cold running water. Repeat this process a few times to help remove excess salt. Keep in mind that this method may affect the texture and flavor of the kimchi.

**Start over (if necessary)**: If your kimchi is severely over-salted and none of the above methods work, it might be best to start over with a new batch. Don't worry, it's all part of the kimchi-making process, and you'll learn from your mistakes!

**Prevention is the best cure**: To avoid over-salting in the future, make sure to:

* Use the right type and amount of salt for your recipe.
* Taste the kimchi as you go and adjust the seasoning accordingly.
* Keep an eye on the fermentation process and monitor the salt content regularly.

Remember, kimchi is a flexible and forgiving fermented food, and with a little patience and practice, you'll develop the skills to create a perfectly balanced and delicious kimchi.

<a id="source-830dfa66711d3ef2"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_286878ba2ab6 -->
[2023-05-21] user: I think I'll try rinsing the kimchi under cold running water to remove excess salt. But before I do that, can you give me some tips on how to choose the right Korean chili flakes for my kimchi?

<a id="source-45fb741a5b723a61"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_10b483cad7ba -->
[2023-05-21] assistant: Rinsing the kimchi under cold running water is a great way to remove excess salt. Now, let's talk about choosing the right Korean chili flakes (gochugaru) for your kimchi!

**Understanding Korean chili flakes**:

* Korean chili flakes, also known as gochugaru, are made from dried and crushed Korean chili peppers.
* They come in different levels of heat, flavor, and texture, depending on the type of chili pepper used and the production process.

**Factors to consider when choosing Korean chili flakes**:

1. **Heat level**: Korean chili flakes can range from mildly spicy to extremely hot. If you're new to kimchi, start with a milder variety and adjust to taste.
2. **Flavor profile**: Different chili flakes can have distinct flavor profiles, such as smoky, fruity, or sweet. Choose a flavor that complements your kimchi ingredients.
3. **Texture**: Korean chili flakes can be coarse or fine, depending on the grind size. A finer grind will distribute the heat and flavor more evenly, while a coarser grind will provide a more textured experience.
4. **Brand and quality**: Look for reputable brands that use high-quality chili peppers and have a good reputation among kimchi enthusiasts.

**Popular types of Korean chili flakes**:

1. **Gochugaru**: This is the most common type of Korean chili flakes, made from dried and crushed Korean chili peppers. It has a medium to hot heat level and a balanced flavor.
2. **Cheongyang gochugaru**: This type is made from Cheongyang chili peppers, known for their intense heat and fruity flavor.
3. **Gochugaru from specific regions**: Some brands offer chili flakes from specific regions in Korea, like Jeju Island or Gwangju, which can have unique flavor profiles.

**Tips for choosing the right Korean chili flakes for your kimchi**:

1. **Start with a mild variety**: If you're new to kimchi, begin with a milder chili flake, like gochugaru, and adjust to taste.
2. **Experiment with different brands**: Try different brands to find the one that suits your taste preferences.
3. **Read reviews and ask for recommendations**: Research online, ask friends, or join kimchi communities to get recommendations on the best chili flakes for your kimchi.
4. **Store chili flakes properly**: Keep your chili flakes in an airtight container, away from light and moisture, to preserve their flavor and heat.

Now that you know more about Korean chili flakes, you can make an informed decision when choosing the right one for your kimchi. Remember, the type and amount of chili flakes you use will greatly impact the flavor and heat of your kimchi. Happy kimchi-making!

<a id="source-274c1177e1bea022"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_9ba747ecd95c -->
[2023-05-21] user: I think I'll go with the gochugaru, the most common type of Korean chili flakes. I've heard it has a medium to hot heat level and a balanced flavor, which sounds perfect for my kimchi.

<a id="source-3955dc17fa09c679"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_8b5a61df7f15 -->
[2023-05-21] assistant: Gochugaru is a popular and versatile choice for kimchi, and its medium to hot heat level and balanced flavor make it suitable for a wide range of kimchi recipes. With gochugaru, you'll get a good balance of heat, sweetness, and umami flavor in your kimchi.

**Tips for using gochugaru in your kimchi:**

1. **Start with a small amount**: Begin with a small amount of gochugaru, such as 1/4 to 1/2 teaspoon per 2 cups of vegetables, and adjust to taste.
2. **Mix with other ingredients**: Combine gochugaru with other ingredients like garlic, ginger, fish sauce, and Korean chili paste (gochujang) to create a balanced flavor profile.
3. **Use it in combination with other chili peppers**: If you want to add more heat or depth to your kimchi, you can combine gochugaru with other types of chili peppers, like Korean chili peppers (gochu) or serrano peppers.
4. **Adjust to taste**: Remember that gochugaru's heat level can vary depending on the brand and batch, so taste your kimchi as you go and adjust the seasoning accordingly.

**Some popular kimchi recipes using gochugaru:**

1. **Classic Baechu Kimchi**: A traditional Korean kimchi recipe using napa cabbage, gochugaru, garlic, ginger, and fish sauce.
2. **Kimchi Stew (Kimchi Jjigae)**: A spicy, savory stew made with gochugaru, kimchi, pork, tofu, and vegetables.
3. **Radish Kimchi (Danmuji Kimchi)**: A refreshing kimchi recipe using daikon radish, gochugaru, garlic, and ginger.

Now that you have your gochugaru, it's time to get started on your kimchi-making journey! Remember to taste and adjust as you go, and don't hesitate to experiment with different ingredients and recipes. Happy kimchi-making!

<a id="source-3dd95118165ede9d"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_2719e25a26a0 -->
[2023-05-21] user: I'm going to rinse the kimchi under cold running water to remove excess salt, and then I'll try using the gochugaru to add more flavor to my kimchi. I'm also thinking of adding some garlic and ginger to balance out the flavors. Do you have any tips on how to prepare garlic and ginger for kimchi?

<a id="source-38b226a6cc202564"></a>
<!-- source-id:locomo/thread_6bc2090ac4de/msg_077b9fd33521 -->
[2023-05-21] assistant: Rinsing the kimchi under cold running water is a great way to remove excess salt, and adding gochugaru, garlic, and ginger will definitely enhance the flavor. Preparing garlic and ginger correctly is important to bring out their flavors and textures in your kimchi. Here are some tips:

**Preparing Garlic for Kimchi:**

1. **Use fresh garlic**: Fresh garlic is essential for kimchi, as it provides a pungent flavor and aroma. Avoid using old or sprouted garlic, as it can be bitter and affect the flavor.
2. **Mince or crush garlic**: Mince or crush garlic cloves to release their oils and flavor compounds. You can use a garlic press, microplane, or simply chop the garlic finely with a knife.
3. **Use the right amount**: Use about 2-3 cloves of garlic per 2 cups of vegetables. You can adjust to taste, but this is a good starting point.
4. **Mix with other ingredients**: Combine minced garlic with other ingredients like gochugaru, fish sauce, and ginger to create a harmonious flavor profile.

**Preparing Ginger for Kimchi:**

1. **Use fresh ginger**: Fresh ginger is preferred for kimchi, as it provides a spicy, warming flavor and aroma. You can use either young or mature ginger, depending on your preference.
2. **Peel and grate or slice**: Peel the ginger and grate or slice it thinly to release its oils and flavor compounds. You can use a microplane or a box grater for this.
3. **Use the right amount**: Use about 1-2 inches of grated or sliced ginger per 2 cups of vegetables. Adjust to taste, as ginger can be quite potent.
4. **Mix with other ingredients**: Combine grated or sliced ginger with other ingredients like gochugaru, garlic, and fish sauce to create a balanced flavor profile.

**Tips for working with garlic and ginger:**

* Always handle garlic and ginger gently to avoid bruising or crushing them, which can release their bitterness.
* Use a separate cutting board and knife for garlic and ginger to prevent flavor transfer to other ingredients.
* If you're concerned about the pungency of garlic or ginger, you can sauté them in a bit of oil before adding them to your kimchi to mellow out their flavors.

By following these tips, you'll be able to prepare garlic and ginger that will add depth and balance to your kimchi. Remember to taste and adjust as you go, and don't hesitate to experiment with different amounts and preparation methods to find your perfect flavor profile. Happy kimchi-making!
